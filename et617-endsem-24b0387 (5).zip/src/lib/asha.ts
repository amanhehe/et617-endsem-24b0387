// "Ask Asha": the learner can ask a question, say she's confused, or explain her reasoning (typed or spoken) at
// any point. Asha answers in context and asks a FOLLOW-UP question; the learner's reply is then assessed for the
// concept (AI when available; a labelled concept check otherwise). Every number in an AI answer is verified.
import { checkMath, type Ctx } from "./pipeline";
import type { Diag } from "./content";

export type AskCtx = { stage: string; diag: Diag; labPct: number | null; anxious: boolean };
export type Concept = "independence" | "chance" | "multiply" | "variation" | "streak";
export type AshaReply = { answer: string; followup: string; concept: Concept; source: "ai" | "rules"; note?: string };
export type Judgement = { understood: boolean; feedback: string; source: "ai" | "rules" };

const INTENTS: { re: RegExp; concept: Concept; answer: (c: AskCtx) => string; followup: string }[] = [
  {
    re: /(confus|don'?t (get|understand)|not (getting|clear)|samajh|lost|hard|difficult|explain again)/i, concept: "independence",
    answer: (c) => `That's okay${c.anxious ? ", and thank you for saying it" : ""}. Let's make it smaller: a coin is just metal; it can't remember anything. So each toss is a fresh start, and the chance of heads is always 1/2.`,
    followup: "In your own words: why can't five heads change the next toss?",
  },
  {
    re: /(due|turn|balance|owe|catch up|even out|my luck)/i, concept: "streak",
    answer: () => "Great question. It feels like tails should be \"due\", but the coin doesn't keep score. Over many tosses the % evens out because new tosses dilute old ones, not because the coin pays anything back.",
    followup: "So after five heads, is tails more likely, less likely, or the same? Why?",
  },
  {
    re: /(streak|hot|lucky|guarantee|keep winning|in form|continue)/i, concept: "streak",
    answer: (c) => `A streak feels powerful, but for a fair coin it changes nothing.${c.labPct !== null ? ` Your own lab showed heads came after H H H about ${c.labPct}% of the time.` : ""} In sport, skill can change; a coin's chance can't.`,
    followup: "If someone won 4 tosses in a row, what's their chance of winning the 5th, and why?",
  },
  {
    re: /(two toss|2 toss|both|twice|hh|multiply|1\/4|sequence|in a row)/i, concept: "multiply",
    answer: () => "For two tosses, list them: HH, HT, TH, TT. These 4 are equally likely, and HH is one of them, so 1/4. That's the same as multiplying: 1/2 × 1/2 = 1/4.",
    followup: "Using the same idea, what is the chance of HHH in three tosses?",
  },
  {
    re: /(lab|range|variation|why not exactly|not 50|percent|%|data)/i, concept: "variation",
    answer: () => "Real data wobbles. With a few hundred streaks, getting 46% or 54% instead of exactly 50% is normal chance variation. The more tosses, the closer it settles to 50%.",
    followup: "If you tossed 10 times and got 7 heads, would that prove the coin is unfair? Why or why not?",
  },
  {
    re: /(why|how come|reason|independ|memory|what does .* mean|matlab)/i, concept: "independence",
    answer: () => "\"Independent\" means one toss can't affect another. The coin has no memory and nothing inside it changes, so the chance of heads stays 1/2 every single time.",
    followup: "Can you think of something that is NOT independent, where the past does change the next result?",
  },
];

export function ashaRules(q: string, c: AskCtx): AshaReply {
  const hit = INTENTS.find((x) => x.re.test(q));
  if (hit) return { answer: hit.answer(c), followup: hit.followup, concept: hit.concept, source: "rules" };
  return {
    answer: "Good thinking out loud. The key idea today: each toss of a fair coin is independent, so earlier results never change the next chance of 1/2.",
    followup: "Which part feels least clear: the 'no memory' idea, the 1/2, or what the streak means?",
    concept: "independence",
    source: "rules",
  };
}

/** Concept check of the learner's reply to Asha's follow-up (fallback when the AI isn't available). */
export function judgeRules(reply: string, concept: Concept): Judgement {
  const t = reply.toLowerCase();
  const indep = /(independ|memory|remember|fresh|separate|not (affect|change|depend)|doesn'?t (affect|change|depend)|can'?t (affect|change))/.test(t);
  const half = /(1\/2|half|50 ?%|50-50|same|equal)/.test(t);
  const endorses = /(is due|will turn|must turn|more likely now|keep winning|on a streak so)/.test(t) && !/(not|n'?t|never|no)\s+(\w+\s+){0,3}(due|turn|more likely)/.test(t);
  if (endorses) return { understood: false, feedback: "Hmm, that still sounds like the streak changes the next toss. What does the coin remember?", source: "rules" };
  const ok =
    concept === "multiply" ? /(1\/8|0\.125|12\.5|one eighth)/.test(t) :
    concept === "variation" ? /(no|not|chance|normal|vary|small|few|luck)/.test(t) && !/^yes\b/.test(t.trim()) :
    concept === "streak" ? (half || /(same|equal)/.test(t)) && (indep || /(because|coin|toss)/.test(t)) :
    indep || /(cards|draw|without|marbles|skill|practice|tired|weather)/.test(t);
  return {
    understood: ok,
    feedback: ok
      ? "Yes, that shows you understand it, not just the words. Nice reasoning."
      : concept === "multiply" ? "Close. Three tosses: 1/2 × 1/2 × 1/2. What does that give?" : "Nearly. Try to say WHY: does the earlier result change anything about the coin?",
    source: "rules",
  };
}

async function post(task: string, body: object): Promise<unknown | null> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 9000);
    const r = await fetch("/api/agent", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ task, ...body }), signal: ctl.signal });
    clearTimeout(t);
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}
const mathCtx = (c: AskCtx): Ctx => ({ key: "ask", diag: c.diag, anxious: c.anxious, labPct: c.labPct, labCases: 0, truth: { label: "", forms: [""] } });

export async function askAsha(q: string, c: AskCtx): Promise<AshaReply> {
  const rules = ashaRules(q, c);
  const o = (await post("ask", { ctx: c, question: q.slice(0, 500) })) as Partial<AshaReply> | null;
  const concepts: Concept[] = ["independence", "chance", "multiply", "variation", "streak"];
  if (!o || typeof o.answer !== "string" || typeof o.followup !== "string" || !concepts.includes(o.concept as Concept) || o.answer.length > 600) return { ...rules, note: o ? "AI reply failed the format check; Asha used her verified notes." : undefined };
  if (!checkMath(`${o.answer} ${o.followup}`, mathCtx(c)).pass) return { ...rules, note: "AI reply contained a number Noor couldn't verify, so Asha used her verified notes." };
  return { answer: o.answer, followup: o.followup, concept: o.concept as Concept, source: "ai" };
}

export async function judgeReply(followup: string, reply: string, concept: Concept, c: AskCtx): Promise<Judgement> {
  const rules = judgeRules(reply, concept);
  const o = (await post("understand", { ctx: c, followup, reply: reply.slice(0, 500), concept })) as { understood?: unknown; feedback?: unknown } | null;
  if (!o || typeof o.understood !== "boolean" || typeof o.feedback !== "string" || o.feedback.length > 300) return rules;
  if (!checkMath(o.feedback, mathCtx(c)).pass) return rules;
  return { understood: o.understood, feedback: o.feedback, source: "ai" };
}

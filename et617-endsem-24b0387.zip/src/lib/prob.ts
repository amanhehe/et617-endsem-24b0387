// Probability helpers for a fair coin. All maths here is exact or computed from real simulated tosses.
export type Side = "H" | "T";

/** n fair, independent tosses using the browser's cryptographic random generator. */
export function toss(n: number): Side[] {
  const out: Side[] = [];
  while (out.length < n) {
    const chunk = new Uint32Array(Math.min(n - out.length, 8192));
    crypto.getRandomValues(chunk);
    for (const x of chunk) out.push(x & 1 ? "H" : "T");
  }
  return out;
}

export type LabStats = {
  tosses: number;
  heads: number;
  longestHeads: number;
  longestAny: number;
  /** positions that came right after 3 heads in a row, and how many of those were heads */
  after3: { cases: number; heads: number };
};

export function stats(seq: Side[]): LabStats {
  let heads = 0, run = 0, runSide: Side | null = null, longestHeads = 0, longestAny = 0;
  let cases = 0, h3 = 0;
  for (let i = 0; i < seq.length; i++) {
    const s = seq[i]!;
    if (i >= 3 && seq[i - 1] === "H" && seq[i - 2] === "H" && seq[i - 3] === "H") {
      cases++;
      if (s === "H") h3++;
    }
    if (s === "H") heads++;
    run = s === runSide ? run + 1 : 1;
    runSide = s;
    longestAny = Math.max(longestAny, run);
    if (s === "H") longestHeads = Math.max(longestHeads, run);
  }
  return { tosses: seq.length, heads, longestHeads, longestAny, after3: { cases, heads: h3 } };
}

/** Exact probability that n fair tosses contain a run of at least k heads (dynamic programming). */
export function pRunAtLeast(n: number, k: number): number {
  let p = new Array<number>(k).fill(0); // p[j] = prob. current head-run is j and no run of k yet
  p[0] = 1;
  let done = 0;
  for (let t = 0; t < n; t++) {
    const q = new Array<number>(k).fill(0);
    for (let j = 0; j < k; j++) {
      q[0] += p[j]! * 0.5; // tails resets the run
      if (j + 1 < k) q[j + 1] += p[j]! * 0.5;
      else done += p[j]! * 0.5; // heads completes a run of k
    }
    p = q;
  }
  return done;
}

/** Probability of one exact sequence of n fair tosses. */
export const pSequence = (n: number) => Math.pow(0.5, n);

/** Reads "1/4", "0.25", "25%", "1 / 4", ".25" → 0.25; anything else → null. */
export function parseProb(raw: string): number | null {
  const s = raw.trim().replace(/\s+/g, "");
  let m = s.match(/^(\d+)\/(\d+)$/);
  if (m) return Number(m[2]) === 0 ? null : Number(m[1]) / Number(m[2]);
  m = s.match(/^(\d*\.?\d+)%$/);
  if (m) return Number(m[1]) / 100;
  m = s.match(/^(\d*\.?\d+)$/);
  if (m) return Number(m[1]);
  return null;
}

export const pct = (a: number, b: number) => (b ? Math.round((a / b) * 100) : 0);

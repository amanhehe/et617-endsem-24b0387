// The three agents' reasoning pipeline. Each agent has its own task and passes a STRUCTURED output to the next:
//   1. Teacher   → Proposal  {explanation, example, claims}
//   2. Challenger→ Critique  {issues[], verdict}           (tests the proposal for weaknesses)
//   3. Evaluator → MathCheck {checks[], labCheck, pass}    (verifies every number against exact maths / lab data)
//   4. Teacher revises using the critique + math check    → Final {text, revisions[]}
// Teacher and Challenger use the AI model when available (/api/agent); otherwise a labelled rule engine.
// The Evaluator's mathematical verification always runs in code: numbers are checked, never trusted.
import type { Diag } from "./content";

export type Ctx = {
  key: string;
  diag: Diag;
  anxious: boolean;
  labPct: number | null;
  labCases: number;
  question?: string;
  learnerAnswer?: string;
  /** the correct result the explanation must state, in any of these forms */
  truth: { label: string; forms: string[] };
};
export type Proposal = { explanation: string; example: string; source: "ai" | "rules" };
export type Issue = { type: "no-independence" | "misconception-not-addressed" | "too-long" | "no-evidence" | "endorses-misconception" | "missing-answer"; note: string };
export type Critique = { issues: Issue[]; verdict: "ok" | "revise"; source: "ai" | "rules" };
export type MathCheck = { checks: { stated: string; value: number; ok: boolean; why: string }[]; truthStated: boolean; labCheck?: { stated: number; actual: number; ok: boolean }; pass: boolean };
export type PipeResult = { proposal: Proposal; critique: Critique; math: MathCheck; final: string; revisions: string[]; usedFallback: boolean };

// ---------------------------------------------------------------- 1. Teacher: propose
const TEACH: Record<Diag, { core: string; example: string }> = {
  M1: {
    core: "A fair coin has no memory, so each toss is independent. It doesn't keep score, so it can't \"owe\" you tails after a run of heads.",
    example: "Over many tosses the share of heads gets close to 50% because new tosses dilute the old streak, not because tails comes to pay it back: 5 extra heads in 1000 tosses is only 0.5%.",
  },
  M2: {
    core: "A fair coin has no memory, so each toss is independent. Winning doesn't make the next win more likely, and a streak can never guarantee one.",
    example: "A cricket captain who won 3 tosses in a row still has the same chance on the 4th toss: nothing about the coin has changed.",
  },
  none: {
    core: "Any fair device with no memory works the same way: each toss or roll is independent of the ones before.",
    example: "A fair die has 6 equally likely faces, so the chance of a 6 is 1/6 on every roll, even after three 6s.",
  },
};
function teacherRules(c: Ctx): Proposal {
  const t = TEACH[c.diag];
  const ans = c.truth.forms[0]!;
  const lead = c.learnerAnswer ? `You answered "${c.learnerAnswer}". Let's check it. ` : "";
  return { explanation: `${lead}${t.core} So ${c.truth.label} is ${ans}.`, example: t.example, source: "rules" };
}

// ---------------------------------------------------------------- 2. Challenger: test for weaknesses
const MIS_WORDS: Record<Diag, RegExp> = { M1: /(owe|due|balance|pay (it )?back|keep score)/i, M2: /(guarantee|streak|more likely|hot)/i, none: /./ };
function challengerRules(p: Proposal, c: Ctx): Critique {
  const text = `${p.explanation} ${p.example}`;
  const issues: Issue[] = [];
  if (!/(independent|no memory|doesn'?t remember|does not remember)/i.test(text)) issues.push({ type: "no-independence", note: "It never says the tosses are independent (no memory). That is the core idea." });
  if (!MIS_WORDS[c.diag].test(text)) issues.push({ type: "misconception-not-addressed", note: `It doesn't speak to the learner's actual belief (${c.diag}).` });
  if (/(is due|are due|luck (will|must|has to) (turn|change)|streak (will|should) continue)/i.test(text.replace(/can'?t "owe"|not because|never guarantee/gi, ""))) issues.push({ type: "endorses-misconception", note: "A sentence could be read as supporting the misconception." });
  if (!c.truth.forms.some((f) => text.includes(f))) issues.push({ type: "missing-answer", note: `It never states the correct result (${c.truth.forms[0]}).` });
  const words = p.explanation.split(/\s+/).length;
  if (c.anxious && words > 55) issues.push({ type: "too-long", note: `${words} words is a lot for an anxious learner. Keep it short.` });
  if (c.labPct !== null && c.labCases >= 15 && !/(your lab|your own lab|your data)/i.test(text)) issues.push({ type: "no-evidence", note: `It doesn't use the learner's own evidence (${c.labPct}% heads after HHH).` });
  return { issues, verdict: issues.length ? "revise" : "ok", source: "rules" };
}

// ---------------------------------------------------------------- 3. Evaluator: verify the maths (always code)
const KNOWN: { v: number; why: string }[] = [
  { v: 1 / 2, why: "P(H) for a fair coin" }, { v: 1 / 4, why: "(1/2)² for two tosses" }, { v: 1 / 6, why: "P(one face) for a fair die" },
  { v: 1 / 8, why: "(1/2)³" }, { v: 1 / 16, why: "(1/2)⁴" }, { v: 1 / 32, why: "(1/2)⁵" }, { v: 1 / 64, why: "(1/2)⁶" }, { v: 0.005, why: "5 of 1000" },
];
export function checkMath(text: string, c: Ctx): MathCheck {
  const checks: MathCheck["checks"] = [];
  let labCheck: MathCheck["labCheck"];
  // fractions like 1/2, decimals like 0.25, percentages like 50%
  const re = /(\d+)\s*\/\s*(\d+)|(\d*\.\d+)%?|(\d+(?:\.\d+)?)%/g;
  for (const m of text.matchAll(re)) {
    const raw = m[0];
    const value = m[1] ? Number(m[1]) / Number(m[2]) : m[3] ? Number(m[3]) / (raw.endsWith("%") ? 100 : 1) : Number(m[4]) / 100;
    const isPct = raw.endsWith("%");
    // a percentage that matches the learner's lab result is checked against the real data
    if (isPct && c.labPct !== null && Math.abs(value * 100 - c.labPct) < 0.51 && Math.abs(value - 0.5) > 0.004) {
      labCheck = { stated: value * 100, actual: c.labPct, ok: true };
      checks.push({ stated: raw, value, ok: true, why: `matches your lab data (${c.labPct}%)` });
      continue;
    }
    const k = KNOWN.find((x) => Math.abs(x.v - value) < 1e-9);
    checks.push({ stated: raw, value, ok: !!k, why: k ? k.why : "not a probability this situation can have" });
  }
  // the learner's lab percentage, if mentioned in words like "your lab ... 47%", must equal the real data
  const truthStated = c.truth.forms.some((f) => text.includes(f));
  return { checks, truthStated, labCheck, pass: checks.every((x) => x.ok) && truthStated };
}

// ---------------------------------------------------------------- 4. Teacher: revise using both reviews
function revise(p: Proposal, cr: Critique, mc: MathCheck, c: Ctx): { text: string; revisions: string[] } {
  const revisions: string[] = [];
  let base = p;
  if (!mc.pass) {
    base = teacherRules(c);
    revisions.push(`Noor rejected the maths (${mc.checks.filter((x) => !x.ok).map((x) => x.stated).join(", ") || "correct result missing"}); Asha rewrote it from verified facts.`);
  }
  let text = base.explanation;
  const has = (t: Issue["type"]) => cr.issues.some((i) => i.type === t);
  if (has("too-long")) {
    text = text.split(/(?<=[.!?])\s+/).slice(0, 2).join(" ");
    if (!c.truth.forms.some((f) => text.includes(f))) text += ` So ${c.truth.label} is ${c.truth.forms[0]}.`;
    revisions.push("Shortened for an anxious learner (Kabir's point).");
  }
  if (has("no-independence") && !/(independent|no memory)/i.test(text)) {
    text = `Each toss is independent: the coin has no memory. ${text}`;
    revisions.push("Added the independence idea (Kabir's point).");
  }
  if (has("misconception-not-addressed") && !MIS_WORDS[c.diag].test(text)) {
    text += c.diag === "M1" ? " The coin can't \"owe\" you anything." : c.diag === "M2" ? " A streak never guarantees the next win." : "";
    revisions.push("Spoke to the learner's own belief (Kabir's point).");
  }
  if (has("missing-answer") && !c.truth.forms.some((f) => text.includes(f))) {
    text += ` So ${c.truth.label} is ${c.truth.forms[0]}.`;
    revisions.push("Stated the correct result (Kabir's point).");
  }
  let example = base.example;
  if (has("no-evidence") && c.labPct !== null) {
    example = `In your own lab, heads came right after H H H ${c.labPct}% of the time (${c.labCases} times), close to 50%. ${example}`;
    revisions.push("Added the learner's own lab evidence (Kabir's point).");
  }
  if (!revisions.length) revisions.push("No changes needed: Kabir found no weaknesses and Noor verified the maths.");
  return { text: `${text}\n${example}`, revisions };
}

// ---------------------------------------------------------------- AI calls (validated), with rule fallbacks
async function ai(role: "teacher" | "challenger", body: unknown): Promise<unknown | null> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 9000);
    const r = await fetch("/api/agent", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ task: role, ...(body as object) }), signal: ctl.signal });
    clearTimeout(t);
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}
const ISSUE_TYPES: Issue["type"][] = ["no-independence", "misconception-not-addressed", "too-long", "no-evidence", "endorses-misconception", "missing-answer"];

export async function runPipeline(c: Ctx): Promise<PipeResult> {
  // 1. Teacher proposes
  let proposal = teacherRules(c);
  const tp = (await ai("teacher", { ctx: c })) as Record<string, unknown> | null;
  if (tp && typeof tp.explanation === "string" && typeof tp.example === "string" && tp.explanation.length > 20 && tp.explanation.length < 700 && tp.example.length < 500)
    proposal = { explanation: tp.explanation.trim(), example: tp.example.trim(), source: "ai" };
  // 2. Challenger critiques (AI issues are merged with the rule checks, never replace them)
  const rules = challengerRules(proposal, c);
  let critique = rules;
  const cp = (await ai("challenger", { ctx: c, proposal })) as { issues?: unknown } | null;
  if (cp && Array.isArray(cp.issues)) {
    const extra = (cp.issues as { type?: unknown; note?: unknown }[])
      .filter((i) => ISSUE_TYPES.includes(i.type as Issue["type"]) && typeof i.note === "string" && !rules.issues.some((r) => r.type === i.type))
      .map((i) => ({ type: i.type as Issue["type"], note: String(i.note).slice(0, 200) }));
    critique = { issues: [...rules.issues, ...extra], verdict: rules.issues.length + extra.length ? "revise" : "ok", source: "ai" };
  }
  // 3. Evaluator verifies the maths in code
  const math = checkMath(`${proposal.explanation} ${proposal.example}`, c);
  // 4. Teacher revises; the final text is verified again before it is shown
  let { text, revisions } = revise(proposal, critique, math, c);
  let usedFallback = !math.pass;
  if (!checkMath(text, c).pass) {
    const safe = teacherRules(c);
    text = `${safe.explanation}\n${safe.example}`;
    revisions = [...revisions, "Final check failed, so Noor released the verified rule-based version."];
    usedFallback = true;
  }
  return { proposal, critique, math, final: text, revisions, usedFallback };
}

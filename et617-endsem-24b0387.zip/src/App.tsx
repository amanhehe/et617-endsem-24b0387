import { useEffect, useMemo, useRef, useState } from "react";
import "./App.css";
import { AGENTS, CARD, DIAG, ID, MIS_NAME, POST, PRE, SESSION_SECONDS, STEPS, tasksFor, type AgentId, type Diag, type Mis, type Step, type TestItem } from "./lib/content";
import { parseProb, pct, pRunAtLeast, stats, toss, type Side } from "./lib/prob";
import { evaluateExplanation, type Verdict } from "./lib/evaluator";

// ---------------------------------------------------------------- state (saved to this device after every change)
type Msg = { from: AgentId; to: AgentId; text: string; at: number };
type Ans = { attempts: number; correct: boolean; hint: boolean; value: string; tag?: Mis; done: boolean; fb?: string; labFb?: boolean };
type TestAns = { choice: string; correct: boolean; tag?: Mis; conf?: 0 | 1 | 2 };
type Batch = { tosses: number; cases: number; heads: number };
type Ev = { t: number; step: Step; type: string; data?: unknown };
export type S = {
  v: 2;
  step: Step;
  started: boolean;
  finished: boolean;
  paused: boolean;
  activeMs: number;
  stepMs: Partial<Record<Step, number>>;
  feeling?: 0 | 1 | 2;
  pre: Record<string, TestAns>;
  preIdx: number;
  side?: "M1" | "M2"; // the idea the Challenger argues (taken from the learner's pre-test)
  diag?: Diag; // explicit diagnosis: selects explanation, example, follow-up and hints
  met: Mis[];
  resolved: Mis[];
  lab: { seq: Side[]; batches: Batch[]; verdict?: "teacher" | "challenger" | "unsure"; wrongVerdicts: number };
  task: number;
  answers: Record<string, Ans>;
  q5?: Verdict & { text: string };
  post: Record<string, TestAns>;
  postIdx: number;
  endConf?: 0 | 1 | 2;
  channel: Msg[];
  log: Ev[];
};
const KEY = `et617-${ID}-lucky-streak-v2`;
const fresh = (): S => ({
  v: 2, step: "welcome", started: false, finished: false, paused: false, activeMs: 0, stepMs: {},
  pre: {}, preIdx: 0, met: [], resolved: [], lab: { seq: [], batches: [], wrongVerdicts: 0 },
  task: 0, answers: {}, post: {}, postIdx: 0, channel: [], log: [],
});
function load(): S | null {
  try {
    const s = JSON.parse(localStorage.getItem(KEY) ?? "null");
    return s && s.v === 2 ? (s as S) : null;
  } catch {
    return null;
  }
}
const mmss = (ms: number) => {
  const s = Math.max(0, Math.round(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
};
const FEEL = ["😟 Worried", "😐 Unsure", "🙂 Okay"];
const CONF = ["Guessing", "Fairly sure", "Sure"];
const uniq = <T,>(a: T[]) => [...new Set(a)];

/** The shared notes board every agent reads before it speaks. */
function notes(s: S) {
  const st = stats(s.lab.seq);
  const hints = Object.values(s.answers).filter((a) => a.hint).length;
  return {
    anxious: s.feeling === 0 || s.pre.pre1?.conf === 0,
    feeling: s.feeling === undefined ? "—" : FEEL[s.feeling]!.slice(3),
    diag: s.diag,
    labPct: st.after3.cases ? pct(st.after3.heads, st.after3.cases) : null,
    labCases: st.after3.cases,
    wrongVerdicts: s.lab.wrongVerdicts,
    hints,
  };
}
type Notes = ReturnType<typeof notes>;

export default function App() {
  const [s, setS] = useState<S>(() => load() ?? fresh());
  const [welcomeBack, setWelcomeBack] = useState(() => {
    const l = load();
    return !!(l && l.started && !l.finished);
  });
  const [about, setAbout] = useState(false);
  const sRef = useRef(s);
  sRef.current = s;
  const supporting = useRef(false);
  supporting.current = about || welcomeBack;
  const save = (n: S) => {
    try {
      localStorage.setItem(KEY, JSON.stringify(n));
    } catch {
      /* storage full: the session still works */
    }
  };
  const up = (f: (d: S) => S) => setS((p) => { const n = f(p); save(n); return n; });
  const log = (type: string, data?: unknown) => up((d) => ({ ...d, log: [...d.log, { t: Date.now(), step: d.step, type, data }].slice(-600) }));
  const say = (msgs: Omit<Msg, "at">[]) => up((d) => ({ ...d, channel: [...d.channel, ...msgs.map((m) => ({ ...m, at: Date.now() }))] }));
  const go = (step: Step) => up((d) => ({ ...d, step, log: [...d.log, { t: Date.now(), step, type: "enter_stage" }] }));

  // the 10-minute clock: ACTIVE time in the six timed stages only (not while paused, on supporting screens, or in a hidden tab)
  useEffect(() => {
    const id = window.setInterval(() => {
      const d = sRef.current;
      if (d.paused || d.finished || !d.started || supporting.current || document.visibilityState !== "visible") return;
      if (!STEPS.some((x) => x.id === d.step)) return;
      up((x) => ({ ...x, activeMs: x.activeMs + 1000, stepMs: { ...x.stepMs, [x.step]: (x.stepMs[x.step] ?? 0) + 1000 } }));
    }, 1000);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pause = () => { up((d) => ({ ...d, paused: true })); log("pause"); };
  const resume = () => { setWelcomeBack(false); up((d) => ({ ...d, paused: false })); log("resume"); };
  const restart = () => { const n = fresh(); save(n); setS(n); setWelcomeBack(false); };

  const N = notes(s);
  const idx = STEPS.findIndex((x) => x.id === s.step);
  const timed = idx >= 0 && !about && !welcomeBack && !s.paused;
  const P = { s, up, say, log, go, N };

  return (
    <div className="app">
      <header className="top">
        <div className="brand">🪙 <b>Lucky Streak?</b> <small>probability with 3 AI helpers</small></div>
        {s.started && !s.finished && (
          <div className="session" aria-label="10-minute session">
            <div className="clock">
              <span>⏱ {mmss(s.activeMs)} <small>of 10:00 {timed ? "" : "· clock stopped"}</small></span>
              {timed && <button className="ghost" onClick={pause}>⏸ Pause &amp; save</button>}
            </div>
            <ol className="steps">
              {STEPS.map((x, i) => (
                <li key={x.id} className={i < idx ? "done" : i === idx ? "now" : ""}>
                  <span>{x.label}</span>
                  <i>{mmss(x.budget * 1000)}</i>
                </li>
              ))}
            </ol>
            {timed && (
              <p className="calm">
                {s.activeMs / 1000 > SESSION_SECONDS
                  ? "A little over 10 minutes. That's fine, finish calmly."
                  : `Stage ${idx + 1} of 6 · about ${Math.max(1, Math.round((SESSION_SECONDS - s.activeMs / 1000) / 60))} min left · no rush, nothing is graded`}
              </p>
            )}
          </div>
        )}
      </header>

      <main>
        {about ? (
          <About onBack={() => setAbout(false)} />
        ) : welcomeBack ? (
          <Welcome returning s={s} onStart={() => {}} onContinue={resume} onRestart={restart} onAbout={() => setAbout(true)} />
        ) : s.paused ? (
          <Paused s={s} onResume={resume} />
        ) : s.step === "welcome" ? (
          <Welcome returning={false} s={s} onStart={() => { up((d) => ({ ...d, started: true })); go("pretest"); }} onContinue={resume} onRestart={restart} onAbout={() => setAbout(true)} />
        ) : s.step === "pretest" ? (
          <Pretest {...P} />
        ) : s.step === "debate" ? (
          <Debate {...P} />
        ) : s.step === "lab" ? (
          <Lab {...P} />
        ) : s.step === "practice" ? (
          <Practice {...P} />
        ) : s.step === "posttest" ? (
          <Posttest {...P} />
        ) : s.step === "reflect" ? (
          <Reflect {...P} />
        ) : (
          <Summary s={s} onRestart={restart} />
        )}
        {s.started && !about && !welcomeBack && s.step !== "welcome" && <Channel s={s} N={N} />}
      </main>

      <footer>
        ET 617 End-Sem · ID <b>{ID}</b> · {CARD} · <button className="link" onClick={() => setAbout(true)}>About</button>
      </footer>
    </div>
  );
}

// ---------------------------------------------------------------- shared bits
type Up = (f: (d: S) => S) => void;
type Props = { s: S; up: Up; say: (m: Omit<Msg, "at">[]) => void; log: (t: string, d?: unknown) => void; go: (s: Step) => void; N: Notes };

function Bubble({ who, children, challenge, via }: { who: AgentId; children: React.ReactNode; challenge?: boolean; via?: string }) {
  const a = AGENTS[who];
  return (
    <div className={`bubble ${who}`}>
      <div className="who">
        <span className={`dot ${who}`} /> {a.name} <small>· {a.role}</small>
        {challenge && <em className="tag">CHALLENGE: test me, I might be wrong</em>}
      </div>
      <div className="say">{children}</div>
      {via && <div className="via">↳ {via}</div>}
    </div>
  );
}

function Channel({ s, N }: { s: S; N: Notes }) {
  return (
    <details className="channel">
      <summary>🔁 Agent channel: shared notes &amp; messages ({s.channel.length})</summary>
      <p className="notes">
        <b>Shared notes:</b> feeling {N.feeling}{N.anxious ? " (anxious → gentle mode)" : ""} · diagnosis {N.diag ? DIAG[N.diag].title : "—"} · lab {N.labPct === null ? "—" : `${N.labPct}% heads after HHH (${N.labCases} times)`} · wrong verdicts {N.wrongVerdicts} · hints used {N.hints}
      </p>
      <ul>
        {s.channel.map((m, i) => (
          <li key={i}><b className={m.from}>{AGENTS[m.from].role}</b> → <b className={m.to}>{AGENTS[m.to].role}</b>: {m.text}</li>
        ))}
      </ul>
    </details>
  );
}

function Options({ item, value, onPick, disabled, mark }: { item: TestItem; value?: string; onPick: (id: string) => void; disabled?: boolean; mark?: boolean }) {
  return (
    <div className="options">
      {item.options.map((o) => (
        <button key={o.id} disabled={disabled} className={`option ${value === o.id ? (mark ? (o.correct ? "good" : "notyet") : "on") : ""}`} onClick={() => onPick(o.id)}>{o.text}</button>
      ))}
    </div>
  );
}

function Coins({ seq, small }: { seq: string; small?: boolean }) {
  return <div className={`coins ${small ? "small" : ""}`}>{seq.split("").map((c, i) => <span key={i} className={`coin ${c === "H" ? "h" : "t"}`}>{c}</span>)}</div>;
}

// ---------------------------------------------------------------- supporting screens (not timed)
function Welcome({ returning, s, onStart, onContinue, onRestart, onAbout }: { returning: boolean; s: S; onStart: () => void; onContinue: () => void; onRestart: () => void; onAbout: () => void }) {
  if (returning) {
    const i = STEPS.findIndex((x) => x.id === s.step);
    return (
      <section className="card">
        <h1>Welcome back 👋</h1>
        <p>Your place is saved. You were on <b>Stage {i + 1}: {STEPS[i]?.label}</b>, with <b>{mmss(s.activeMs)}</b> of your 10 minutes used.</p>
        <div className="row">
          <button className="primary" onClick={onContinue}>Continue where I stopped</button>
          <button className="ghost" onClick={onRestart}>Start over</button>
        </div>
      </section>
    );
  }
  return (
    <section className="card">
      <h1>Is a "lucky streak" real?</h1>
      <p>You've met probability before, and maybe it didn't go well. <b>That's okay.</b> This time we won't memorise rules. We'll <b>test ideas with real coin tosses</b>, and you decide what's true.</p>
      <div className="trio">
        {(Object.keys(AGENTS) as AgentId[]).map((k) => (
          <div key={k} className={`mini ${k}`}><span className={`dot ${k}`} /> <b>{AGENTS[k].name}</b><small>{AGENTS[k].role}: {AGENTS[k].tone}</small></div>
        ))}
      </div>
      <ul className="facts">
        <li>⏱ <b>10 minutes</b> in 6 short stages (1:30 + 1:30 + 2:00 + 2:30 + 1:30 + 1:00).</li>
        <li>⏸ <b>Pause any time</b>; your place is saved on this phone.</li>
        <li>🌱 Nothing is graded and nobody sees your answers.</li>
      </ul>
      <div className="row">
        <button className="primary" onClick={onStart}>Start my 10-minute session</button>
        <button className="ghost" onClick={onAbout}>About</button>
      </div>
    </section>
  );
}

function Paused({ s, onResume }: { s: S; onResume: () => void }) {
  const i = STEPS.findIndex((x) => x.id === s.step);
  return (
    <section className="card center">
      <h1>⏸ Saved</h1>
      <p>You can close the app now. Next time you'll continue from <b>Stage {i + 1}: {STEPS[i]?.label}</b>.</p>
      <p className="muted">Time used: {mmss(s.activeMs)} of 10:00 (the clock is stopped).</p>
      <button className="primary" onClick={onResume}>Continue now</button>
    </section>
  );
}

// ---------------------------------------------------------------- stage 1: check-in + pre-test (no feedback)
function Pretest({ s, up, say, log, go }: Props) {
  const item = PRE[s.preIdx]!;
  const a = s.pre[item.id];
  if (s.feeling === undefined) {
    return (
      <section className="card">
        <Bubble who="teacher">Before we start: how do you feel about probability today?</Bubble>
        <div className="chips">
          {FEEL.map((f, i) => (
            <button key={f} className="chip" onClick={() => {
              up((d) => ({ ...d, feeling: i as 0 | 1 | 2 }));
              log("feeling", f);
              say([
                { from: "evaluator", to: "teacher", text: `Note: learner feels "${f.slice(3)}".` },
                ...(i === 0 ? [{ from: "teacher" as AgentId, to: "challenger" as AgentId, text: "Note: anxious learner. Use the gentle version of your challenge." }] : []),
              ]);
            }}>{f}</button>
          ))}
        </div>
      </section>
    );
  }
  const next = () => {
    if (s.preIdx + 1 < PRE.length) { up((d) => ({ ...d, preIdx: d.preIdx + 1 })); return; }
    // explicit diagnosis from the two streak items
    const tags = ["pre1", "pre2"].map((k) => s.pre[k]?.tag).filter((t): t is Mis => t === "M1" || t === "M2");
    const c1 = tags.filter((t) => t === "M1").length, c2 = tags.filter((t) => t === "M2").length;
    const diag: Diag = c1 > c2 ? "M1" : c2 > c1 ? "M2" : ((tags[0] as Diag | undefined) ?? "none");
    const side: "M1" | "M2" = diag === "none" ? "M1" : diag;
    const met = uniq([...s.met, ...Object.values(s.pre).map((x) => x.tag).filter((t): t is Mis => !!t)]);
    up((d) => ({ ...d, diag, side, met }));
    log("pretest_done", { pre: s.pre, diag });
    say([
      { from: "evaluator", to: "teacher", text: `Pre-test: ${Object.values(s.pre).filter((x) => x.correct).length}/3 correct. Diagnosis: ${DIAG[diag].title}.` },
      { from: "teacher", to: "challenger", text: diag === "none" ? "Learner chose 1/2. Argue \"tails is due\" (M1) to test whether that holds up." : `Argue the learner's own idea (${diag}) so they can test it from the outside.` },
    ]);
    go("debate");
  };
  return (
    <section className="card">
      <div className="qhead"><b>Warm-up {s.preIdx + 1} of 3</b><span className="lo">no marks · just your first thoughts</span></div>
      <Bubble who="teacher">{item.story}{item.coins && <Coins seq={item.coins} />}<b>{item.ask}</b></Bubble>
      <Options item={item} value={a?.choice} onPick={(id) => {
        const o = item.options.find((x) => x.id === id)!;
        up((d) => ({ ...d, pre: { ...d.pre, [item.id]: { choice: id, correct: !!o.correct, tag: o.tag, conf: d.pre[item.id]?.conf } } }));
        log("pretest", { item: item.id, choice: id, tag: o.tag ?? "none" });
      }} />
      {a && item.id === "pre1" && (
        <>
          <p className="q">How sure are you?</p>
          <div className="chips">
            {CONF.map((c, i) => <button key={c} className={`chip ${a.conf === i ? "on" : ""}`} onClick={() => up((d) => ({ ...d, pre: { ...d.pre, pre1: { ...d.pre.pre1!, conf: i as 0 | 1 | 2 } } }))}>{c}</button>)}
          </div>
        </>
      )}
      {a && (item.id !== "pre1" || a.conf !== undefined) && (
        <button className="primary" onClick={next}>{s.preIdx + 1 < PRE.length ? "Next →" : "Done. Let's see what the helpers think →"}</button>
      )}
    </section>
  );
}

// ---------------------------------------------------------------- stage 2: the agents disagree
function Debate({ s, go, N }: Props) {
  const [shown, setShown] = useState(1);
  const M2 = s.side === "M2";
  const p1 = PRE[0]!.options.find((o) => o.id === s.pre.pre1?.choice);
  const bold = M2 ? "That coin is on a hot streak! Five heads means heads AGAIN, maybe even for sure." : "Five heads in a row! Things have to balance out, so tails is DUE now. Heads is less likely than 1/2.";
  const gentle = M2 ? "I think that coin is on a lucky streak, so heads again seems more likely than 1/2. But please test me." : "I think after five heads, tails is more likely now, to balance things out. But please test me.";
  const lines: { who: AgentId; text: React.ReactNode; challenge?: boolean; via?: string }[] = [
    {
      who: "evaluator",
      text: s.diag === "none"
        ? `You chose "${p1?.text}". Kabir is going to challenge that. Let's see if your answer survives a real test.`
        : `Your warm-up answers show the idea "${DIAG[s.diag!].title}". Lots of people think this. Kabir agrees with you; Asha doesn't.`,
      via: "using Noor's diagnosis from your warm-up",
    },
    { who: "challenger", challenge: true, text: N.anxious ? gentle : bold, via: N.anxious ? "toned down after Asha's note: learner is anxious" : undefined },
    { who: "teacher", text: "I disagree. For a fair coin, each toss is independent: the coin has no memory. Every toss is a fresh 1/2 heads, 1/2 tails." },
    { who: "evaluator", text: "So two of us disagree. Don't pick whoever sounds more confident. You'll test it: toss a fair coin hundreds of times and check what happens right after 3 heads in a row." },
    { who: "teacher", text: "One note: we're testing fair coin tosses, which are independent. Real-life streaks (like a batsman in form) can involve changing skill. That's a different question." },
  ];
  return (
    <section className="card">
      <h2>The helpers disagree. You'll settle it.</h2>
      {lines.slice(0, shown).map((l, i) => <Bubble key={i} who={l.who} challenge={l.challenge} via={l.via}>{l.text}</Bubble>)}
      {shown < lines.length ? <button className="primary" onClick={() => setShown(shown + 1)}>Next ›</button> : <button className="primary" onClick={() => go("lab")}>Go to the coin lab →</button>}
    </section>
  );
}

// ---------------------------------------------------------------- stage 3: coin lab with sample variation
function Lab({ s, up, say, log, go, N }: Props) {
  const st = useMemo(() => stats(s.lab.seq), [s.lab.seq]);
  const M2 = s.side === "M2";
  const run = (n: number) => {
    const before = stats(s.lab.seq);
    const seq = [...s.lab.seq, ...toss(n)].slice(-30000);
    const after = stats(seq);
    const b: Batch = { tosses: n, cases: after.after3.cases - before.after3.cases, heads: after.after3.heads - before.after3.heads };
    up((d) => ({ ...d, lab: { ...d.lab, seq, batches: [...d.lab.batches, b] } }));
    log("toss_batch", b);
  };
  const p = st.after3.cases ? (st.after3.heads / st.after3.cases) * 100 : 0;
  const band = st.after3.cases ? 98 / Math.sqrt(st.after3.cases) : 0; // ≈95% range for a fair coin, in percentage points
  const lo = Math.max(0, Math.round(50 - band)), hi = Math.min(100, Math.round(50 + band));
  const inRange = Math.abs(p - 50) <= band;
  const enough = st.tosses >= 200 && st.after3.cases >= 15;
  const p100 = Math.round(pRunAtLeast(100, 5) * 100);
  const verdict = s.lab.verdict;
  const choose = (v: "teacher" | "challenger" | "unsure") => {
    const wrong = v === "challenger" ? s.lab.wrongVerdicts + 1 : s.lab.wrongVerdicts;
    up((d) => ({
      ...d,
      lab: { ...d.lab, verdict: v, wrongVerdicts: wrong },
      ...(v === "challenger" ? { diag: d.diag === "none" ? d.side : d.diag, met: uniq([...d.met, d.side ?? "M1"]) as Mis[] } : {}),
      ...(v === "teacher" ? { resolved: uniq([...d.resolved, d.side ?? "M1"]) as Mis[] } : {}),
    }));
    log("verdict", { v, tosses: st.tosses, after3: st.after3 });
    say(
      v === "teacher"
        ? [
            { from: "evaluator", to: "challenger", text: `Learner's evidence: ${Math.round(p)}% heads after HHH over ${st.after3.cases} times (theory 50%, normal range ${lo}–${hi}%). Verdict: Teacher.` },
            { from: "challenger", to: "evaluator", text: "Conceding. I'll say so to the learner, using their data." },
            { from: "evaluator", to: "teacher", text: `Note: lab result ${Math.round(p)}% after HHH. Quote it in practice feedback.` },
          ]
        : [{ from: "evaluator", to: "teacher", text: `Learner chose "${v}" with ${Math.round(p)}% after HHH (wrong verdicts: ${wrong}). ${wrong >= 2 ? "Please walk them through it." : "I'll nudge; not revealing the answer."}` }],
    );
  };
  return (
    <section className="card">
      <h2>🪙 Coin lab</h2>
      <p className="muted">A fair coin, tossed by the computer. Every time <b>H H H</b> appears, we record the <b>very next toss</b>. Run several batches.</p>
      <div className="row">
        <button className="primary" onClick={() => run(10)}>Toss 10</button>
        <button className="primary" onClick={() => run(100)}>Toss 100</button>
        <button className="primary" onClick={() => run(1000)}>Toss 1000</button>
      </div>
      {st.tosses > 0 && (
        <>
          <Coins seq={s.lab.seq.slice(-36).join("")} small />
          <table className="batches">
            <thead><tr><th>Batch</th><th>Tosses</th><th>HHH seen</th><th>Heads next</th></tr></thead>
            <tbody>
              {s.lab.batches.slice(-5).map((b, i, arr) => (
                <tr key={i}><td>{s.lab.batches.length - arr.length + i + 1}</td><td>{b.tosses}</td><td>{b.cases}</td><td>{b.cases ? `${pct(b.heads, b.cases)}%` : "—"}</td></tr>
              ))}
              <tr className="total"><td>All</td><td>{st.tosses}</td><td>{st.after3.cases}</td><td>{st.after3.cases ? `${Math.round(p)}%` : "—"}</td></tr>
            </tbody>
          </table>
          {st.after3.cases > 0 && (
            <div className="key">
              <p>🔎 <b>Your result:</b> after H H H, heads came next <b className="big">{Math.round(p)}%</b> of the time ({st.after3.heads} of {st.after3.cases}).</p>
              <p>📐 <b>Theory for a fair coin:</b> 50% (independent tosses).</p>
              <div className="bar">
                <span className="band" style={{ left: `${lo}%`, width: `${hi - lo}%` }} />
                <i style={{ left: `calc(${Math.min(99, p)}% - 2px)` }} />
                <span className="mid" />
              </div>
              <p className="muted small">Shaded = normal chance range for {st.after3.cases} cases (about {lo}%–{hi}%). Black line = 50%. Blue mark = you.</p>
              <p className="variation">
                {inRange
                  ? `Your ${Math.round(p)}% is inside the normal range: the gap from 50% is just sample variation.`
                  : `Your ${Math.round(p)}% is outside the usual range. That happens about 1 time in 20 by chance; run another batch.`}{" "}
                Small batches jump around (look at the table); with more data the result settles near 50%.
              </p>
              <p className="muted">Kabir predicted {M2 ? "clearly MORE" : "clearly LESS"} than 50%. Asha predicted 50%.</p>
            </div>
          )}
          <p className="muted small">Streaks are normal: the exact chance that 100 tosses contain a run of 5+ heads is <b>{p100}%</b>. So a streak alone isn't "luck".</p>
        </>
      )}
      {!enough && <p className="hint">Toss at least 200 times (several batches) so there are enough H H H moments to judge.</p>}
      {enough && (
        <div className="verdict">
          <p className="q">Who does <b>your</b> evidence support?</p>
          <div className="options">
            <button className={`option ${verdict === "teacher" ? "on" : ""}`} onClick={() => choose("teacher")}>Asha (Teacher): it stays about 1/2</button>
            <button className={`option ${verdict === "challenger" ? "on" : ""}`} onClick={() => choose("challenger")}>Kabir (Challenger): {M2 ? "heads is more likely" : "tails is due"}</button>
            <button className={`option ${verdict === "unsure" ? "on" : ""}`} onClick={() => choose("unsure")}>Not sure yet</button>
          </div>
          {verdict === "teacher" && (
            <>
              <Bubble who="challenger" via="using Noor's note: your lab data">Fair enough. Your data: {Math.round(p)}% heads right after a streak, inside the normal range around 50%. The coin didn't "remember" the streak. I was wrong.</Bubble>
              <Bubble who="teacher"><b>You</b> settled this with evidence. For a fair coin, tosses are <b>independent</b>: the past doesn't change the next toss, so P(heads) stays 1/2.</Bubble>
              <button className="primary" onClick={() => go("practice")}>Next: your personal diagnosis →</button>
            </>
          )}
          {verdict === "challenger" && (
            <>
              <Bubble who="evaluator">Look at the number: after H H H, heads came next <b>{Math.round(p)}%</b> of the time. Kabir said it would be {M2 ? "clearly MORE" : "clearly LESS"} than 50%. Is {Math.round(p)}% outside the shaded normal range? Run another batch and check again.</Bubble>
              {N.wrongVerdicts >= 2 && (
                <>
                  <Bubble who="teacher" via="using Noor's note: second wrong verdict">Let's look together. {Math.round(p)}% sits {inRange ? "inside" : "near"} the range a fair coin gives just by chance. If streaks mattered, it would be far from 50% every batch. So each toss is independent: still 1/2.</Bubble>
                  <button className="primary" onClick={() => { log("verdict_explained"); go("practice"); }}>I see. Next →</button>
                </>
              )}
            </>
          )}
          {verdict === "unsure" && <Bubble who="evaluator">Good instinct: more data makes it clearer. Run another batch of 1000 and watch where the blue mark lands.</Bubble>}
        </div>
      )}
    </section>
  );
}

// ---------------------------------------------------------------- stage 4: diagnosis + practice
function Practice({ s, up, say, log, go, N }: Props) {
  const diag: Diag = s.diag ?? "none";
  const D = DIAG[diag];
  const TASKS = tasksFor(diag);
  const t = TASKS[s.task]!;
  const a: Ans = s.answers[t.id] ?? { attempts: 0, correct: false, hint: false, value: "", done: false };
  const [val, setVal] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { setVal(""); }, [s.task]);
  useEffect(() => {
    if (s.task === 0 && !s.channel.some((m) => m.text.startsWith("Diagnosis →")))
      say([
        { from: "evaluator", to: "teacher", text: `Diagnosis → ${D.title}. Use the ${diag} explanation, example, follow-up and hints.` },
        { from: "teacher", to: "evaluator", text: `Giving the ${diag} explanation now; please check the follow-up for the same misconception.` },
      ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.task]);

  const labLine = N.labPct !== null ? ` In your own lab, heads came right after H H H ${N.labPct}% of the time.` : "";
  const record = (patch: Partial<Ans>, tag?: Mis) => {
    const n: Ans = { ...a, ...patch };
    up((d) => ({
      ...d,
      answers: { ...d.answers, [t.id]: n },
      met: tag ? uniq([...d.met, tag]) : d.met,
      resolved: n.correct && a.tag ? uniq([...d.resolved, a.tag]) : d.resolved,
    }));
    log("answer", { task: t.id, ...patch });
    if (tag) say([{ from: "evaluator", to: "teacher", text: `${t.id}: answer shows ${MIS_NAME[tag]} (try ${n.attempts}). Add the learner's lab data to the feedback.` }]);
  };
  const finish = () => (s.task + 1 < TASKS.length ? up((d) => ({ ...d, task: d.task + 1 })) : go("posttest"));
  const lastTry = a.attempts >= 2 && !a.correct;
  const prevTag = s.task > 0 ? s.answers[TASKS[s.task - 1]!.id]?.tag : undefined;
  const hintExtra = diag === "M1" ? " (Noor's note: you're working on \"tails is due\". The coin doesn't owe anything.)" : diag === "M2" ? " (Noor's note: you're working on \"streaks continue\". A streak guarantees nothing.)" : "";

  return (
    <section className="card">
      {s.task === 0 && (
        <>
          <Bubble who="evaluator"><b>Your diagnosis: {D.title}.</b> {D.what}</Bubble>
          <Bubble who="teacher" via="explanation & example chosen from Noor's diagnosis">{D.explain}<br /><i>Example:</i> {D.example}</Bubble>
        </>
      )}
      {(prevTag === "M1" || prevTag === "M2") && s.task > 0 && !a.attempts && (
        <Bubble who="teacher" via="using Noor's note on your last answer">Quick reminder: {DIAG[prevTag].explain}</Bubble>
      )}
      <div className="qhead"><b>Practice {s.task + 1} of {TASKS.length}</b><span className="lo">{t.lo}</span></div>
      <p className="prompt">{t.prompt}</p>

      {t.kind === "mcq" && (
        <div className="options">
          {t.choices.map((c) => (
            <button key={c.id} disabled={a.done} className={`option ${a.value === c.id ? (c.correct ? "good" : "notyet") : ""}`} onClick={() => {
              const ok = !!c.correct;
              record({ attempts: a.attempts + 1, value: c.id, correct: ok, tag: c.tag ?? a.tag, done: ok || a.attempts + 1 >= 2, fb: c.fb, labFb: !ok && !!c.tag }, c.tag);
            }}>{c.text}</button>
          ))}
        </div>
      )}

      {t.kind === "number" && (
        <form className="row" onSubmit={(e) => {
          e.preventDefault();
          const v = parseProb(val);
          if (v === null) { record({ fb: "Please type a number like 1/4, 0.25 or 25%." }); return; }
          const ok = Math.abs(v - t.answer) < 1e-6;
          const w = t.wrong.find((x) => Math.abs(x.value - v) < 1e-3);
          record({ attempts: a.attempts + 1, value: val, correct: ok, tag: w?.tag ?? a.tag, done: ok || a.attempts + 1 >= 2, fb: ok ? t.correctFb : w?.fb ?? t.otherFb, labFb: !!w?.tag }, w?.tag);
        }}>
          <input inputMode="decimal" aria-label="Your answer" placeholder="e.g. 1/3" value={val} disabled={a.done} onChange={(e) => setVal(e.target.value)} />
          <button className="primary" disabled={a.done || !val.trim()}>Check</button>
        </form>
      )}

      {t.kind === "explain" && (
        <>
          <textarea rows={3} aria-label="Your explanation" placeholder="Type 1–2 sentences…" value={val} disabled={a.done || busy} onChange={(e) => setVal(e.target.value)} />
          <button className="primary" disabled={a.done || busy || val.trim().length < 8} onClick={async () => {
            setBusy(true);
            const v = await evaluateExplanation(val);
            setBusy(false);
            const tag = v.tag === "M1" || v.tag === "M2" ? v.tag : undefined;
            up((d) => ({ ...d, q5: { ...v, text: val } }));
            say([{ from: "evaluator", to: "teacher", text: `Explanation scored ${v.score}/2 by ${v.source === "ai" ? "AI (output verified)" : "rule-based rubric"}${tag ? `; shows ${tag}` : ""}.` }]);
            record({ attempts: a.attempts + 1, value: val, correct: v.score >= 1, tag: tag ?? a.tag, done: v.score === 2 || a.attempts + 1 >= 2, fb: v.feedback, labFb: !!tag }, tag);
          }}>{busy ? "Noor is checking…" : "Send to the Evaluator"}</button>
          {s.q5 && a.attempts > 0 && <p className="muted small">Score {s.q5.score}/2 · checked by {s.q5.source === "ai" ? "AI Evaluator (output verified)" : "rule-based Evaluator"}{s.q5.note ? ` · ${s.q5.note}` : ""}</p>}
        </>
      )}

      {a.fb && a.attempts > 0 && (
        <Bubble who={a.correct ? "evaluator" : "teacher"} via={a.labFb && labLine ? "uses your lab data, shared by Noor" : undefined}>
          {a.correct ? "✅ " : "🌱 Not yet. "}{a.fb}{!a.correct && a.labFb ? labLine : ""}
          {!a.correct && !lastTry && <><br /><b>Try once more.</b></>}
        </Bubble>
      )}
      {a.correct && s.task === 0 && s.pre.pre1?.conf === 0 && <Bubble who="teacher" via="using your warm-up confidence">You felt you were guessing earlier, but you reasoned this correctly. Trust that reasoning.</Bubble>}
      {lastTry && <Bubble who="teacher"><b>Model answer:</b> {t.model} {N.anxious ? "This one trips up most people; you've seen the idea now." : ""}</Bubble>}
      {a.hint && !a.done && <Bubble who="teacher" via={hintExtra ? "hint tailored from Noor's diagnosis" : undefined}>💡 {t.hint}{hintExtra}</Bubble>}
      <div className="row">
        {!a.done && !a.hint && <button className="ghost" onClick={() => record({ hint: true })}>💡 Hint from Asha</button>}
        {a.done && <button className="primary" onClick={finish}>{s.task + 1 < TASKS.length ? "Next →" : "Next: post-test →"}</button>}
      </div>
    </section>
  );
}

// ---------------------------------------------------------------- stage 5: post-test (new scenarios, matched to the pre-test)
function Posttest({ s, up, say, log, go }: Props) {
  const item = POST[s.postIdx]!;
  const a = s.post[item.id];
  const o = a ? item.options.find((x) => x.id === a.choice) : undefined;
  return (
    <section className="card">
      <div className="qhead"><b>Check-out {s.postIdx + 1} of 3</b><span className="lo">new situations · first answer counts</span></div>
      <Bubble who="evaluator">{item.story} <b>{item.ask}</b></Bubble>
      <Options item={item} value={a?.choice} disabled={!!a} mark onPick={(id) => {
        const c = item.options.find((x) => x.id === id)!;
        up((d) => ({ ...d, post: { ...d.post, [item.id]: { choice: id, correct: !!c.correct, tag: c.tag } }, met: c.tag ? uniq([...d.met, c.tag]) : d.met }));
        log("posttest", { item: item.id, choice: id, tag: c.tag ?? "none" });
        if (c.tag) say([{ from: "evaluator", to: "teacher", text: `Post-test ${item.id}: ${MIS_NAME[c.tag]} still present.` }]);
      }} />
      {o && <Bubble who={o.correct ? "evaluator" : "teacher"}>{o.correct ? "✅ " : "🌱 "}{o.fb}</Bubble>}
      {a && (
        <button className="primary" onClick={() => {
          if (s.postIdx + 1 < POST.length) up((d) => ({ ...d, postIdx: d.postIdx + 1 }));
          else {
            const pre = Object.values(s.pre).filter((x) => x.correct).length, post = Object.values(s.post).filter((x) => x.correct).length;
            say([{ from: "evaluator", to: "teacher", text: `Pre-test ${pre}/3 → post-test ${post}/3.` }]);
            go("reflect");
          }
        }}>{s.postIdx + 1 < POST.length ? "Next →" : "Next: reflect →"}</button>
      )}
    </section>
  );
}

// ---------------------------------------------------------------- stage 6: reflect
function Reflect({ s, up, log, go }: Props) {
  return (
    <section className="card">
      <Bubble who="teacher">Last thing. If a friend said "a lucky streak makes the next toss more likely to win", how sure are you that they're wrong?</Bubble>
      <div className="chips">
        {CONF.map((c, i) => <button key={c} className={`chip ${s.endConf === i ? "on" : ""}`} onClick={() => { up((d) => ({ ...d, endConf: i as 0 | 1 | 2 })); log("end_confidence", c); }}>{c}</button>)}
      </div>
      <button className="primary" disabled={s.endConf === undefined} onClick={() => { up((d) => ({ ...d, finished: true })); go("summary"); }}>See my summary →</button>
    </section>
  );
}

// ---------------------------------------------------------------- summary (supporting screen, not timed)
function Summary({ s, onRestart }: { s: S; onRestart: () => void }) {
  const ok = (id: string) => !!s.answers[id]?.correct;
  const pre = Object.values(s.pre).filter((x) => x.correct).length;
  const post = Object.values(s.post).filter((x) => x.correct).length;
  const postTags = Object.values(s.post).map((x) => x.tag).filter(Boolean) as Mis[];
  const preTags = Object.values(s.pre).map((x) => x.tag).filter(Boolean) as Mis[];
  const lo = [
    { id: "LO1", text: "Predict & explain: after a streak the next toss is unchanged", met: !!s.post.post1?.correct && !!s.post.post2?.correct },
    { id: "LO2", text: "Compute & compare probabilities of sequences", met: ok("q2") && !!s.post.post3?.correct },
    { id: "LO3", text: "Use evidence (with sample variation) to settle the disagreement", met: s.lab.verdict === "teacher" && (s.q5?.score ?? 0) >= 1 },
  ];
  const within = s.activeMs <= SESSION_SECONDS * 1000;
  const end = s.endConf ?? 0;
  const calib = end === 2 && post < 3 ? "You feel sure, but the check-out wasn't 3/3 yet. Have a quick look at the idea you missed." : end < 2 && post === 3 ? "You got all 3 check-out questions right but don't feel sure. Your answers show you DO understand this. Trust them." : "Your confidence matches how you did: knowing what you know is a real skill.";
  const download = () => {
    const b = new Blob([JSON.stringify({ id: ID, card: CARD, exportedAt: new Date().toISOString(), session: s }, null, 1)], { type: "application/json" });
    const u = URL.createObjectURL(b);
    const el = document.createElement("a");
    el.href = u; el.download = `lucky-streak-session-${ID}.json`; el.click();
    setTimeout(() => URL.revokeObjectURL(u), 1500);
  };
  return (
    <section className="card">
      <h1>Your session summary</h1>
      <p className={`c4 ${within ? "good" : ""}`}>⏱ Six stages completed in <b>{mmss(s.activeMs)}</b> of 10:00 {within ? "✓ within one 10-minute session" : "(a little over; that's fine)"}</p>
      <div className="prepost">
        <div><small>Warm-up (before)</small><b>{pre}/3</b></div>
        <span>→</span>
        <div><small>Check-out (after, new situations)</small><b>{post}/3</b></div>
      </div>
      <p className="muted">Streak ideas: {preTags.length ? uniq(preTags).join(", ") : "none"} before → {postTags.length ? uniq(postTags).join(", ") : "none"} after.</p>
      <h3>What you can now do</h3>
      <ul className="lo">{lo.map((x) => <li key={x.id} className={x.met ? "good" : "notyet"}><b>{x.id}</b> {x.met ? "✓" : "· not yet"} {x.text}</li>)}</ul>
      <h3>Your thinking</h3>
      <p>Diagnosis: <b>{DIAG[s.diag ?? "none"].title}</b>. {DIAG[s.diag ?? "none"].what}</p>
      {s.lab.verdict === "teacher" && <p>Disagreement: <b>you</b> settled Asha vs Kabir with {stats(s.lab.seq).tosses} tosses; Kabir conceded.</p>}
      <p>Confidence: <b>{CONF[s.pre.pre1?.conf ?? 0]}</b> at the start → <b>{CONF[end]}</b> now. {calib}</p>
      <Bubble who="evaluator">{lo.every((x) => x.met) ? "Next time: try the same idea with a spinner or dice. Same rule: independent events." : "Next session: start again; your answers will help Asha focus on what's still tricky."}</Bubble>
      <div className="row">
        <button className="ghost" onClick={download}>⬇ Download my session log</button>
        <button className="primary" onClick={onRestart}>Start a new session</button>
      </div>
    </section>
  );
}

function About({ onBack }: { onBack: () => void }) {
  return (
    <section className="card">
      <h1>About this app</h1>
      <table className="idcard"><tbody>
        <tr><th>Identity token</th><td><b>{ID}</b></td></tr>
        <tr><th>Problem</th><td>P3 · Multi-agent collaborative learning</td></tr>
        <tr><th>Topic</th><td>T6 · Probability: is a "lucky streak" real? (Class 9–10)</td></tr>
        <tr><th>Learner</th><td>L5 · Anxious learner repeating the topic after failing once</td></tr>
        <tr><th>Constraint</th><td>C4 · 10-minute sessions: six timed stages = 10:00; pause &amp; resume</td></tr>
      </tbody></table>
      <h3>The three agents</h3>
      <ul>
        <li><b>Asha (Teacher)</b>: explains, gives hints and model answers. Her explanation, example and hints are chosen from Noor's diagnosis.</li>
        <li><b>Kabir (Challenger)</b>: argues your own warm-up idea, always labelled as a challenge. He softens his tone when Asha notes you're anxious, and concedes using your lab data.</li>
        <li><b>Noor (Evaluator)</b>: diagnoses the gambler's fallacy vs the winning-streak belief, moderates the disagreement and checks your explanation.</li>
      </ul>
      <p>They share one notes board; open the <b>Agent channel</b> under any stage to see the notes and messages, and look for "↳ using … note" on messages they influenced.</p>
      <h3>Scope</h3>
      <p>The streak claim is tested for <b>independent tosses of a fair coin or die</b>. Real-life streaks (for example in sport) can involve changing skill, which is a different question.</p>
      <h3>AI use &amp; honesty</h3>
      <p>Your written explanation is scored by an AI model through a server function. Its output is checked (format, banned claims, cross-check with a rubric) before you see it; if the AI fails, a clearly labelled rule-based Evaluator is used. All maths (simulation, normal range, streak probabilities) is computed in code. Built with the Vite React-TS starter template and no UI library; AI assistance is disclosed in the report.</p>
      <button className="primary" onClick={onBack}>← Back</button>
    </section>
  );
}

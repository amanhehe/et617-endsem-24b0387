import { useEffect, useMemo, useRef, useState } from "react";
import "./App.css";
import { AGENTS, CARD, DIAG, EXTRA, ID, MIS_NAME, POST, PRE, SESSION_SECONDS, STEPS, TASKS as BASE_TASKS, type AgentId, type Task, type Diag, type Mis, type Step, type TestItem } from "./lib/content";
import { afterPattern, parseProb, PATTERNS, pct, pRunAtLeast, stats, toss, type Side } from "./lib/prob";
import { CONCEPTS, evaluateTeachBack, type ConceptId, type TeachBack, type Verdict } from "./lib/evaluator";
import { runPipeline, type Ctx, type PipeResult } from "./lib/pipeline";
import { canListen, canSpeak, listen, speak, stopSpeaking } from "./lib/voice";
import { LESSON } from "./lib/content";
import { askAsha, judgeReply, type AshaReply, type Judgement } from "./lib/asha";

// ---------------------------------------------------------------- state (saved to this device after every change)
type Msg = { from: AgentId; to: AgentId; text: string; at: number };
type Ans = { attempts: number; correct: boolean; hint: boolean; value: string; tag?: Mis; done: boolean; fb?: string; labFb?: boolean };
type TestAns = { choice: string; correct: boolean; tag?: Mis; conf?: 0 | 1 | 2 };
type Batch = { tosses: number; cases: number; heads: number };
type Ev = { t: number; step: Step; type: string; data?: unknown };
export type S = {
  v: 2;
  step: Step;
  started: boolean;
  finished: boolean;
  paused: boolean;
  activeMs: number;
  stepMs: Partial<Record<Step, number>>;
  feeling?: 0 | 1 | 2;
  pre: Record<string, TestAns>;
  preIdx: number;
  side?: "M1" | "M2"; // the idea the Challenger argues (taken from the learner's pre-test)
  diag?: Diag; // explicit diagnosis: selects explanation, example, follow-up and hints
  met: Mis[];
  resolved: Mis[];
  lab: { seq: Side[]; batches: Batch[]; verdict?: "teacher" | "challenger" | "unsure"; wrongVerdicts: number };
  task: number;
  answers: Record<string, Ans>;
  q5?: Verdict & { text: string };
  post: Record<string, TestAns>;
  postIdx: number;
  endConf?: 0 | 1 | 2;
  voice?: boolean; // read agents' lines aloud
  maxStage?: number; // furthest stage reached (unlocks cards on the home dashboard)
  skipped?: Step[];
  lessonAns?: Record<number, { choice: string; right: boolean }>;
  asks?: { stage: Step; q: string; reply: AshaReply; answer?: string; judge?: Judgement }[];
  channel: Msg[];
  log: Ev[];
};
const KEY = `et617-${ID}-lucky-streak-v2`;
const fresh = (): S => ({
  v: 2, step: "welcome", started: false, finished: false, paused: false, activeMs: 0, stepMs: {},
  pre: {}, preIdx: 0, met: [], resolved: [], lab: { seq: [], batches: [], wrongVerdicts: 0 },
  task: 0, answers: {}, post: {}, postIdx: 0, channel: [], log: [],
});
function load(): S | null {
  try {
    const s = JSON.parse(localStorage.getItem(KEY) ?? "null");
    return s && s.v === 2 ? (s as S) : null;
  } catch {
    return null;
  }
}
const mmss = (ms: number) => {
  const s = Math.max(0, Math.round(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
};
const FEEL = ["😟 Worried", "😐 Unsure", "🙂 Okay"];
const CONF = ["Guessing", "Fairly sure", "Sure"];
const uniq = <T,>(a: T[]) => [...new Set(a)];

/** The shared notes board every agent reads before it speaks. */
function notes(s: S) {
  const st = stats(s.lab.seq);
  const hints = Object.values(s.answers).filter((a) => a.hint).length;
  return {
    anxious: s.feeling === 0 || s.pre.pre1?.conf === 0,
    feeling: s.feeling === undefined ? "—" : FEEL[s.feeling]!.slice(3),
    diag: s.diag,
    labPct: st.after3.cases ? pct(st.after3.heads, st.after3.cases) : null,
    labCases: st.after3.cases,
    wrongVerdicts: s.lab.wrongVerdicts,
    hints,
  };
}
type Notes = ReturnType<typeof notes>;

/** Asha's memory of this session: earlier mistakes, questions, confidence and lab results. */
function memory(s: S) {
  const wrongPre = PRE.filter((it) => s.pre[it.id] && !s.pre[it.id]!.correct).map((it) => it.options.find((o) => o.id === s.pre[it.id]!.choice)!.text);
  const lessonWrong = LESSON.map((L, i) => ({ L, a: s.lessonAns?.[i] })).filter((x) => x.a && !x.a.right).map((x) => `"${x.a!.choice}" (${x.L.title})`);
  const st = stats(s.lab.seq);
  const lab = st.after3.cases ? `${pct(st.after3.heads, st.after3.cases)}% heads right after H H H in ${st.tosses} tosses` : null;
  const asked = (s.asks ?? []).map((a) => a.q);
  const conf = s.pre.pre1?.conf !== undefined ? CONF[s.pre.pre1.conf]! : null;
  const feeling = s.feeling !== undefined ? FEEL[s.feeling]!.slice(3).toLowerCase() : null;
  const pre1 = PRE[2]!.options.find((o) => o.id === s.pre.pre1?.choice)?.text ?? null;
  return { wrongPre, lessonWrong, lab, asked, conf, feeling, pre1, wrongVerdicts: s.lab.wrongVerdicts };
}
type Memory = ReturnType<typeof memory>;
/** One short "remember when…" line, chosen for where we are now. */
function recall(m: Memory, at: "debate" | "lab" | "practice" | "ask"): string | null {
  if (at === "debate" && m.lessonWrong.length) return `In the lesson you predicted ${m.lessonWrong[0]}. Let's see if Kabir agrees with you.`;
  if (at === "lab" && m.pre1) return `Remember your very first answer today: "${m.pre1}"${m.conf ? `, and you felt ${m.conf.toLowerCase()}` : ""}. ${m.lab ? `Now your own data says: ${m.lab}.` : ""}`;
  if (at === "practice") {
    const bits = [m.pre1 && `you first said "${m.pre1}"`, m.lab && `your lab showed ${m.lab}`, m.wrongVerdicts ? `you sided with Kabir ${m.wrongVerdicts === 1 ? "once" : "twice"} before changing your mind` : null, m.asked.length ? `you asked me "${m.asked[0]}"` : null].filter(Boolean);
    return bits.length ? `Earlier today ${bits.join(", ")}. Let's build on that.` : null;
  }
  if (at === "ask" && m.asked.length) return `You asked earlier: "${m.asked[m.asked.length - 1]}".`;
  return null;
}

/**
 * Adaptive planner. The practice path is built from the learner model, not fixed:
 *  - revisit:  follow-up needed a hint / >1 try, or the learner was SURE but wrong in the warm-up → same misconception, new context
 *  - easier:   a basics item was wrong in the diagnostic → prerequisite "list the outcomes" before multiplying
 *  - harder:   no misconception + basics & sequences right + confident → P(HHH) = 1/8 instead of P(HH) = 1/4
 *  - evidence: the lab verdict went wrong at least once → re-read evidence with sample variation
 * Items already answered keep their place, so the path only grows forward.
 */
function plan(s: S): { tasks: Task[]; why: Record<string, string> } {
  const diag: Diag = s.diag ?? "none";
  const why: Record<string, string> = {};
  const tasks: Task[] = [DIAG[diag].followup];
  why.f1 = diag === "none" ? "No streak misconception showed up, so you get a stretch question." : `Chosen for your diagnosis: ${DIAG[diag].title}.`;
  const f1 = s.answers.f1;
  const overSure = s.pre.pre1?.conf === 2 && !s.pre.pre1?.correct;
  if (diag !== "none" && ((f1?.done && (f1.attempts > 1 || f1.hint || !f1.correct)) || (f1?.done && overSure))) {
    tasks.push(EXTRA[`r1-${diag}`]!);
    why.r1 = f1 && (f1.attempts > 1 || f1.hint || !f1.correct) ? `Revisiting ${DIAG[diag].title}: the follow-up needed ${f1.hint ? "a hint" : "more than one try"}, so here it is again in a new situation.` : `Revisiting ${DIAG[diag].title}: in the warm-up you were "Sure" but chose a streak answer.`;
  }
  const basicsWeak = !s.pre.k1?.correct || !s.pre.k2?.correct;
  if (basicsWeak) { tasks.push(EXTRA.e1!); why.e1 = "A step back first: your warm-up showed a gap in listing outcomes, which you need before multiplying."; }
  const strong = diag === "none" && !!s.pre.k2?.correct && !!s.pre.pre3?.correct && (s.pre.pre1?.conf ?? 0) >= 1;
  const q2 = BASE_TASKS.find((t) => t.id === "q2")!;
  if (strong) { tasks.push(EXTRA.q2h!); why.q2h = "Level up: your basics and sequence answers were right and you felt confident, so this one is harder (3 tosses)."; }
  else tasks.push(q2);
  if (s.lab.wrongVerdicts > 0) { tasks.push(EXTRA.lab1!); why.lab1 = "Your lab verdict went the other way at first, so let's read some evidence together once more."; }
  tasks.push(BASE_TASKS.find((t) => t.id === "q5")!);
  why.q5 = "Finally, teach the idea back in your own words.";
  return { tasks, why };
}

export default function App() {
  const [s, setS] = useState<S>(() => load() ?? fresh());
  const [welcomeBack, setWelcomeBack] = useState(true); // the home dashboard; opens on every visit
  const [about, setAbout] = useState(false);
  const [evalOpen, setEvalOpen] = useState(false);
  const sRef = useRef(s);
  sRef.current = s;
  const supporting = useRef(false);
  supporting.current = about || welcomeBack || evalOpen;
  const save = (n: S) => {
    try {
      localStorage.setItem(KEY, JSON.stringify(n));
    } catch {
      /* storage full: the session still works */
    }
  };
  const up = (f: (d: S) => S) => setS((p) => { const n = f(p); save(n); return n; });
  const log = (type: string, data?: unknown) => up((d) => ({ ...d, log: [...d.log, { t: Date.now(), step: d.step, type, data }].slice(-600) }));
  const say = (msgs: Omit<Msg, "at">[]) => up((d) => ({ ...d, channel: [...d.channel, ...msgs.map((m) => ({ ...m, at: Date.now() }))] }));
  const go = (step: Step) => up((d) => ({ ...d, step, maxStage: Math.max(d.maxStage ?? -1, STEPS.findIndex((x) => x.id === step)), log: [...d.log, { t: Date.now(), step, type: "enter_stage" }] }));

  // the 10-minute clock: ACTIVE time in the six timed stages only (not while paused, on supporting screens, or in a hidden tab)
  useEffect(() => {
    const id = window.setInterval(() => {
      const d = sRef.current;
      if (d.paused || d.finished || !d.started || supporting.current || document.visibilityState !== "visible") return;
      if (!STEPS.some((x) => x.id === d.step)) return;
      up((x) => ({ ...x, activeMs: x.activeMs + 1000, stepMs: { ...x.stepMs, [x.step]: (x.stepMs[x.step] ?? 0) + 1000 } }));
    }, 1000);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pause = () => { up((d) => ({ ...d, paused: true })); log("pause"); };
  const resume = () => { setWelcomeBack(false); up((d) => ({ ...d, paused: false })); log("resume"); };
  const restart = () => { const n = fresh(); save(n); setS(n); setWelcomeBack(false); };

  const N = notes(s);
  const idx = STEPS.findIndex((x) => x.id === s.step);
  const timed = idx >= 0 && !about && !welcomeBack && !s.paused;
  const P = { s, up, say, log, go, N };

  return (
    <div className="app">
      <header className="top">
        <div className="brand">🪙 <b>Lucky Streak?</b> <small>probability with 3 AI helpers</small></div>
        {s.started && !s.finished && !welcomeBack && (
          <div className="session" aria-label="10-minute session">
            <div className="clock">
              <span>⏱ {mmss(s.activeMs)} <small>of 10:00 {timed ? "" : "· clock stopped"}</small></span>
              <span className="row">
                {canSpeak() && <button className="ghost" aria-pressed={s.voice !== false} onClick={() => { if (s.voice !== false) stopSpeaking(); up((d) => ({ ...d, voice: d.voice === false })); }}>{s.voice !== false ? "🔊 Voice on" : "🔇 Voice off"}</button>}
                {timed && <button className="ghost" onClick={() => { stopSpeaking(); setWelcomeBack(true); log("home"); }}>🏠 Home</button>}
                {timed && <button className="ghost" title="Skip this stage (e.g. if you've done it before)" onClick={() => {
                  stopSpeaking();
                  const i = STEPS.findIndex((x) => x.id === s.step);
                  log("skip_stage", s.step);
                  up((d) => ({ ...d, skipped: uniq([...(d.skipped ?? []), d.step]) }));
                  if (i + 1 < STEPS.length) go(STEPS[i + 1]!.id); else { up((d) => ({ ...d, finished: true })); go("summary"); }
                }}>⏭ Skip</button>}
                {timed && <button className="ghost" onClick={pause}>⏸ Pause &amp; save</button>}
              </span>
            </div>
            <ol className="steps">
              {STEPS.map((x, i) => (
                <li key={x.id} className={i < idx ? "done" : i === idx ? "now" : ""}>
                  <span>{x.label}</span>
                  <i>{mmss(x.budget * 1000)}</i>
                </li>
              ))}
            </ol>
            {timed && (
              <p className="calm">
                {s.activeMs / 1000 > SESSION_SECONDS
                  ? "A little over 10 minutes. That's fine, finish calmly."
                  : `Stage ${idx + 1} of 6 · about ${Math.max(1, Math.round((SESSION_SECONDS - s.activeMs / 1000) / 60))} min left · no rush, nothing is graded`}
              </p>
            )}
          </div>
        )}
      </header>

      <main>
        {about ? (
          <About onBack={() => setAbout(false)} />
        ) : evalOpen ? (
          <Evaluation s={s} onBack={() => setEvalOpen(false)} />
        ) : welcomeBack ? (
          <Home s={s}
            onStart={() => { setWelcomeBack(false); up((d) => ({ ...d, started: true, paused: false })); go("pretest"); }}
            onContinue={resume}
            onOpen={(st) => { setWelcomeBack(false); up((d) => ({ ...d, paused: false })); go(st); }}
            onRestart={restart} onAbout={() => setAbout(true)} onEval={() => setEvalOpen(true)} />
        ) : s.paused ? (
          <Paused s={s} onResume={resume} />
        ) : s.step === "welcome" ? (
          <Welcome returning={false} s={s} onStart={() => { up((d) => ({ ...d, started: true })); go("pretest"); }} onContinue={resume} onRestart={restart} onAbout={() => setAbout(true)} />
        ) : s.step === "pretest" ? (
          <Pretest {...P} />
        ) : s.step === "debate" ? (
          <Debate {...P} />
        ) : s.step === "lab" ? (
          <Lab {...P} />
        ) : s.step === "practice" ? (
          <Practice {...P} />
        ) : s.step === "posttest" ? (
          <Posttest {...P} />
        ) : s.step === "reflect" ? (
          <Reflect {...P} />
        ) : (
          <Summary s={s} onRestart={restart} onHome={() => setWelcomeBack(true)} onEval={() => setEvalOpen(true)} />
        )}
        {timed && <AskAsha {...P} />}
        {s.started && !about && !welcomeBack && s.step !== "welcome" && <Channel s={s} N={N} />}
      </main>

      <footer>
        ET 617 End-Sem · ID <b>{ID}</b> · {CARD} · <button className="link" onClick={() => setAbout(true)}>About</button>
      </footer>
    </div>
  );
}

// ---------------------------------------------------------------- shared bits
type Up = (f: (d: S) => S) => void;
type Props = { s: S; up: Up; say: (m: Omit<Msg, "at">[]) => void; log: (t: string, d?: unknown) => void; go: (s: Step) => void; N: Notes };

function Bubble({ who, children, challenge, via }: { who: AgentId; children: React.ReactNode; challenge?: boolean; via?: string }) {
  const a = AGENTS[who];
  const ref = useRef<HTMLDivElement>(null);
  return (
    <div className={`bubble ${who}`}>
      <div className="who">
        <span className={`dot ${who}`} /> {a.name} <small>· {a.role}</small>
        {canSpeak() && <button className="listen" aria-label={`Listen to ${a.name}`} onClick={() => { stopSpeaking(); speak(ref.current?.innerText ?? "", who); }}>🔊</button>}
        {challenge && <em className="tag">CHALLENGE: test me, I might be wrong</em>}
      </div>
      <div className="say" ref={ref}>{children}</div>
      {via && <div className="via">↳ {via}</div>}
    </div>
  );
}

function Channel({ s, N }: { s: S; N: Notes }) {
  return (
    <details className="channel">
      <summary>🔁 Agent channel: shared notes &amp; messages ({s.channel.length})</summary>
      <p className="notes">
        <b>Shared notes:</b> feeling {N.feeling}{N.anxious ? " (anxious → gentle mode)" : ""} · diagnosis {N.diag ? DIAG[N.diag].title : "—"} · lab {N.labPct === null ? "—" : `${N.labPct}% heads after HHH (${N.labCases} times)`} · wrong verdicts {N.wrongVerdicts} · hints used {N.hints}
      </p>
      <ul>
        {s.channel.map((m, i) => (
          <li key={i}><b className={m.from}>{AGENTS[m.from].role}</b> → <b className={m.to}>{AGENTS[m.to].role}</b>: {m.text}</li>
        ))}
      </ul>
    </details>
  );
}

function Options({ item, value, onPick, disabled, mark }: { item: TestItem; value?: string; onPick: (id: string) => void; disabled?: boolean; mark?: boolean }) {
  return (
    <div className="options">
      {item.options.map((o) => (
        <button key={o.id} disabled={disabled} className={`option ${value === o.id ? (mark ? (o.correct ? "good" : "notyet") : "on") : ""}`} onClick={() => onPick(o.id)}>{o.text}</button>
      ))}
    </div>
  );
}

function Coins({ seq, small }: { seq: string; small?: boolean }) {
  return <div className={`coins ${small ? "small" : ""}`}>{seq.split("").map((c, i) => <span key={i} className={`coin ${c === "H" ? "h" : "t"}`}>{c}</span>)}</div>;
}

// ---------------------------------------------------------------- Ask Asha (any time): question, confusion or reasoning, by voice or text
function AskAsha({ s, up, log, say, N }: Props) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const stopRef = useRef<(() => void) | null>(null);
  const asks = s.asks ?? [];
  const cur = asks[asks.length - 1];
  const awaitingReply = cur && cur.answer === undefined;
  const ctx = { stage: s.step, diag: s.diag ?? "none", labPct: N.labPct, anxious: N.anxious, memory: memory(s) } as Parameters<typeof askAsha>[1];
  const mic = (set: (t: string) => void) => {
    if (listening) { stopRef.current?.(); return; }
    setListening(true);
    stopRef.current = listen((t) => set(t), () => setListening(false));
  };
  const send = async () => {
    const q = text.trim();
    if (!q) return;
    setBusy(true);
    if (awaitingReply) {
      const j = await judgeReply(cur.reply.followup, q, cur.reply.concept, ctx);
      up((d) => ({ ...d, asks: (d.asks ?? []).map((x, i, arr) => (i === arr.length - 1 ? { ...x, answer: q, judge: j } : x)) }));
      log("ask_followup_reply", { reply: q, understood: j.understood, source: j.source });
      say([{ from: "teacher", to: "evaluator", text: `Follow-up on "${cur.reply.concept}": ${j.understood ? "she reasoned it correctly" : "not yet; guiding again"} (${j.source === "ai" ? "AI judgement" : "concept check"}).` }]);
      if (s.voice !== false) speak(j.feedback, "teacher");
    } else {
      const r = await askAsha(q, ctx);
      up((d) => ({ ...d, asks: [...(d.asks ?? []), { stage: d.step, q, reply: r }] }));
      log("ask", { q, concept: r.concept, source: r.source });
      say([{ from: "teacher", to: "evaluator", text: `She asked: "${q.slice(0, 60)}". Answered about ${r.concept}; asked a follow-up to check understanding.` }]);
      if (s.voice !== false) { speak(r.answer, "teacher"); speak(r.followup, "teacher"); }
    }
    setText("");
    setBusy(false);
  };
  return (
    <div className="ask">
      {!open ? (
        <button className="ask-open" onClick={() => setOpen(true)}>✋ Ask Asha a doubt · 🎤 or type · any time</button>
      ) : (
        <div className="ask-box">
          <div className="qhead"><b>✋ Talk to Asha</b><button className="link" onClick={() => setOpen(false)}>close</button></div>
          {cur && (
            <>
              <p className="attempt"><b>You:</b> "{cur.q}"</p>
              <Bubble who="teacher" via={cur.reply.source === "ai" ? "AI answer, numbers checked by Noor" : "from Asha's verified notes"}>{recall(memory(s), "ask") && asks.length > 1 ? <i>{recall(memory(s), "ask")} </i> : null}{cur.reply.answer}<br /><b>{cur.reply.followup}</b></Bubble>
              {cur.answer !== undefined && (
                <>
                  <p className="attempt"><b>You:</b> "{cur.answer}"</p>
                  <Bubble who="teacher" via={cur.judge?.source === "ai" ? "understanding judged by AI" : "concept check"}>{cur.judge?.understood ? "✅ " : "🌱 "}{cur.judge?.feedback}</Bubble>
                </>
              )}
            </>
          )}
          {!cur || cur.answer !== undefined ? (
            <div className="chips">
              {["I'm confused", "Why doesn't the streak matter?", "Isn't tails due after many heads?", "Why isn't my lab exactly 50%?", "How do I get 1/4 for two tosses?"].map((c) => <button key={c} className="chip" onClick={() => setText(c)}>{c}</button>)}
            </div>
          ) : null}
          <div className="row">
            <input aria-label="Talk to Asha" placeholder={awaitingReply ? "Answer Asha's question (or tap 🎤)…" : "Ask, or explain your thinking…"} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && void send()} />
            {canListen() && <button className={`ghost mic ${listening ? "on" : ""}`} aria-label="Speak to Asha" onClick={() => mic(setText)}>{listening ? "⏹" : "🎤"}</button>}
            <button className="primary" disabled={busy || !text.trim()} onClick={() => void send()}>{busy ? "…" : awaitingReply ? "Reply" : "Ask"}</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- home dashboard: the learning journey (a supporting screen, not timed)
const CARDS: { group: string; stage: Step; icon: string; title: string; desc: string; lessonPart?: "lesson" | "debate" }[] = [
  { group: "Learn", stage: "pretest", icon: "🧭", title: "Where am I starting?", desc: "A quick check-in and 5 warm-up questions that show what you already know." },
  { group: "Learn", stage: "debate", icon: "👩‍🏫", title: "Asha's lesson: no memory", desc: "Short teaching segments with coin pictures; you predict, Asha adapts.", lessonPart: "lesson" },
  { group: "Classroom Discussion", stage: "debate", icon: "🗣️", title: "Is tails due? The class disagrees", desc: "Kabir challenges, Asha disagrees; you'll be the judge.", lessonPart: "debate" },
  { group: "Explore", stage: "lab", icon: "🪙", title: "Coin lab", desc: "Toss thousands of coins and test what happens right after a streak." },
  { group: "Practice", stage: "practice", icon: "✍️", title: "Practice + teach-back", desc: "Questions chosen for you, then explain it in your own words, typed or spoken." },
  { group: "Practice", stage: "posttest", icon: "🎯", title: "Check-out", desc: "Three new situations to see how your thinking changed." },
  { group: "Practice", stage: "reflect", icon: "🌱", title: "Reflect", desc: "How sure do you feel now? Then see your session story." },
];
function Home({ s, onStart, onContinue, onOpen, onRestart, onAbout, onEval }: { s: S; onStart: () => void; onContinue: () => void; onOpen: (st: Step) => void; onRestart: () => void; onAbout: () => void; onEval: () => void }) {
  const reached = s.started ? (s.maxStage ?? 0) : -1;
  const done = s.finished ? STEPS.length : Math.max(0, reached);
  const cur = STEPS.findIndex((x) => x.id === s.step);
  const lessonDone = Object.keys(s.lessonAns ?? {}).length >= LESSON.length;
  const status = (c: (typeof CARDS)[number]) => {
    const i = STEPS.findIndex((x) => x.id === c.stage);
    if ((s.skipped ?? []).includes(c.stage) && i !== cur) return "skipped";
    if (s.finished || i < cur) return "done";
    if (c.lessonPart === "lesson" && i === cur && lessonDone) return "done";
    if (c.lessonPart === "debate" && i === cur && !lessonDone) return "locked";
    if (s.started && i === cur) return "now";
    if ((s.skipped ?? []).includes(c.stage)) return "skipped";
    return i <= reached ? "done" : s.started ? "open" : "locked";
  };
  const groups = ["Learn", "Classroom Discussion", "Explore", "Practice"];
  return (
    <section className="home">
      <div className="card">
        <h1>{s.started && !s.finished ? "Welcome back 👋" : "Is a \"lucky streak\" real?"}</h1>
        {!s.started && <p>You've met probability before, and maybe it didn't go well. <b>That's okay.</b> This time Asha, Kabir and Noor will learn it <b>with</b> you: we'll test ideas with real coin tosses, and you decide what's true.</p>}
        <div className="journey-bar"><i style={{ width: `${(done / STEPS.length) * 100}%` }} /></div>
        <p className="muted">{s.finished ? "Session complete" : s.started ? `Stage ${cur + 1} of 6 · ${mmss(s.activeMs)} of 10:00 used` : "One session · 6 short stages · 10 minutes · pause any time"}</p>
        <div className="row">
          {!s.started && <button className="primary" onClick={onStart}>Start my 10-minute session</button>}
          {s.started && !s.finished && <><p className="resume">Your place is saved. You were on <b>Stage {cur + 1}: {STEPS[cur]?.label}</b>.</p><button className="primary" onClick={onContinue}>Continue where I stopped</button><button className="ghost" onClick={onRestart}>Start over</button></>}
          {s.finished && <><button className="primary" onClick={() => onOpen("summary")}>See my session story</button><button className="ghost" onClick={onRestart}>Start a new session</button></>}
          {s.started && <button className="ghost" onClick={onEval}>📊 My evaluation</button>}
          <button className="ghost" onClick={onAbout}>About</button>
        </div>
      </div>
      {groups.map((g) => (
        <div key={g} className="group">
          <h3>{g}</h3>
          <div className="cards">
            {CARDS.filter((c) => c.group === g).map((c) => {
              const st = status(c);
              const i = STEPS.findIndex((x) => x.id === c.stage);
              return (
                <button key={c.title} className={`lcard ${st}`} disabled={st === "locked"} onClick={() => (st === "now" ? onContinue() : onOpen(c.stage))}>
                  <span className="lc-icon">{c.icon}</span>
                  <span className="lc-body"><b>{c.title}</b><small>{c.desc}</small></span>
                  <span className="lc-meta">{st === "done" ? "✓" : st === "now" ? "▶" : st === "skipped" ? "⏭" : st === "open" ? "›" : "🔒"}<small>{mmss(STEPS[i]!.budget * 1000)}</small></span>
                </button>
              );
            })}
          </div>
        </div>
      ))}
      <p className="muted small center">The 6 stages add up to exactly 10:00. Follow the journey in order, or, if you've been here before, open any card or ⏭ Skip a stage to revisit just what you need.</p>
    </section>
  );
}

// ---------------------------------------------------------------- evaluation: marks, what was right/wrong, feedback, misconception status
type Row = { what: string; your: string; correct: string; marks: number; of: number; feedback: string; tag?: Mis };
function Evaluation({ s, onBack }: { s: S; onBack: () => void }) {
  const sec: { name: string; why: string; rows: Row[] }[] = [];
  // 1. diagnostic
  sec.push({ name: "1 · Diagnostic warm-up", why: "What you knew at the start (not graded during the session).", rows: PRE.map((it) => {
    const a = s.pre[it.id]; const o = it.options.find((x) => x.id === a?.choice); const c = it.options.find((x) => x.correct)!;
    return { what: `${it.story} ${it.ask}`, your: o?.text ?? "skipped", correct: c.text, marks: a?.correct ? 1 : 0, of: 1, feedback: o ? o.fb : "Not answered.", tag: o?.tag };
  }) });
  // 2. lesson predictions
  sec.push({ name: "2 · Lesson predictions", why: "Thinking before being told.", rows: LESSON.map((L, i) => {
    const a = s.lessonAns?.[i]; const c = L.predict.options.find((x) => x.right)!;
    return { what: L.predict.ask, your: a?.choice ?? "skipped", correct: c.text, marks: a?.right ? 1 : 0, of: 1, feedback: a ? (a.right ? L.predict.ifRight : L.predict.ifWrong) : "Not answered." };
  }) });
  // 3. lab
  const st = stats(s.lab.seq);
  const lv = s.lab.verdict === "teacher" ? (s.lab.wrongVerdicts ? 1 : 2) : 0;
  sec.push({ name: "3 · Coin lab: using evidence", why: "Did you judge the claim from the data?", rows: [{
    what: "Who did your evidence support: Asha (stays 1/2) or Kabir (streak changes it)?",
    your: s.lab.verdict ? `${s.lab.verdict === "teacher" ? "Asha" : s.lab.verdict === "challenger" ? "Kabir" : "Not sure"}${s.lab.wrongVerdicts ? ` (after ${s.lab.wrongVerdicts} wrong verdict${s.lab.wrongVerdicts > 1 ? "s" : ""})` : ""}` : "skipped",
    correct: `Asha: your data showed ${st.after3.cases ? pct(st.after3.heads, st.after3.cases) : "—"}% heads after H H H, close to 50%`,
    marks: lv, of: 2,
    feedback: lv === 2 ? "You read the evidence correctly first time." : lv === 1 ? "You got there after looking again. Next time, compare the % with the shaded normal range first." : "Look at the % after H H H: if it's inside the normal range around 50%, the streak changed nothing.",
    tag: s.lab.wrongVerdicts ? s.side : undefined,
  }] });
  // 4. practice (2 marks first try, 1 with a hint or second try)
  const tasks = plan(s).tasks.filter((t) => t.kind !== "explain");
  sec.push({ name: "4 · Practice", why: "2 marks first try, 1 mark with a hint or on the second try.", rows: tasks.map((t) => {
    const a = s.answers[t.id];
    const m = !a ? 0 : a.correct ? (a.attempts === 1 && !a.hint ? 2 : 1) : 0;
    const shown = !a ? "skipped" : t.kind === "mcq" ? t.choices.find((c) => c.id === a.value)?.text ?? a.value : a.value;
    return { what: t.prompt, your: shown, correct: t.model, marks: m, of: 2, feedback: a?.fb ?? "Not answered.", tag: a?.tag };
  }) });
  // 5. teach-back
  const tb = s.answers.q5;
  const n = tb ? Number(String(tb.value).split("/")[0]) || 0 : 0;
  sec.push({ name: "5 · Teach-back (your own words)", why: "1 mark for each idea: no memory · still 1/2 · so the streak changes nothing.", rows: [{
    what: "Explain why \"my luck has to turn\" is wrong.", your: tb ? `${n} of 3 ideas included` : "skipped", correct: "Each toss is independent (no memory), so the chance is still 1/2; losing 5 times doesn't make a win due.",
    marks: n, of: 3, feedback: n === 3 ? "All three ideas, in your own words." : `Missing ${3 - n} idea${3 - n === 1 ? "" : "s"}. Practise saying all three in one breath: no memory → still 1/2 → the streak changes nothing.`, tag: tb?.tag,
  }] });
  // 6. post-test
  sec.push({ name: "6 · Check-out (new situations)", why: "Can you use the idea somewhere new?", rows: POST.map((it) => {
    const a = s.post[it.id]; const o = it.options.find((x) => x.id === a?.choice); const c = it.options.find((x) => x.correct)!;
    return { what: `${it.story} ${it.ask}`, your: o?.text ?? "skipped", correct: c.text, marks: a?.correct ? 1 : 0, of: 1, feedback: o?.fb ?? "Not answered.", tag: o?.tag };
  }) });
  // 7. conversations with Asha
  if ((s.asks ?? []).some((a) => a.judge)) sec.push({ name: "7 · Reasoning out loud with Asha", why: "Your answers to Asha's follow-up questions, judged for understanding.", rows: (s.asks ?? []).filter((a) => a.judge).map((a) => ({
    what: a.reply.followup, your: a.answer ?? "", correct: "Reasoning that the past can't change an independent toss", marks: a.judge!.understood ? 1 : 0, of: 1, feedback: a.judge!.feedback,
  })) });
  const total = sec.flatMap((x) => x.rows).reduce((a, r) => a + r.marks, 0), max = sec.flatMap((x) => x.rows).reduce((a, r) => a + r.of, 0);
  const tags = uniq(sec.flatMap((x) => x.rows).map((r) => r.tag).filter((t): t is Mis => !!t));
  const postTags = uniq(Object.values(s.post).map((x) => x.tag).filter((t): t is Mis => !!t));
  const right = sec.flatMap((x) => x.rows.filter((r) => r.marks === r.of && r.your !== "skipped").map((r) => ({ ...r, sec: x.name })));
  const wrong = sec.flatMap((x) => x.rows.filter((r) => r.marks < r.of).map((r) => ({ ...r, sec: x.name })));
  const CLEAR: Record<Mis, string> = {
    M1: "The coin doesn't keep score, so nothing is ever \"due\". Each toss is independent: still 1/2.",
    M2: "A streak never guarantees or boosts the next result for a fair coin. Each toss is independent: still 1/2.",
    M3: "Every exact sequence of n tosses has the same chance, (1/2)ⁿ. Random-looking isn't more likely.",
  };
  return (
    <section className="card evaluation">
      <h1>📊 Your evaluation</h1>
      <div className="score"><b>{total}</b><span>/ {max} marks</span><small>{Math.round((total / Math.max(1, max)) * 100)}%</small></div>
      <table className="batches marks"><thead><tr><th>Part</th><th>Marks</th></tr></thead><tbody>
        {sec.map((x) => <tr key={x.name}><td>{x.name}<br /><small className="muted">{x.why}</small></td><td>{x.rows.reduce((a, r) => a + r.marks, 0)} / {x.rows.reduce((a, r) => a + r.of, 0)}</td></tr>)}
      </tbody></table>

      <h3>✅ What you did right ({right.length})</h3>
      <ul className="lo">{right.map((r, i) => <li key={i} className="good"><small>{r.sec}</small><br />{r.what}<br /><b>{r.your}</b> ({r.marks}/{r.of})</li>)}</ul>

      <h3>🌱 What went wrong, and how to fix it ({wrong.length})</h3>
      <ul className="lo">{wrong.map((r, i) => (
        <li key={i} className="notyet"><small>{r.sec} · {r.marks}/{r.of}</small><br />{r.what}<br />
          Your answer: <b>{r.your}</b><br />Correct: <b>{r.correct}</b><br />
          <i>Why:</i> {r.feedback}{r.tag ? <><br /><i>Misconception:</i> {MIS_NAME[r.tag]}</> : null}</li>
      ))}</ul>

      <h3>🧠 Misconceptions</h3>
      {tags.length ? <ul className="lo">{tags.map((t) => {
        const cleared = !postTags.includes(t) && Object.keys(s.post).length === POST.length;
        return <li key={t} className={cleared ? "good" : "notyet"}><b>{MIS_NAME[t]}</b>: {cleared ? "cleared ✓ (not seen in the check-out)" : Object.keys(s.post).length < POST.length ? "not checked yet: finish the check-out" : "still present ✗"}<br /><i>The fix:</i> {CLEAR[t]}</li>;
      })}</ul> : <p>No misconceptions showed up. 👏</p>}

      <h3>📈 How to improve</h3>
      <ul className="facts">
        {wrong.some((r) => r.sec.startsWith("4") || r.sec.startsWith("6")) && <li>Redo <b>Practice</b> from the Home screen: the questions adapt to what you missed.</li>}
        {tags.includes("M1") && <li>Say it aloud: "The coin has no memory, so nothing is ever due." Then explain it to Asha with 🎤.</li>}
        {tags.includes("M2") && <li>Before trusting a streak, ask: "Could chance alone do this?" Run 1000 tosses in the lab and look at the longest streak.</li>}
        {sec[4]!.rows[0]!.marks < 3 && <li>Teach-back: include all three ideas: no memory → still 1/2 → the streak changes nothing.</li>}
        {(s.skipped ?? []).length > 0 && <li>You skipped {(s.skipped ?? []).length} stage{(s.skipped ?? []).length > 1 ? "s" : ""}. Open them from Home if you want those marks.</li>}
        {total === max && <li>Perfect score: try the same idea with dice or spinners, or explain it to a friend.</li>}
      </ul>
      <button className="primary" onClick={onBack}>← Back</button>
    </section>
  );
}

// ---------------------------------------------------------------- supporting screens (not timed)
export function Welcome({ returning, s, onStart, onContinue, onRestart, onAbout }: { returning: boolean; s: S; onStart: () => void; onContinue: () => void; onRestart: () => void; onAbout: () => void }) {
  if (returning) {
    const i = STEPS.findIndex((x) => x.id === s.step);
    return (
      <section className="card">
        <h1>Welcome back 👋</h1>
        <p>Your place is saved. You were on <b>Stage {i + 1}: {STEPS[i]?.label}</b>, with <b>{mmss(s.activeMs)}</b> of your 10 minutes used.</p>
        <div className="row">
          <button className="primary" onClick={onContinue}>Continue where I stopped</button>
          <button className="ghost" onClick={onRestart}>Start over</button>
        </div>
      </section>
    );
  }
  return (
    <section className="card">
      <h1>Is a "lucky streak" real?</h1>
      <p>You've met probability before, and maybe it didn't go well. <b>That's okay.</b> This time we won't memorise rules. We'll <b>test ideas with real coin tosses</b>, and you decide what's true.</p>
      <div className="trio">
        {(Object.keys(AGENTS) as AgentId[]).map((k) => (
          <div key={k} className={`mini ${k}`}><span className={`dot ${k}`} /> <b>{AGENTS[k].name}</b><small>{AGENTS[k].role}: {AGENTS[k].tone}</small></div>
        ))}
      </div>
      <ul className="facts">
        <li>⏱ <b>10 minutes</b> in 6 short stages (1:45 + 1:45 + 1:45 + 2:30 + 1:15 + 1:00).</li>
        <li>🔊 The helpers can <b>talk to you</b>, and you can <b>answer by voice</b> 🎤.</li>
        <li>⏸ <b>Pause any time</b>; your place is saved on this phone.</li>
        <li>🌱 Nothing is graded and nobody sees your answers.</li>
      </ul>
      <div className="row">
        <button className="primary" onClick={onStart}>Start my 10-minute session</button>
        <button className="ghost" onClick={onAbout}>About</button>
      </div>
    </section>
  );
}

function Paused({ s, onResume }: { s: S; onResume: () => void }) {
  const i = STEPS.findIndex((x) => x.id === s.step);
  return (
    <section className="card center">
      <h1>⏸ Saved</h1>
      <p>You can close the app now. Next time you'll continue from <b>Stage {i + 1}: {STEPS[i]?.label}</b>.</p>
      <p className="muted">Time used: {mmss(s.activeMs)} of 10:00 (the clock is stopped).</p>
      <button className="primary" onClick={onResume}>Continue now</button>
    </section>
  );
}

// ---------------------------------------------------------------- stage 1: check-in + pre-test (no feedback)
function Pretest({ s, up, say, log, go }: Props) {
  if (s.feeling !== undefined && s.preIdx >= PRE.length) return <Diagnostic s={s} go={go} />;
  const item = PRE[s.preIdx]!;
  const a = s.pre[item.id];
  if (s.feeling === undefined) {
    return (
      <section className="card">
        <Bubble who="teacher">Before we start: how do you feel about probability today?</Bubble>
        <div className="chips">
          {FEEL.map((f, i) => (
            <button key={f} className="chip" onClick={() => {
              up((d) => ({ ...d, feeling: i as 0 | 1 | 2 }));
              log("feeling", f);
              say([
                { from: "evaluator", to: "teacher", text: `Note: learner feels "${f.slice(3)}".` },
                ...(i === 0 ? [{ from: "teacher" as AgentId, to: "challenger" as AgentId, text: "Note: anxious learner. Use the gentle version of your challenge." }] : []),
              ]);
            }}>{f}</button>
          ))}
        </div>
      </section>
    );
  }
  const next = () => {
    if (s.preIdx + 1 < PRE.length) { up((d) => ({ ...d, preIdx: d.preIdx + 1 })); return; }
    // explicit diagnosis from the two streak items
    const tags = ["pre1", "pre2"].map((k) => s.pre[k]?.tag).filter((t): t is Mis => t === "M1" || t === "M2");
    const c1 = tags.filter((t) => t === "M1").length, c2 = tags.filter((t) => t === "M2").length;
    const diag: Diag = c1 > c2 ? "M1" : c2 > c1 ? "M2" : ((tags[0] as Diag | undefined) ?? "none");
    const side: "M1" | "M2" = diag === "none" ? "M1" : diag;
    const met = uniq([...s.met, ...Object.values(s.pre).map((x) => x.tag).filter((t): t is Mis => !!t)]);
    up((d) => ({ ...d, diag, side, met, preIdx: PRE.length }));
    log("pretest_done", { pre: s.pre, diag });
    say([
      { from: "evaluator", to: "teacher", text: `Diagnostic: ${Object.values(s.pre).filter((x) => x.correct).length}/${PRE.length} correct. Diagnosis: ${DIAG[diag].title}.` },
      { from: "teacher", to: "challenger", text: diag === "none" ? "Learner chose 1/2. Argue \"tails is due\" (M1) to test whether that holds up." : `Argue the learner's own idea (${diag}) so they can test it from the outside.` },
    ]);
  };
  return (
    <section className="card">
      <div className="qhead"><b>Warm-up {s.preIdx + 1} of {PRE.length}</b><span className="lo">no marks · just your first thoughts</span></div>
      <Bubble who="teacher">{item.story}{item.coins && <Coins seq={item.coins} />}<b>{item.ask}</b></Bubble>
      <Options item={item} value={a?.choice} onPick={(id) => {
        const o = item.options.find((x) => x.id === id)!;
        up((d) => ({ ...d, pre: { ...d.pre, [item.id]: { choice: id, correct: !!o.correct, tag: o.tag, conf: d.pre[item.id]?.conf } } }));
        log("pretest", { item: item.id, choice: id, tag: o.tag ?? "none" });
      }} />
      {a && item.id === "pre1" && (
        <>
          <p className="q">How sure are you?</p>
          <div className="chips">
            {CONF.map((c, i) => <button key={c} className={`chip ${a.conf === i ? "on" : ""}`} onClick={() => up((d) => ({ ...d, pre: { ...d.pre, pre1: { ...d.pre.pre1!, conf: i as 0 | 1 | 2 } } }))}>{c}</button>)}
          </div>
        </>
      )}
      {a && (item.id !== "pre1" || a.conf !== undefined) && <AutoNext key={`${item.id}-${a.choice}-${a.conf}`} ms={700} onNext={next} label={s.preIdx + 1 < PRE.length ? "Next question" : "Checking your answers"} />}
    </section>
  );
}

function Diagnostic({ s, go }: { s: S; go: (x: Step) => void }) {
  const area = (ids: string[]) => ({ ok: ids.filter((k) => s.pre[k]?.correct).length, of: ids.length });
  const rows = [
    { name: "Basics: P for one toss, listing outcomes", ...area(["k1", "k2"]) },
    { name: "Streaks: does the past change the next toss?", ...area(["pre1", "pre2"]) },
    { name: "Sequences: comparing exact results", ...area(["pre3"]) },
  ];
  const wrong = PRE.filter((it) => s.pre[it.id] && !s.pre[it.id]!.correct);
  const D = DIAG[s.diag ?? "none"];
  return (
    <section className="card">
      <h2>What your answers tell us</h2>
      <p className="muted">This isn't a mark. It shows where to focus.</p>
      <table className="batches profile"><tbody>
        {rows.map((r) => <tr key={r.name}><td>{r.name}</td><td className={r.ok === r.of ? "good" : "notyet"}>{r.ok}/{r.of}</td></tr>)}
      </tbody></table>
      {wrong.length ? (
        <>
          <h3>Ideas we'll work on</h3>
          <ul className="lo">
            {wrong.map((it) => {
              const o = it.options.find((x) => x.id === s.pre[it.id]!.choice)!;
              return <li key={it.id} className="notyet"><b>You chose "{o.text}".</b> {o.fb}</li>;
            })}
          </ul>
        </>
      ) : <p>All {PRE.length} right: no misconceptions showed up. We'll still test the idea with evidence.</p>}
      <Bubble who="evaluator" via="Noor's diagnosis, shared with Asha and Kabir"><b>Main misconception: {D.title}.</b> {D.what}</Bubble>
      <button className="primary" onClick={() => go("debate")}>Let's test it: see what the helpers think →</button>
    </section>
  );
}

// ---------------------------------------------------------------- stage 2: the agents disagree
function Classroom({ speaking }: { speaking?: AgentId }) {
  const seats: { id: AgentId; face: string }[] = [{ id: "teacher", face: "👩‍🏫" }, { id: "challenger", face: "🙋‍♂️" }, { id: "evaluator", face: "🧑‍🔬" }];
  return (
    <div className="classroom" aria-label="Classroom">
      <div className="board">Is a lucky streak real?</div>
      <div className="seats">
        {seats.map((x) => <div key={x.id} className={`seat ${x.id} ${speaking === x.id ? "speaking" : ""}`}><span>{x.face}</span><small>{AGENTS[x.id].name}</small></div>)}
        <div className="seat you"><span>🧒</span><small>You</small></div>
      </div>
    </div>
  );
}

function MiniLesson({ s, up, log, say, voice, onDone }: { s: S; up: Up; log: Props["log"]; say: Props["say"]; voice: boolean; onDone: () => void }) {
  const ans = s.lessonAns ?? {};
  const upTo = Math.min(LESSON.length - 1, Object.keys(ans).length); // segments unlock as she predicts
  const wrongSoFar = Object.values(ans).filter((x) => !x.right).length;
  useEffect(() => {
    if (!voice) return;
    const L = LESSON[upTo]!;
    stopSpeaking();
    const prev = ans[upTo - 1];
    if (prev) speak(prev.right ? LESSON[upTo - 1]!.predict.ifRight : LESSON[upTo - 1]!.predict.ifWrong, "teacher");
    if (!ans[upTo]) { speak(L.say, "teacher"); speak(L.predict.ask, "teacher"); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [upTo, voice, ans[upTo]?.choice]);
  const pick = (i: number, text: string, right: boolean) => {
    up((d) => ({ ...d, lessonAns: { ...(d.lessonAns ?? {}), [i]: { choice: text, right } } }));
    log("lesson_predict", { segment: i, choice: text, right });
    if (!right) say([{ from: "teacher", to: "evaluator", text: `Lesson ${i + 1}: she predicted "${text}". Explaining it a second way and remembering it for later.` }]);
  };
  return (
    <>
      <Classroom speaking="teacher" />
      <div className="lesson">
        <div className="qhead"><b>Asha's lesson: we'll think together</b><span className="lo">{upTo + 1} of {LESSON.length}</span></div>
        {LESSON.slice(0, upTo + 1).map((L, i) => {
          const a = ans[i];
          return (
            <div key={i} className="lesson-step">
              <Bubble who="teacher"><b>{i + 1}. {L.title}.</b> {L.say}</Bubble>
              <div className="lesson-visual"><Coins seq={L.visual.replace(/[^HT]/g, "")} />{L.visual.includes("?") && <span className="qcoin">?</span>}<p className="caption">{L.caption}</p></div>
              <p className="q">🤔 {L.predict.ask}</p>
              <div className="chips">
                {L.predict.options.map((o) => <button key={o.text} disabled={!!a} className={`chip ${a?.choice === o.text ? (o.right ? "on" : "warn") : ""}`} onClick={() => pick(i, o.text, !!o.right)}>{o.text}</button>)}
              </div>
              {a && <Bubble who="teacher" via={a.right ? undefined : "adapted to your prediction; Asha will remember it"}>{a.right ? L.predict.ifRight : L.predict.ifWrong}{!a.right && wrongSoFar >= 2 && i === upTo ? " Two ideas felt tricky, and that's fine: we'll come back to both with real tosses." : ""}</Bubble>}
            </div>
          );
        })}
        {ans[LESSON.length - 1] && <button className="primary" onClick={() => { stopSpeaking(); onDone(); }}>Let's hear the class discuss it ›</button>}
      </div>
    </>
  );
}

function Debate({ s, up, log, say, go, N }: Props) {
  const [lessonDone, setLessonDone] = useState<boolean>(false); // a finished lesson reopens showing her answers, with one button to the debate
  const [shown, setShown] = useState(1);
  const M2 = s.side === "M2";
  const p1 = PRE[0]!.options.find((o) => o.id === s.pre.pre1?.choice);
  const bold = M2 ? "That coin is on a hot streak! Five heads means heads AGAIN, maybe even for sure." : "Five heads in a row! Things have to balance out, so tails is DUE now. Heads is less likely than 1/2.";
  const gentle = M2 ? "I think that coin is on a lucky streak, so heads again seems more likely than 1/2. But please test me." : "I think after five heads, tails is more likely now, to balance things out. But please test me.";
  const lines: { who: AgentId; text: React.ReactNode; challenge?: boolean; via?: string }[] = [
    {
      who: "evaluator",
      text: s.diag === "none"
        ? `You chose "${p1?.text}". Kabir is going to challenge that. Let's see if your answer survives a real test.`
        : `Your warm-up answers show the idea "${DIAG[s.diag!].title}". Lots of people think this. Kabir agrees with you; Asha doesn't.`,
      via: "using Noor's diagnosis from your warm-up",
    },
    ...(recall(memory(s), "debate") ? [{ who: "teacher" as AgentId, text: recall(memory(s), "debate")!, via: "Asha remembers your lesson prediction" }] : []),
    { who: "challenger", challenge: true, text: N.anxious ? gentle : bold, via: N.anxious ? "toned down after Asha's note: learner is anxious" : undefined },
    { who: "teacher", text: "I disagree. For a fair coin, each toss is independent: the coin has no memory. Every toss is a fresh 1/2 heads, 1/2 tails." },
    { who: "evaluator", text: "So two of us disagree. Don't pick whoever sounds more confident. You'll test it: toss a fair coin hundreds of times and check what happens right after 3 heads in a row." },
    { who: "teacher", text: "One note: we're testing fair coin tosses, which are independent. Real-life streaks (like a batsman in form) can involve changing skill. That's a different question." },
  ];
  const voice = s.voice !== false;
  useEffect(() => {
    if (!lessonDone || !voice) return;
    const l = lines[shown - 1];
    if (l && typeof l.text === "string") { stopSpeaking(); speak(l.text, l.who); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shown, lessonDone, voice]);
  useEffect(() => {
    if (!lessonDone || shown >= lines.length) return;
    const l = lines[shown - 1];
    const len = typeof l?.text === "string" ? l.text.length : 120;
    const t = window.setTimeout(() => setShown((n) => n + 1), Math.min(6000, 1600 + len * (voice ? 55 : 30)));
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shown, lessonDone, voice]);
  if (!lessonDone) return <section className="card"><MiniLesson s={s} up={up} log={log} say={say} voice={voice} onDone={() => setLessonDone(true)} /></section>;
  return (
    <section className="card">
      <Classroom speaking={lines[shown - 1]?.who} />
      <h2>The class disagrees. You'll settle it.</h2>
      {lines.slice(0, shown).map((l, i) => <Bubble key={i} who={l.who} challenge={l.challenge} via={l.via}>{l.text}</Bubble>)}
      {shown < lines.length ? <button className="ghost" onClick={() => setShown(lines.length)}>Skip ahead ›</button> : <button className="primary" onClick={() => go("lab")}>Go to the coin lab →</button>}
    </section>
  );
}

// ---------------------------------------------------------------- stage 3: coin lab with sample variation
function Lab({ s, up, say, log, go, N }: Props) {
  const st0 = useMemo(() => stats(s.lab.seq), [s.lab.seq]);
  const [pattern, setPattern] = useState("HHH");
  const [howMany, setHowMany] = useState("500");
  const ap = useMemo(() => afterPattern(s.lab.seq, pattern), [s.lab.seq, pattern]);
  const all = useMemo(() => PATTERNS.map((pt) => ({ pt, ...afterPattern(s.lab.seq, pt) })), [s.lab.seq]);
  // the key test follows the learner's chosen pattern
  const st = { ...st0, after3: ap };
  const M2 = s.side === "M2";
  const run = (n: number) => {
    const before = stats(s.lab.seq);
    const seq = [...s.lab.seq, ...toss(n)].slice(-30000);
    const after = stats(seq);
    const b: Batch = { tosses: n, cases: after.after3.cases - before.after3.cases, heads: after.after3.heads - before.after3.heads };
    up((d) => ({ ...d, lab: { ...d.lab, seq, batches: [...d.lab.batches, b] } }));
    log("toss_batch", b);
  };
  const p = st.after3.cases ? (st.after3.heads / st.after3.cases) * 100 : 0;
  const band = st.after3.cases ? 98 / Math.sqrt(st.after3.cases) : 0; // ≈95% range for a fair coin, in percentage points
  const lo = Math.max(0, Math.round(50 - band)), hi = Math.min(100, Math.round(50 + band));
  const inRange = Math.abs(p - 50) <= band;
  const enough = st.tosses >= 200 && st.after3.cases >= 15;
  const p100 = Math.round(pRunAtLeast(100, 5) * 100);
  const verdict = s.lab.verdict;
  const choose = (v: "teacher" | "challenger" | "unsure") => {
    const wrong = v === "challenger" ? s.lab.wrongVerdicts + 1 : s.lab.wrongVerdicts;
    up((d) => ({
      ...d,
      lab: { ...d.lab, verdict: v, wrongVerdicts: wrong },
      ...(v === "challenger" ? { diag: d.diag === "none" ? d.side : d.diag, met: uniq([...d.met, d.side ?? "M1"]) as Mis[] } : {}),
      ...(v === "teacher" ? { resolved: uniq([...d.resolved, d.side ?? "M1"]) as Mis[] } : {}),
    }));
    log("verdict", { v, tosses: st.tosses, after3: st.after3 });
    say(
      v === "teacher"
        ? [
            { from: "evaluator", to: "challenger", text: `Learner's evidence: ${Math.round(p)}% heads after HHH over ${st.after3.cases} times (theory 50%, normal range ${lo}–${hi}%). Verdict: Teacher.` },
            { from: "challenger", to: "evaluator", text: "Conceding. I'll say so to the learner, using their data." },
            { from: "evaluator", to: "teacher", text: `Note: lab result ${Math.round(p)}% after HHH. Quote it in practice feedback.` },
          ]
        : [{ from: "evaluator", to: "teacher", text: `Learner chose "${v}" with ${Math.round(p)}% after HHH (wrong verdicts: ${wrong}). ${wrong >= 2 ? "Please walk them through it." : "I'll nudge; not revealing the answer."}` }],
    );
  };
  return (
    <section className="card">
      <h2>🪙 Coin lab</h2>
      <p className="muted">A fair coin, tossed by the computer. <b>You choose a pattern</b>; every time it appears, we record the <b>very next toss</b>.</p>
      <div className="labctl">
        <span className="q">1. Pattern to test:</span>
        <div className="chips">{PATTERNS.map((pt) => <button key={pt} className={`chip ${pattern === pt ? "on" : ""}`} onClick={() => { setPattern(pt); log("lab_pattern", pt); }}>{pt.split("").join(" ")}</button>)}</div>
        <span className="q">2. How many tosses?</span>
        <div className="row">
          <button className="primary" onClick={() => run(10)}>Toss 10</button>
          <button className="primary" onClick={() => run(100)}>Toss 100</button>
          <button className="primary" onClick={() => run(1000)}>Toss 1000</button>
          <input aria-label="Number of tosses" inputMode="numeric" value={howMany} onChange={(e) => setHowMany(e.target.value.replace(/\D/g, "").slice(0, 4))} style={{ width: 90 }} />
          <button className="ghost" disabled={!Number(howMany)} onClick={() => run(Math.min(5000, Math.max(1, Number(howMany))))}>Toss {Math.min(5000, Number(howMany) || 0)}</button>
        </div>
      </div>
      {st.tosses > 0 && (
        <>
          <Coins seq={s.lab.seq.slice(-36).join("")} small />
          <table className="batches">
            <thead><tr><th>Batch</th><th>Tosses</th><th>HHH seen</th><th>Heads next</th></tr></thead>
            <tbody>
              {s.lab.batches.slice(-5).map((b, i, arr) => (
                <tr key={i}><td>{s.lab.batches.length - arr.length + i + 1}</td><td>{b.tosses}</td><td>{b.cases}</td><td>{b.cases ? `${pct(b.heads, b.cases)}%` : "—"}</td></tr>
              ))}
              <tr className="total"><td>All</td><td>{st.tosses}</td><td>{st.after3.cases}</td><td>{st.after3.cases ? `${Math.round(p)}%` : "—"}</td></tr>
            </tbody>
          </table>
          {st.after3.cases > 0 && (
            <div className="key">
              <p>🔎 <b>Your result:</b> after {pattern.split("").join(" ")}, heads came next <b className="big">{Math.round(p)}%</b> of the time ({st.after3.heads} of {st.after3.cases}).</p>
              <p>📐 <b>Theory for a fair coin:</b> 50% (independent tosses).</p>
              <div className="bar">
                <span className="band" style={{ left: `${lo}%`, width: `${hi - lo}%` }} />
                <i style={{ left: `calc(${Math.min(99, p)}% - 2px)` }} />
                <span className="mid" />
              </div>
              <p className="muted small">Shaded = normal chance range for {st.after3.cases} cases (about {lo}%–{hi}%). Black line = 50%. Blue mark = you.</p>
              <p className="variation">
                {inRange
                  ? `Your ${Math.round(p)}% is inside the normal range: the gap from 50% is just sample variation.`
                  : `Your ${Math.round(p)}% is outside the usual range. That happens about 1 time in 20 by chance; run another batch.`}{" "}
                Small batches jump around (look at the table); with more data the result settles near 50%.
              </p>
              <p className="muted">Kabir predicted {M2 ? "clearly MORE" : "clearly LESS"} than 50%. Asha predicted 50%.</p>
            </div>
          )}
          <div className="compare">
            <p className="q">🧪 Does the past change the next toss? Heads next, after each pattern:</p>
            {all.map((r) => (
              <div key={r.pt} className={`cmp ${r.pt === pattern ? "sel" : ""}`}>
                <span className="cmp-pt">after {r.pt.split("").join(" ")}</span>
                <span className="cmp-bar"><i style={{ width: `${r.cases ? (r.heads / r.cases) * 100 : 0}%` }} /><span className="mid" /></span>
                <span className="cmp-v">{r.cases ? `${pct(r.heads, r.cases)}%` : "—"} <small>({r.cases})</small></span>
              </div>
            ))}
            <p className="variation">Whatever came before (heads, tails, long streaks or mixed), the next toss is heads about <b>50%</b> of the time. <b>The past flips don't affect the next one.</b> Small counts (in brackets) wobble more.</p>
          </div>
          <p className="muted small">Streaks are normal: the exact chance that 100 tosses contain a run of 5+ heads is <b>{p100}%</b>. So a streak alone isn't "luck".</p>
        </>
      )}
      {!enough && <p className="hint">Toss at least 200 times (several batches) so there are enough H H H moments to judge.</p>}
      {enough && (
        <div className="verdict">
          <p className="q">Who does <b>your</b> evidence support?</p>
          <div className="options">
            <button className={`option ${verdict === "teacher" ? "on" : ""}`} onClick={() => choose("teacher")}>Asha (Teacher): it stays about 1/2</button>
            <button className={`option ${verdict === "challenger" ? "on" : ""}`} onClick={() => choose("challenger")}>Kabir (Challenger): {M2 ? "heads is more likely" : "tails is due"}</button>
            <button className={`option ${verdict === "unsure" ? "on" : ""}`} onClick={() => choose("unsure")}>Not sure yet</button>
          </div>
          {verdict === "teacher" && (
            <>
              <Bubble who="challenger" via="using Noor's note: your lab data">Fair enough. Your data: {Math.round(p)}% heads right after a streak, inside the normal range around 50%. The coin didn't "remember" the streak. I was wrong.</Bubble>
              {recall(memory(s), "lab") && <Bubble who="teacher" via="Asha remembers your first answer and confidence">{recall(memory(s), "lab")}</Bubble>}
              <Bubble who="teacher"><b>You</b> settled this with evidence. For a fair coin, tosses are <b>independent</b>: the past doesn't change the next toss, so P(heads) stays 1/2.</Bubble>
              <button className="primary" onClick={() => go("practice")}>Next: your personal diagnosis →</button>
            </>
          )}
          {verdict === "challenger" && (
            <>
              <Bubble who="evaluator">Look at the number: after H H H, heads came next <b>{Math.round(p)}%</b> of the time. Kabir said it would be {M2 ? "clearly MORE" : "clearly LESS"} than 50%. Is {Math.round(p)}% outside the shaded normal range? Run another batch and check again.</Bubble>
              {N.wrongVerdicts >= 2 && (
                <>
                  <Bubble who="teacher" via="using Noor's note: second wrong verdict">Let's look together. {Math.round(p)}% sits {inRange ? "inside" : "near"} the range a fair coin gives just by chance. If streaks mattered, it would be far from 50% every batch. So each toss is independent: still 1/2.</Bubble>
                  <button className="primary" onClick={() => { log("verdict_explained"); go("practice"); }}>I see. Next →</button>
                </>
              )}
            </>
          )}
          {verdict === "unsure" && <Bubble who="evaluator">Good instinct: more data makes it clearer. Run another batch of 1000 and watch where the blue mark lands.</Bubble>}
        </div>
      )}
    </section>
  );
}

// ---------------------------------------------------------------- the agents' reasoning pipeline, shown to the learner
const TRUTH: Record<string, Ctx["truth"] & { method?: string }> = {
  "diag-M1": { label: "the chance of heads on the next toss", forms: ["1/2"] },
  "diag-M2": { label: "the chance of heads on the next toss", forms: ["1/2"] },
  "diag-none": { label: "the chance of a 6 on the next roll", forms: ["1/6"] },
  "f1-M1": { label: "the expected number of tails in the next 2 tosses", forms: ["1 tail"] },
  "f1-M2": { label: "Priya's chance of winning the 4th toss", forms: ["1/2"] },
  "f1-none": { label: "the chance of a 6 on the next roll", forms: ["1/6"] },
  q2: { label: "the chance of heads on both of 2 tosses", forms: ["1/4"] },
  q2h: { label: "the chance of heads on all 3 tosses", forms: ["1/8"] },
  r1: { label: "the chance on the next spin or roll", forms: ["1/2", "1/6"] },
  e1: { label: "the number of equally likely outcomes for 2 tosses", forms: ["4 outcomes"] },
  lab1: { label: "the chance of heads after a streak", forms: ["1/2"] },
  q5: { label: "the chance of winning the next toss", forms: ["1/2"] },
};
const PIPE_CACHE = new Map<string, PipeResult>();
function PipeCard({ ctx, onDone }: { ctx: Ctx; onDone: (r: PipeResult) => void }) {
  const [r, setR] = useState<PipeResult | null>(() => PIPE_CACHE.get(ctx.key) ?? null);
  useEffect(() => {
    if (PIPE_CACHE.has(ctx.key)) return;
    let live = true;
    void runPipeline(ctx).then((res) => {
      PIPE_CACHE.set(ctx.key, res);
      if (live) { setR(res); onDone(res); }
    });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ctx.key]);
  if (!r) return <div className="bubble teacher"><div className="say">✍️ Asha is drafting → Kabir is testing it → Noor is verifying the maths…</div></div>;
  const src = (x: "ai" | "rules") => (x === "ai" ? "AI" : "rule engine");
  return (
    <>
      <Bubble who="teacher" via={`drafted by Asha · tested by Kabir · maths verified by Noor${r.usedFallback ? " · verified fallback used" : ""}`}>
        {r.final.split("\n").map((l, i) => <p key={i} className={i ? "example" : ""}>{i ? <><i>Example:</i> {l}</> : l}</p>)}
      </Bubble>
      <details className="trace">
        <summary>🔍 How the 3 agents built this answer</summary>
        <ol>
          <li><b className="teacher">1 · Teacher proposes</b> <small>({src(r.proposal.source)})</small><pre>{JSON.stringify({ explanation: r.proposal.explanation, example: r.proposal.example }, null, 1)}</pre></li>
          <li><b className="challenger">2 · Challenger tests it</b> <small>({src(r.critique.source)})</small><pre>{JSON.stringify({ verdict: r.critique.verdict, issues: r.critique.issues }, null, 1)}</pre></li>
          <li><b className="evaluator">3 · Evaluator verifies the maths</b> <small>(exact check in code)</small><pre>{JSON.stringify({ pass: r.math.pass, correctResultStated: r.math.truthStated, numbers: r.math.checks.map((c) => `${c.stated}: ${c.ok ? "✓" : "✗"} ${c.why}`) }, null, 1)}</pre></li>
          <li><b className="teacher">4 · Teacher revises</b><ul>{r.revisions.map((x, i) => <li key={i}>{x}</li>)}</ul></li>
        </ol>
      </details>
    </>
  );
}

// ---------------------------------------------------------------- stage 4: diagnosis + practice
function Practice({ s, up, say, log, go, N }: Props) {
  const diag: Diag = s.diag ?? "none";
  const D = DIAG[diag];
  const { tasks: TASKS, why } = plan(s);
  const t = TASKS[s.task]!;
  const a: Ans = s.answers[t.id] ?? { attempts: 0, correct: false, hint: false, value: "", done: false };
  const [val, setVal] = useState("");
  const sNow = useRef(s);
  sNow.current = s;
  useEffect(() => { setVal(""); }, [s.task]);
  useEffect(() => {
    if (s.task === 0 && !s.channel.some((m) => m.text.startsWith("Diagnosis →")))
      say([
        { from: "evaluator", to: "teacher", text: `Diagnosis → ${D.title}. Use the ${diag} explanation, example, follow-up and hints. Starting plan: ${TASKS.map((x) => x.id).join(" → ")}.` },
        { from: "teacher", to: "evaluator", text: `Giving the ${diag} explanation now; please check the follow-up for the same misconception.` },
      ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.task]);

  const record = (patch: Partial<Ans>, tag?: Mis) => {
    const n: Ans = { ...a, ...patch };
    up((d) => ({
      ...d,
      answers: { ...d.answers, [t.id]: n },
      met: tag ? uniq([...d.met, tag]) : d.met,
      resolved: n.correct && a.tag ? uniq([...d.resolved, a.tag]) : d.resolved,
    }));
    log("answer", { task: t.id, ...patch });
    if (tag) say([{ from: "evaluator", to: "teacher", text: `${t.id}: answer shows ${MIS_NAME[tag]} (try ${n.attempts}). Add the learner's lab data to the feedback.` }]);
  };
  const finish = () => {
    const nextPlan = plan(sNow.current).tasks;
    if (nextPlan.length !== TASKS.length) say([{ from: "evaluator", to: "teacher", text: `Adapting the path: ${nextPlan.map((x) => x.id).join(" → ")} (${nextPlan.filter((x) => !TASKS.some((y) => y.id === x.id)).map((x) => x.id).join(", ")} added).` }]);
    log("plan", nextPlan.map((x) => x.id));
    if (s.task + 1 < nextPlan.length) up((d) => ({ ...d, task: d.task + 1 }));
    else go("posttest");
  };
  const lastTry = a.attempts >= 2 && !a.correct;
  const ctxFor = (k: string, extra?: Partial<Ctx>): Ctx => ({ key: `${k}#${extra?.learnerAnswer ?? ""}`, diag, anxious: N.anxious, labPct: N.labPct, labCases: N.labCases, truth: TRUTH[k] ?? TRUTH[`diag-${diag}`]!, ...extra });
  const piped = (r: PipeResult) => {
    log("pipeline", { proposal: r.proposal, critique: r.critique, math: r.math, revisions: r.revisions });
    say([
      { from: "teacher", to: "challenger", text: `Proposal (${r.proposal.source}): ${r.proposal.explanation.split(/\s+/).length} words. Please test it.` },
      { from: "challenger", to: "evaluator", text: r.critique.issues.length ? `Weaknesses: ${r.critique.issues.map((i) => i.type).join(", ")}.` : "No weaknesses found." },
      { from: "evaluator", to: "teacher", text: `Maths check ${r.math.pass ? "PASSED" : "FAILED"}: ${r.math.checks.map((c) => `${c.stated} ${c.ok ? "✓" : "✗"}`).join(", ") || "no numbers"}; correct result ${r.math.truthStated ? "stated" : "missing"}.` },
      { from: "teacher", to: "evaluator", text: `Revised: ${r.revisions.join(" ")}` },
    ]);
  };
  const prevTag = s.task > 0 ? s.answers[TASKS[s.task - 1]!.id]?.tag : undefined;
  const hintExtra = diag === "M1" ? " (Noor's note: you're working on \"tails is due\". The coin doesn't owe anything.)" : diag === "M2" ? " (Noor's note: you're working on \"streaks continue\". A streak guarantees nothing.)" : "";

  return (
    <section className="card">
      {s.task === 0 && (
        <>
          <Bubble who="evaluator"><b>Your diagnosis: {D.title}.</b> {D.what}</Bubble>
          {recall(memory(s), "practice") && <Bubble who="teacher" via="Asha's memory of this session">{recall(memory(s), "practice")}</Bubble>}
          <PipeCard ctx={ctxFor(`diag-${diag}`)} onDone={piped} />
        </>
      )}
      {(prevTag === "M1" || prevTag === "M2") && s.task > 0 && !a.attempts && (
        <Bubble who="teacher" via="using Noor's note on your last answer">Quick reminder: {DIAG[prevTag].explain}</Bubble>
      )}
      <div className="qhead"><b>Practice {s.task + 1} of {TASKS.length}{s.task + 1 === TASKS.length ? "" : "+"}</b><span className="lo">{t.lo}</span></div>
      {why[t.id] && <p className="why">🧭 {why[t.id]}</p>}
      <p className="prompt">{t.prompt}</p>

      {t.kind === "mcq" && (
        <div className="options">
          {t.choices.map((c) => (
            <button key={c.id} disabled={a.done} className={`option ${a.value === c.id ? (c.correct ? "good" : "notyet") : ""}`} onClick={() => {
              const ok = !!c.correct;
              record({ attempts: a.attempts + 1, value: c.id, correct: ok, tag: c.tag ?? a.tag, done: ok || a.attempts + 1 >= 2, fb: c.fb, labFb: !ok && !!c.tag }, c.tag);
            }}>{c.text}</button>
          ))}
        </div>
      )}

      {t.kind === "number" && (
        <form className="row" onSubmit={(e) => {
          e.preventDefault();
          const v = parseProb(val);
          if (v === null) { record({ fb: "Please type a number like 1/4, 0.25 or 25%." }); return; }
          const ok = Math.abs(v - t.answer) < 1e-6;
          const w = t.wrong.find((x) => Math.abs(x.value - v) < 1e-3);
          record({ attempts: a.attempts + 1, value: val, correct: ok, tag: w?.tag ?? a.tag, done: ok || a.attempts + 1 >= 2, fb: ok ? t.correctFb : w?.fb ?? t.otherFb, labFb: !!w?.tag }, w?.tag);
        }}>
          <input inputMode="decimal" aria-label="Your answer" placeholder="e.g. 1/3" value={val} disabled={a.done} onChange={(e) => setVal(e.target.value)} />
          <button className="primary" disabled={a.done || !val.trim()}>Check</button>
        </form>
      )}

      {t.kind === "explain" && <TeachBackBox s={s} up={up} say={say} log={log} diag={diag} onDone={(found, tag, attempts) => {
        const n = Object.values(found).filter(Boolean).length;
        up((d) => ({ ...d, q5: { score: Math.min(2, n) as 0 | 1 | 2, tag, feedback: "", source: "rules", text: "" } }));
        record({ attempts, value: `${n}/3 concepts`, correct: n >= 2 && tag === "none", done: true, fb: n === 3 ? "You taught all three ideas in your own words." : `You taught ${n} of 3 ideas. The model answer below shows the full version.` });
      }} />}

      {a.fb && a.attempts > 0 && (
        <Bubble who="evaluator">
          {a.correct ? "✅ " : "🌱 Not yet. "}{a.fb}
          {!a.correct && !lastTry && <><br /><b>Try once more.</b></>}
        </Bubble>
      )}
      {!a.correct && a.attempts > 0 && a.value && t.kind !== "explain" && (
        <PipeCard ctx={ctxFor(t.id === "f1" ? `f1-${diag}` : t.id, { learnerAnswer: a.value, question: t.prompt })} onDone={piped} />
      )}
      {a.correct && s.task === 0 && s.pre.pre1?.conf === 0 && <Bubble who="teacher" via="using your warm-up confidence">You felt you were guessing earlier, but you reasoned this correctly. Trust that reasoning.</Bubble>}
      {a.done && a.correct && t.kind !== "explain" && <AutoNext key={t.id} ms={2500} onNext={finish} />}
      {lastTry && <Bubble who="teacher"><b>Model answer:</b> {t.model} {N.anxious ? "This one trips up most people; you've seen the idea now." : ""}</Bubble>}
      {a.hint && !a.done && <Bubble who="teacher" via={hintExtra ? "hint tailored from Noor's diagnosis" : undefined}>💡 {t.hint}{hintExtra}</Bubble>}
      <div className="row">
        {!a.done && !a.hint && <button className="ghost" onClick={() => record({ hint: true })}>💡 Hint from Asha</button>}
        {a.done && !(a.correct && t.kind !== "explain") && <button className="primary" onClick={finish}>{s.task + 1 < TASKS.length ? "Next →" : "Next: post-test →"}</button>}
      </div>
    </section>
  );
}

// ---------------------------------------------------------------- teach-back: explain in your own words; Evaluator finds gaps; Teacher guides; try again
const GUIDE: Record<ConceptId, (d: Diag) => string> = {
  independence: () => "Add WHY: does the coin know what happened on earlier tosses? Try a sentence starting \"The coin has no…\".",
  chance: () => "Add the number: what is the chance of winning the next toss, whatever happened before?",
  streak: (d) => (d === "M2" ? "Finish the thought: so does a winning (or losing) streak guarantee anything about the next toss?" : "Finish the thought: so does losing 5 times make a win \"due\"?"),
};
function TeachBackBox({ s, say, log, diag, onDone }: { s: S; up: Up; say: Props["say"]; log: Props["log"]; diag: Diag; onDone: (found: Record<ConceptId, boolean>, tag: TeachBack["tag"], attempts: number) => void }) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [tries, setTries] = useState<{ text: string; r: TeachBack }[]>([]);
  const [listening, setListening] = useState(false);
  const [spoken, setSpoken] = useState(false); // was this attempt given by voice?
  const stopRef = useRef<(() => void) | null>(null);
  const [finished, setFinished] = useState(!!s.answers.q5?.done);
  const last = tries[tries.length - 1];
  const best = (k: ConceptId) => tries.some((x) => x.r.found[k] && x.r.tag === "none");
  const missing = CONCEPTS.filter((c) => !best(c.id));
  const submit = async () => {
    setBusy(true);
    const r = await evaluateTeachBack(text);
    setBusy(false);
    const all = [...tries, { text, r }];
    setTries(all);
    const miss = CONCEPTS.filter((c) => !all.some((x) => x.r.found[c.id] && x.r.tag === "none"));
    log("teachback", { attempt: all.length, text, found: r.found, tag: r.tag, source: r.source, mode: spoken ? "voice" : "typed" });
    setSpoken(false);
    say([
      { from: "evaluator", to: "teacher", text: `Teach-back ${all.length}: ${r.tag !== "none" ? `endorses ${r.tag}; ` : ""}missing ${miss.map((m) => m.id).join(", ") || "nothing"} (${r.source === "ai" ? "AI, validated" : "rules"}).` },
      ...(miss.length && r.tag === "none" ? [{ from: "teacher" as AgentId, to: "evaluator" as AgentId, text: `Guiding on "${miss[0]!.id}" only; one gap at a time.` }] : []),
    ]);
    if ((!miss.length && r.tag === "none") || all.length >= 3) {
      setFinished(true);
      const found = Object.fromEntries(CONCEPTS.map((c) => [c.id, all.some((x) => x.r.found[c.id] && x.r.tag === "none")])) as Record<ConceptId, boolean>;
      onDone(found, all[all.length - 1]!.r.tag === "none" ? "none" : all[all.length - 1]!.r.tag, all.length);
    } else setText("");
  };
  return (
    <div className="teachback">
      <p className="muted small">Your explanation needs 3 ideas. Noor ticks them off as you include them:</p>
      <ul className="concepts">
        {CONCEPTS.map((c) => <li key={c.id} className={best(c.id) ? "good" : ""}>{best(c.id) ? "✓" : "○"} {c.label}</li>)}
      </ul>
      {tries.map((x, i) => <p key={i} className="attempt"><b>Attempt {i + 1}:</b> "{x.text}"</p>)}
      {last && !finished && s.voice !== false && <AutoSpeak text={last.r.tag !== "none" ? "Your sentence still says the luck will turn. Try again: what does the coin remember?" : `Good start: you've got ${3 - missing.length} of 3. ${GUIDE[missing[0]!.id](diag)}`} k={tries.length} />}
      {last && !finished && (
        last.r.tag !== "none"
          ? <Bubble who="teacher" via="guided by Noor's check: misconception found">Your sentence still says the luck will turn: that's the {last.r.tag === "M1" ? "\"due\"" : "streak"} idea we tested. Your lab showed heads came after a streak about half the time. Try again: what does the coin remember?</Bubble>
          : <Bubble who="teacher" via={`targeted at the missing idea Noor found: ${missing[0]!.id}`}>Good start: you've got {3 - missing.length} of 3. {GUIDE[missing[0]!.id](diag)}</Bubble>
      )}
      {!finished && (
        <>
          <textarea rows={3} aria-label="Your explanation" placeholder={tries.length ? "Try again: keep what you had and add the missing idea…" : "Explain it in your own words… or tap 🎤 and say it"} value={text} disabled={busy} onChange={(e) => setText(e.target.value)} />
          {canListen() && (
            <button type="button" className={`ghost mic ${listening ? "on" : ""}`} onClick={() => {
              if (listening) { stopRef.current?.(); return; }
              setListening(true);
              setSpoken(true);
              stopRef.current = listen((t) => setText(t), () => setListening(false));
            }}>{listening ? "⏹ Stop: I'm done talking" : "🎤 Say it instead"}</button>
          )}
          <button className="primary" disabled={busy || text.trim().length < 8} onClick={() => void submit()}>{busy ? "Noor is checking…" : tries.length ? `Try again (attempt ${tries.length + 1} of 3)` : "Teach it to Noor"}</button>
          {last?.r.note && <p className="muted small">{last.r.note}</p>}
        </>
      )}
    </div>
  );
}

/** Moves on by itself after `ms`, unless the learner taps "Wait". */
function AutoNext({ ms, onNext, label = "Moving on" }: { ms: number; onNext: () => void; label?: string }) {
  const [hold, setHold] = useState(false);
  const cb = useRef(onNext);
  cb.current = onNext;
  useEffect(() => {
    if (hold) return;
    const t = window.setTimeout(() => cb.current(), ms);
    return () => window.clearTimeout(t);
  }, [hold, ms]);
  return (
    <div className="autonext">
      {hold ? <button className="primary" onClick={() => cb.current()}>Next →</button> : <><span className="dotbar" style={{ animationDuration: `${ms}ms` }} /> {label}… <button className="link" onClick={() => setHold(true)}>Wait, let me read</button></>}
    </div>
  );
}

function AutoSpeak({ text, k }: { text: string; k: number }) {
  useEffect(() => { stopSpeaking(); speak(text, "teacher"); }, [k, text]);
  return null;
}

// ---------------------------------------------------------------- stage 5: post-test (new scenarios, matched to the pre-test)
function Posttest({ s, up, say, log, go }: Props) {
  const item = POST[s.postIdx]!;
  const a = s.post[item.id];
  const o = a ? item.options.find((x) => x.id === a.choice) : undefined;
  return (
    <section className="card">
      <div className="qhead"><b>Check-out {s.postIdx + 1} of 3</b><span className="lo">new situations · first answer counts</span></div>
      <Bubble who="evaluator">{item.story} <b>{item.ask}</b></Bubble>
      <Options item={item} value={a?.choice} disabled={!!a} mark onPick={(id) => {
        const c = item.options.find((x) => x.id === id)!;
        up((d) => ({ ...d, post: { ...d.post, [item.id]: { choice: id, correct: !!c.correct, tag: c.tag } }, met: c.tag ? uniq([...d.met, c.tag]) : d.met }));
        log("posttest", { item: item.id, choice: id, tag: c.tag ?? "none" });
        if (c.tag) say([{ from: "evaluator", to: "teacher", text: `Post-test ${item.id}: ${MIS_NAME[c.tag]} still present.` }]);
      }} />
      {o && <Bubble who={o.correct ? "evaluator" : "teacher"}>{o.correct ? "✅ " : "🌱 "}{o.fb}</Bubble>}
      {a && (
        <AutoNext key={item.id} ms={2500} label={s.postIdx + 1 < POST.length ? "Next question" : "On to reflect"} onNext={() => {
          if (s.postIdx + 1 < POST.length) up((d) => ({ ...d, postIdx: d.postIdx + 1 }));
          else {
            const pre = ["pre1", "pre2", "pre3"].filter((k) => s.pre[k]?.correct).length, post = Object.values(s.post).filter((x) => x.correct).length;
            say([{ from: "evaluator", to: "teacher", text: `Pre-test ${pre}/3 → post-test ${post}/3.` }]);
            go("reflect");
          }
        }} />
      )}
    </section>
  );
}

// ---------------------------------------------------------------- stage 6: reflect
function Reflect({ s, up, log, go }: Props) {
  return (
    <section className="card">
      <Bubble who="teacher">Last thing. If a friend said "a lucky streak makes the next toss more likely to win", how sure are you that they're wrong?</Bubble>
      <div className="chips">
        {CONF.map((c, i) => <button key={c} className={`chip ${s.endConf === i ? "on" : ""}`} onClick={() => { up((d) => ({ ...d, endConf: i as 0 | 1 | 2, finished: true })); log("end_confidence", c); go("summary"); }}>{c}</button>)}
      </div>
    </section>
  );
}

// ---------------------------------------------------------------- summary (supporting screen, not timed)
function Summary({ s, onRestart, onHome, onEval }: { s: S; onRestart: () => void; onHome: () => void; onEval: () => void }) {
  const ok = (id: string) => !!s.answers[id]?.correct;
  const pre = ["pre1", "pre2", "pre3"].filter((k) => s.pre[k]?.correct).length; // matched with the 3 post-test items
  const post = Object.values(s.post).filter((x) => x.correct).length;
  const postTags = Object.values(s.post).map((x) => x.tag).filter(Boolean) as Mis[];
  const preTags = Object.values(s.pre).map((x) => x.tag).filter(Boolean) as Mis[];
  const lo = [
    { id: "LO1", text: "Predict & explain: after a streak the next toss is unchanged", met: !!s.post.post1?.correct && !!s.post.post2?.correct },
    { id: "LO2", text: "Compute & compare probabilities of sequences", met: (ok("q2") || ok("q2h")) && !!s.post.post3?.correct },
    { id: "LO3", text: "Use evidence to settle the disagreement, and teach the idea back", met: s.lab.verdict === "teacher" && (s.q5?.score ?? 0) >= 2 },
  ];
  const within = s.activeMs <= SESSION_SECONDS * 1000;
  const end = s.endConf ?? 0;
  const calib = end === 2 && post < 3 ? "You feel sure, but the check-out wasn't 3/3 yet. Have a quick look at the idea you missed." : end < 2 && post === 3 ? "You got all 3 check-out questions right but don't feel sure. Your answers show you DO understand this. Trust them." : "Your confidence matches how you did: knowing what you know is a real skill.";
  const download = () => {
    const b = new Blob([JSON.stringify({ id: ID, card: CARD, exportedAt: new Date().toISOString(), session: s }, null, 1)], { type: "application/json" });
    const u = URL.createObjectURL(b);
    const el = document.createElement("a");
    el.href = u; el.download = `lucky-streak-session-${ID}.json`; el.click();
    setTimeout(() => URL.revokeObjectURL(u), 1500);
  };
  return (
    <section className="card">
      <h1>Your session summary</h1>
      <button className="primary" onClick={onEval}>📊 See my detailed evaluation (marks &amp; feedback)</button>
      <p className={`c4 ${within ? "good" : ""}`}>⏱ Six stages completed in <b>{mmss(s.activeMs)}</b> of 10:00 {within ? "✓ within one 10-minute session" : "(a little over; that's fine)"}</p>
      <div className="prepost">
        <div><small>Warm-up (before)</small><b>{pre}/3</b></div>
        <span>→</span>
        <div><small>Check-out (after, new situations)</small><b>{post}/3</b></div>
      </div>
      <p className="muted">Streak ideas: {preTags.length ? uniq(preTags).join(", ") : "none"} before → {postTags.length ? uniq(postTags).join(", ") : "none"} after.</p>
      <p className="muted">Your path was adapted: {plan(s).tasks.map((t) => t.id).filter((id) => ["r1", "e1", "q2h", "lab1"].includes(id)).map((id) => ({ r1: "a revisit of your misconception", e1: "a step back to basics", q2h: "a harder sequence question", lab1: "an extra evidence check" })[id as "r1"]).join(", ") || "you went straight through; no extra questions were needed"}.</p>
      <h3>Your session, as Asha remembers it</h3>
      <ul className="lo story">
        {memory(s).pre1 && <li>You started by saying "{memory(s).pre1}"{memory(s).conf ? `, feeling ${memory(s).conf!.toLowerCase()}` : ""}.</li>}
        {memory(s).lessonWrong.length > 0 && <li>In the lesson you predicted {memory(s).lessonWrong.join(" and ")}; Asha explained those a second way.</li>}
        {memory(s).lab && <li>You ran the coin lab: {memory(s).lab}{s.lab.wrongVerdicts ? `, and changed your verdict after ${s.lab.wrongVerdicts} try` : ""}.</li>}
        {(s.asks ?? []).map((a, i) => <li key={i}>You asked "{a.q}"{a.judge ? (a.judge.understood ? " and reasoned the follow-up correctly." : " and are still working on the follow-up.") : "."}</li>)}
      </ul>
      <h3>What you can now do</h3>
      <ul className="lo">{lo.map((x) => <li key={x.id} className={x.met ? "good" : "notyet"}><b>{x.id}</b> {x.met ? "✓" : "· not yet"} {x.text}</li>)}</ul>
      <h3>Your thinking</h3>
      <p>Diagnosis: <b>{DIAG[s.diag ?? "none"].title}</b>. {DIAG[s.diag ?? "none"].what}</p>
      {s.lab.verdict === "teacher" && <p>Disagreement: <b>you</b> settled Asha vs Kabir with {stats(s.lab.seq).tosses} tosses; Kabir conceded.</p>}
      <p>Confidence: <b>{CONF[s.pre.pre1?.conf ?? 0]}</b> at the start → <b>{CONF[end]}</b> now. {calib}</p>
      <Bubble who="evaluator">{lo.every((x) => x.met) ? "Next time: try the same idea with a spinner or dice. Same rule: independent events." : "Next session: start again; your answers will help Asha focus on what's still tricky."}</Bubble>
      <div className="row">
        <button className="ghost" onClick={download}>⬇ Download my session log</button>
        <button className="ghost" onClick={onHome}>🏠 Home</button>
        <button className="primary" onClick={onRestart}>Start a new session</button>
      </div>
    </section>
  );
}

function About({ onBack }: { onBack: () => void }) {
  return (
    <section className="card">
      <h1>About this app</h1>
      <table className="idcard"><tbody>
        <tr><th>Identity token</th><td><b>{ID}</b></td></tr>
        <tr><th>Problem</th><td>P3 · Multi-agent collaborative learning</td></tr>
        <tr><th>Topic</th><td>T6 · Probability: is a "lucky streak" real? (Class 9–10)</td></tr>
        <tr><th>Learner</th><td>L5 · Anxious learner repeating the topic after failing once</td></tr>
        <tr><th>Constraint</th><td>C4 · 10-minute sessions: six timed stages = 10:00; pause &amp; resume</td></tr>
      </tbody></table>
      <h3>The three agents</h3>
      <ul>
        <li><b>Asha (Teacher)</b>: explains, gives hints and model answers. Her explanation, example and hints are chosen from Noor's diagnosis.</li>
        <li><b>Kabir (Challenger)</b>: argues your own warm-up idea, always labelled as a challenge. He softens his tone when Asha notes you're anxious, and concedes using your lab data.</li>
        <li><b>Noor (Evaluator)</b>: diagnoses the gambler's fallacy vs the winning-streak belief, moderates the disagreement and checks your explanation.</li>
      </ul>
      <p>They share one notes board; open the <b>Agent channel</b> under any stage to see the notes and messages, and look for "↳ using … note" on messages they influenced.</p>
      <h3>Scope</h3>
      <p>The streak claim is tested for <b>independent tosses of a fair coin or die</b>. Real-life streaks (for example in sport) can involve changing skill, which is a different question.</p>
      <h3>AI use &amp; honesty</h3>
      <p>Your written explanation is scored by an AI model through a server function. Its output is checked (format, banned claims, cross-check with a rubric) before you see it; if the AI fails, a clearly labelled rule-based Evaluator is used. All maths (simulation, normal range, streak probabilities) is computed in code. Built with the Vite React-TS starter template and no UI library; AI assistance is disclosed in the report.</p>
      <button className="primary" onClick={onBack}>← Back</button>
    </section>
  );
}

// Lesson content: the predict item, 5 practice tasks (4 formats) with feedback for the correct answer and
// for each misconception (M1 gambler's fallacy, M2 hot hand / lucky streak, M3 "random-looking" sequence).
export const ID = "24B0387";
export const CARD = "P3 · T6 · L5 · C4";

export type Step = "welcome" | "pretest" | "debate" | "lab" | "practice" | "posttest" | "reflect" | "summary";
/** six timed stages; welcome, pause, about and summary are supporting screens and are NOT timed */
export const STEPS: { id: Step; label: string; budget: number }[] = [
  { id: "pretest", label: "Check-in + pre-test", budget: 90 },
  { id: "debate", label: "Agents disagree", budget: 90 },
  { id: "lab", label: "Coin lab", budget: 120 },
  { id: "practice", label: "Diagnosis + practice", budget: 150 },
  { id: "posttest", label: "Post-test", budget: 90 },
  { id: "reflect", label: "Reflect", budget: 60 },
];
export const SESSION_SECONDS = STEPS.reduce((a, s) => a + s.budget, 0); // 600 = 10 minutes

export const AGENTS = {
  teacher: { name: "Asha", role: "Teacher", tone: "explains and gives hints" },
  challenger: { name: "Kabir", role: "Challenger", tone: "challenges ideas (may be wrong!)" },
  evaluator: { name: "Noor", role: "Evaluator", tone: "checks evidence and gives feedback" },
} as const;
export type AgentId = keyof typeof AGENTS;

export type Mis = "M1" | "M2" | "M3";
export const MIS_NAME: Record<Mis, string> = {
  M1: "Gambler's fallacy (\"tails is due\")",
  M2: "Hot hand (\"a winning streak guarantees another win\")",
  M3: "\"Random-looking sequences are more likely\"",
};

export type TestItem = { id: string; probe: string; story: string; ask: string; coins?: string; options: { id: string; text: string; correct?: boolean; tag?: Mis; fb: string }[] };
/** Pre-test: scenario A. No feedback is shown during the pre-test. */
export const PRE: TestItem[] = [
  {
    id: "pre1", probe: "M1/M2", story: "At the school mela, Riya's coin landed HEADS 5 times in a row.", coins: "HHHHH",
    ask: "What is the chance that her next toss is Heads?",
    options: [
      { id: "sure", text: "Heads for sure: the streak will continue", tag: "M2", fb: "" },
      { id: "more", text: "More than 1/2: she's on a lucky streak", tag: "M2", fb: "" },
      { id: "less", text: "Less than 1/2: tails is due now", tag: "M1", fb: "" },
      { id: "half", text: "Exactly 1/2", correct: true, fb: "" },
      { id: "unsure", text: "I can't say", fb: "" },
    ],
  },
  {
    id: "pre2", probe: "M1/M2", story: "Arjun lost the coin toss 4 times in a row in his gully-cricket games.", coins: "TTTT",
    ask: "What is his chance of winning the next toss?",
    options: [
      { id: "more", text: "More than 1/2: his luck has to turn", tag: "M1", fb: "" },
      { id: "less", text: "Less than 1/2: he's on a losing streak", tag: "M2", fb: "" },
      { id: "half", text: "1/2", correct: true, fb: "" },
    ],
  },
  {
    id: "pre3", probe: "LO2", story: "You toss a fair coin 4 times.",
    ask: "Which exact result is more likely?",
    options: [
      { id: "a", text: "H H H H", tag: "M3", fb: "" },
      { id: "b", text: "H T T H", tag: "M3", fb: "" },
      { id: "c", text: "Both equally likely", correct: true, fb: "" },
    ],
  },
];
/** Post-test: scenario B, matched item-by-item to the pre-test. Feedback is shown after each answer. */
export const POST: TestItem[] = [
  {
    id: "post1", probe: "M1/M2", story: "In Ludo, a fair die showed a 6 three times in a row.", ask: "What is the chance the next roll is a 6?",
    options: [
      { id: "less", text: "Less than 1/6: the 6s are used up", tag: "M1", fb: "That's the \"due / used up\" idea in a new costume. A die has no memory: it's still 1/6." },
      { id: "more", text: "More than 1/6: the die is on a streak", tag: "M2", fb: "That's the streak idea. The die isn't \"hot\": still 1/6." },
      { id: "sixth", text: "Exactly 1/6", correct: true, fb: "Yes! Same idea as the coin: no memory, so still 1/6." },
    ],
  },
  {
    id: "post2", probe: "M1/M2", story: "Sana won the coin toss in 4 matches in a row. Her coach says she is GUARANTEED to win the next toss.", ask: "What is her chance of winning the next toss?",
    options: [
      { id: "all", text: "100%: the streak guarantees it", tag: "M2", fb: "A streak never guarantees a win. The next toss is still 1/2." },
      { id: "more", text: "More than 1/2", tag: "M2", fb: "Winning doesn't make the next win more likely for a fair coin. Still 1/2." },
      { id: "less", text: "Less than 1/2: her luck will run out", tag: "M1", fb: "Luck doesn't \"run out\" either; the coin doesn't count wins. Still 1/2." },
      { id: "half", text: "1/2", correct: true, fb: "Right: no guarantee, and no change. Exactly 1/2." },
    ],
  },
  {
    id: "post3", probe: "LO2", story: "You toss a fair coin 6 times.", ask: "Which exact result is more likely?",
    options: [
      { id: "a", text: "T T T T T T", tag: "M3", fb: "Each exact 6-toss result has the same chance: (1/2)⁶ = 1/64." },
      { id: "b", text: "T T H T H H", tag: "M3", fb: "It looks more random, but each exact result is (1/2)⁶ = 1/64." },
      { id: "c", text: "Both equally likely", correct: true, fb: "Exactly: each is (1/2)⁶ = 1/64." },
    ],
  },
];

export type Choice = { id: string; text: string; correct?: boolean; tag?: Mis; fb: string };
export type Task =
  | { id: string; kind: "mcq"; prompt: string; choices: Choice[]; hint: string; model: string; lo: string }
  | { id: string; kind: "number"; prompt: string; answer: number; wrong: { value: number; tag?: Mis; fb: string }[]; correctFb: string; otherFb: string; hint: string; model: string; lo: string }
  | { id: string; kind: "tf"; prompt: string; items: { text: string; answer: boolean; tag?: Mis; fbRight: string; fbWrong: string }[]; hint: string; model: string; lo: string }
  | { id: string; kind: "explain"; prompt: string; hint: string; model: string; lo: string };

export const TASKS: Task[] = [
  {
    id: "q2", kind: "number", lo: "LO2",
    prompt: "You toss a fair coin twice. What is the probability of getting Heads BOTH times? (Type it as a fraction, decimal or %.)",
    answer: 0.25,
    wrong: [
      { value: 0.5, fb: "1/2 is the chance for ONE toss. For two independent tosses, multiply: 1/2 × 1/2." },
      { value: 1 / 3, fb: "Careful: the outcomes are HH, HT, TH, TT — that's 4 equally likely outcomes, not 3. HH is 1 of the 4." },
      { value: 1, fb: "That would mean it always happens. HH is just one of four equally likely outcomes." },
    ],
    correctFb: "Correct! 1/2 × 1/2 = 1/4. HH is one of 4 equally likely outcomes: HH, HT, TH, TT.",
    otherFb: "Not yet. List all outcomes of two tosses (HH, HT, TH, TT). How many are HH?",
    hint: "Write down every possible result of 2 tosses. They are all equally likely.",
    model: "1/4 = 0.25 = 25%, because P(H and H) = 1/2 × 1/2.",
  },
  {
    id: "q5", kind: "explain", lo: "LO3",
    prompt: "Your friend says: \"I lost the toss 5 times, so my luck HAS to turn now.\" In 1–2 sentences, explain what's really going on.",
    hint: "Say two things: does the past change the next toss? And what is the chance of winning the next toss?",
    model: "Each toss is independent and the coin has no memory, so the chance of winning is still 1/2 every time; losing 5 times doesn't make winning more likely.",
  },
];

// ---------------------------------------------------------------- diagnosis → tailored explanation, example and follow-up
export type Diag = "M1" | "M2" | "none";
export const DIAG: Record<Diag, { title: string; what: string; explain: string; example: string; followup: Task }> = {
  M1: {
    title: "Gambler's fallacy",
    what: "You expected the OPPOSITE result to be \"due\" after a streak, as if the coin must balance things out.",
    explain: "A coin doesn't keep score, so it can't \"owe\" you tails. Over many tosses the share of heads gets close to 50% because new tosses dilute the old streak, not because tails comes to pay it back.",
    example: "5 extra heads in 1,000 tosses is just 0.5%; the streak gets lost in the crowd. A captain who lost 5 tosses in a row still has exactly 1/2 for the 6th.",
    followup: {
      id: "f1", kind: "number", lo: "LO1",
      prompt: "Follow-up for you: a fair coin landed Heads in all of the first 8 tosses. In the NEXT 2 tosses, how many Tails do you expect on average?",
      answer: 1,
      wrong: [
        { value: 2, tag: "M1", fb: "That's the \"balance it out\" idea again: the coin doesn't owe you tails. Each of the 2 tosses is 1/2 tails, so on average 2 × 1/2 = 1." },
        { value: 0, fb: "Tails is still possible on every toss: each one is 1/2 tails, so on average 2 × 1/2 = 1." },
      ],
      correctFb: "Exactly: 2 tosses × 1/2 = 1 tail on average. The first 8 heads change nothing. That's the gambler's fallacy beaten.",
      otherFb: "Not yet. Each of the 2 tosses has a 1/2 chance of tails. What is 2 × 1/2?",
      hint: "Forget the first 8 tosses; the coin has. Each new toss: 1/2 tails.",
      model: "1 tail on average (2 × 1/2). Past heads don't make tails due.",
    },
  },
  M2: {
    title: "Winning-streak belief (hot hand)",
    what: "You expected a streak to CONTINUE, as if winning makes the next win more likely, or even certain.",
    explain: "A win doesn't make the next win more likely, and a streak can never guarantee one. The coin isn't \"hot\": every toss is a fresh 1/2, however many wins came before.",
    example: "In your coin lab, right after 3 heads in a row, the next toss was heads only about half the time. (In sport, skill and practice can matter, but a coin's chance never changes.)",
    followup: {
      id: "f1", kind: "mcq", lo: "LO1",
      prompt: "Follow-up for you: Priya won the toss 3 matches in a row. Her teammate says, \"She's on a winning streak, so she'll surely win the next toss.\" What's Priya's chance of winning the 4th toss?",
      choices: [
        { id: "a", text: "100%, the streak guarantees it", tag: "M2", fb: "A streak never guarantees anything. Even after 3 wins, losing the 4th toss is exactly as likely as winning it: 1/2 each." },
        { id: "b", text: "More than 1/2, winners keep winning", tag: "M2", fb: "Winning doesn't \"warm up\" a coin. Remember your lab: after 3 heads, heads came next only about half the time." },
        { id: "c", text: "Less than 1/2, her luck will run out", tag: "M1", fb: "Careful: that's the opposite trap (\"due\" to lose). Luck doesn't run out either; the chance stays 1/2." },
        { id: "d", text: "1/2", correct: true, fb: "Right! 3 wins don't change the 4th toss: still 1/2. No streak guarantees a win." },
      ],
      hint: "Does the coin know Priya won the last 3 times?",
      model: "1/2: the streak doesn't change the next toss, and it never guarantees a win.",
    },
  },
  none: {
    title: "No streak misconception",
    what: "You didn't fall for either streak trap: you predicted 1/2 and backed it with evidence.",
    explain: "Let's check that the idea transfers. Independence isn't just about coins: any fair device with no memory works the same way.",
    example: "A fair die has no memory either: each roll is 1/6 for a 6, whatever came before.",
    followup: {
      id: "f1", kind: "number", lo: "LO1",
      prompt: "Stretch question: a fair die showed a 6 three times in a row. What is the probability that the next roll is a 6?",
      answer: 1 / 6,
      wrong: [
        { value: 0.5, fb: "1/2 is for a coin. A die has 6 equally likely faces." },
        { value: 0, tag: "M1", fb: "A 6 isn't \"used up\": the die has no memory, so it's still 1/6." },
      ],
      correctFb: "Yes: 1/6, exactly as before the streak. Independence works for dice too.",
      otherFb: "Not yet. How many equally likely faces does a die have, and how many of them are a 6?",
      hint: "Same idea as the coin: no memory. How many faces does a die have?",
      model: "1/6: the die has no memory of the three 6s.",
    },
  },
};
export const tasksFor = (d: Diag): Task[] => [DIAG[d].followup, ...TASKS];

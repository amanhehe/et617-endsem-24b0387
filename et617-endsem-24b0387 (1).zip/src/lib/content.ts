// Lesson content: the predict item, 5 practice tasks (4 formats) with feedback for the correct answer and
// for each misconception (M1 gambler's fallacy, M2 hot hand / lucky streak, M3 "random-looking" sequence).
export const ID = "24B0387";
export const CARD = "P3 · T6 · L5 · C4";

export type Step = "welcome" | "pretest" | "debate" | "lab" | "practice" | "posttest" | "reflect" | "summary";
/** six timed stages; welcome, pause, about and summary are supporting screens and are NOT timed */
export const STEPS: { id: Step; label: string; budget: number }[] = [
  { id: "pretest", label: "Check-in + diagnostic", budget: 105 },
  { id: "debate", label: "Mini-lesson + class debate", budget: 105 },
  { id: "lab", label: "Coin lab", budget: 105 },
  { id: "practice", label: "Practice + teach-back", budget: 150 },
  { id: "posttest", label: "Post-test", budget: 75 },
  { id: "reflect", label: "Reflect", budget: 60 },
];
export const SESSION_SECONDS = STEPS.reduce((a, s) => a + s.budget, 0); // 600 = 10 minutes

export const AGENTS = {
  teacher: { name: "Asha", role: "Teacher", tone: "explains and gives hints" },
  challenger: { name: "Kabir", role: "Challenger", tone: "challenges ideas (may be wrong!)" },
  evaluator: { name: "Noor", role: "Evaluator", tone: "checks evidence and gives feedback" },
} as const;
export type AgentId = keyof typeof AGENTS;

export type Mis = "M1" | "M2" | "M3";
export const MIS_NAME: Record<Mis, string> = {
  M1: "Gambler's fallacy (\"tails is due\")",
  M2: "Hot hand (\"a winning streak guarantees another win\")",
  M3: "\"Random-looking sequences are more likely\"",
};

export type TestItem = { id: string; probe: string; story: string; ask: string; coins?: string; options: { id: string; text: string; correct?: boolean; tag?: Mis; fb: string }[] };
/** Pre-test: scenario A. No feedback is shown during the pre-test. */
export const PRE: TestItem[] = [
  {
    id: "k1", probe: "basics", story: "A fair coin is tossed once.", ask: "What is the probability of Heads?",
    options: [
      { id: "half", text: "1/2", correct: true, fb: "Basics are solid: one favourable outcome out of two equally likely ones." },
      { id: "third", text: "1/3 (heads, tails, or it lands on its edge)", fb: "Gap: the outcomes must be equally likely. For a fair coin there are just 2: H and T." },
      { id: "luck", text: "It depends on your luck", tag: "M2", fb: "Shows a belief that luck controls a fair coin. The chance is fixed by the coin: 1/2." },
    ],
  },
  {
    id: "k2", probe: "basics", story: "You toss a fair coin TWICE.", ask: "How many equally likely outcomes are there?",
    options: [
      { id: "three", text: "3 (two heads, two tails, one of each)", fb: "Gap: HT and TH are different outcomes, so there are 4. This leads to answers like P(HH) = 1/3." },
      { id: "four", text: "4 (HH, HT, TH, TT)", correct: true, fb: "Correct: you can list outcomes, which you need for sequences." },
      { id: "two", text: "2", fb: "Gap: two tosses give 2 × 2 = 4 outcomes, not 2." },
    ],
  },
  {
    id: "pre1", probe: "M1/M2", story: "At the school mela, Riya's coin landed HEADS 5 times in a row.", coins: "HHHHH",
    ask: "What is the chance that her next toss is Heads?",
    options: [
      { id: "sure", text: "Heads for sure: the streak will continue", tag: "M2", fb: "Hot hand: you expect a streak to continue, even to be guaranteed." },
      { id: "more", text: "More than 1/2: she's on a lucky streak", tag: "M2", fb: "Hot hand: you expect a streak to make the same result more likely." },
      { id: "less", text: "Less than 1/2: tails is due now", tag: "M1", fb: "Gambler's fallacy: you expect the opposite result to be \"due\" to balance things out." },
      { id: "half", text: "Exactly 1/2", correct: true, fb: "Correct: the streak doesn't change the next toss." },
      { id: "unsure", text: "I can't say", fb: "Unsure: fine. The lab will help you decide." },
    ],
  },
  {
    id: "pre2", probe: "M1/M2", story: "Arjun lost the coin toss 4 times in a row in his gully-cricket games.", coins: "TTTT",
    ask: "What is his chance of winning the next toss?",
    options: [
      { id: "more", text: "More than 1/2: his luck has to turn", tag: "M1", fb: "Gambler's fallacy: you expect luck to \"turn\" after losses." },
      { id: "less", text: "Less than 1/2: he's on a losing streak", tag: "M2", fb: "Streak belief: you expect a losing streak to continue." },
      { id: "half", text: "1/2", correct: true, fb: "Correct: 4 losses don't change the next toss." },
    ],
  },
  {
    id: "pre3", probe: "LO2", story: "You toss a fair coin 4 times.",
    ask: "Which exact result is more likely?",
    options: [
      { id: "a", text: "H H H H", tag: "M3", fb: "You picked the streak; each exact sequence is equally likely, (1/2)⁴ = 1/16." },
      { id: "b", text: "H T T H", tag: "M3", fb: "Random-looking feels more likely, but each exact sequence is (1/2)⁴ = 1/16." },
      { id: "c", text: "Both equally likely", correct: true, fb: "Correct: each exact sequence is 1/16." },
    ],
  },
];
/** Post-test: scenario B, matched item-by-item to the pre-test. Feedback is shown after each answer. */
export const POST: TestItem[] = [
  {
    id: "post1", probe: "M1/M2", story: "In Ludo, a fair die showed a 6 three times in a row.", ask: "What is the chance the next roll is a 6?",
    options: [
      { id: "less", text: "Less than 1/6: the 6s are used up", tag: "M1", fb: "That's the \"due / used up\" idea in a new costume. A die has no memory: it's still 1/6." },
      { id: "more", text: "More than 1/6: the die is on a streak", tag: "M2", fb: "That's the streak idea. The die isn't \"hot\": still 1/6." },
      { id: "sixth", text: "Exactly 1/6", correct: true, fb: "Yes! Same idea as the coin: no memory, so still 1/6." },
    ],
  },
  {
    id: "post2", probe: "M1/M2", story: "Sana won the coin toss in 4 matches in a row. Her coach says she is GUARANTEED to win the next toss.", ask: "What is her chance of winning the next toss?",
    options: [
      { id: "all", text: "100%: the streak guarantees it", tag: "M2", fb: "A streak never guarantees a win. The next toss is still 1/2." },
      { id: "more", text: "More than 1/2", tag: "M2", fb: "Winning doesn't make the next win more likely for a fair coin. Still 1/2." },
      { id: "less", text: "Less than 1/2: her luck will run out", tag: "M1", fb: "Luck doesn't \"run out\" either; the coin doesn't count wins. Still 1/2." },
      { id: "half", text: "1/2", correct: true, fb: "Right: no guarantee, and no change. Exactly 1/2." },
    ],
  },
  {
    id: "post3", probe: "LO2", story: "You toss a fair coin 6 times.", ask: "Which exact result is more likely?",
    options: [
      { id: "a", text: "T T T T T T", tag: "M3", fb: "Each exact 6-toss result has the same chance: (1/2)⁶ = 1/64." },
      { id: "b", text: "T T H T H H", tag: "M3", fb: "It looks more random, but each exact result is (1/2)⁶ = 1/64." },
      { id: "c", text: "Both equally likely", correct: true, fb: "Exactly: each is (1/2)⁶ = 1/64." },
    ],
  },
];

export type Choice = { id: string; text: string; correct?: boolean; tag?: Mis; fb: string };
export type Task =
  | { id: string; kind: "mcq"; prompt: string; choices: Choice[]; hint: string; model: string; lo: string }
  | { id: string; kind: "number"; prompt: string; answer: number; wrong: { value: number; tag?: Mis; fb: string }[]; correctFb: string; otherFb: string; hint: string; model: string; lo: string }
  | { id: string; kind: "tf"; prompt: string; items: { text: string; answer: boolean; tag?: Mis; fbRight: string; fbWrong: string }[]; hint: string; model: string; lo: string }
  | { id: string; kind: "explain"; prompt: string; hint: string; model: string; lo: string };

export const TASKS: Task[] = [
  {
    id: "q2", kind: "number", lo: "LO2",
    prompt: "You toss a fair coin twice. What is the probability of getting Heads BOTH times? (Type it as a fraction, decimal or %.)",
    answer: 0.25,
    wrong: [
      { value: 0.5, fb: "1/2 is the chance for ONE toss. For two independent tosses, multiply: 1/2 × 1/2." },
      { value: 1 / 3, fb: "Careful: the outcomes are HH, HT, TH, TT — that's 4 equally likely outcomes, not 3. HH is 1 of the 4." },
      { value: 1, fb: "That would mean it always happens. HH is just one of four equally likely outcomes." },
    ],
    correctFb: "Correct! 1/2 × 1/2 = 1/4. HH is one of 4 equally likely outcomes: HH, HT, TH, TT.",
    otherFb: "Not yet. List all outcomes of two tosses (HH, HT, TH, TT). How many are HH?",
    hint: "Write down every possible result of 2 tosses. They are all equally likely.",
    model: "1/4 = 0.25 = 25%, because P(H and H) = 1/2 × 1/2.",
  },
  {
    id: "q5", kind: "explain", lo: "LO3",
    prompt: "Teach it back: your friend says, \"I lost the toss 5 times, so my luck HAS to turn now.\" Explain to them, in your own words, why that isn't true.",
    hint: "A good explanation has 3 parts: (1) does the coin remember? (2) what is the chance on the next toss? (3) so what does the streak change?",
    model: "Each toss is independent: the coin has no memory. So the chance of winning is still 1/2 on every toss, and losing 5 times doesn't make a win any more \"due\".",
  },
];

// ---------------------------------------------------------------- diagnosis → tailored explanation, example and follow-up
export type Diag = "M1" | "M2" | "none";
export const DIAG: Record<Diag, { title: string; what: string; explain: string; example: string; followup: Task }> = {
  M1: {
    title: "Gambler's fallacy",
    what: "You expected the OPPOSITE result to be \"due\" after a streak, as if the coin must balance things out.",
    explain: "A coin doesn't keep score, so it can't \"owe\" you tails. Over many tosses the share of heads gets close to 50% because new tosses dilute the old streak, not because tails comes to pay it back.",
    example: "5 extra heads in 1,000 tosses is just 0.5%; the streak gets lost in the crowd. A captain who lost 5 tosses in a row still has exactly 1/2 for the 6th.",
    followup: {
      id: "f1", kind: "number", lo: "LO1",
      prompt: "Follow-up for you: a fair coin landed Heads in all of the first 8 tosses. In the NEXT 2 tosses, how many Tails do you expect on average?",
      answer: 1,
      wrong: [
        { value: 2, tag: "M1", fb: "That's the \"balance it out\" idea again: the coin doesn't owe you tails. Each of the 2 tosses is 1/2 tails, so on average 2 × 1/2 = 1." },
        { value: 0, fb: "Tails is still possible on every toss: each one is 1/2 tails, so on average 2 × 1/2 = 1." },
      ],
      correctFb: "Exactly: 2 tosses × 1/2 = 1 tail on average. The first 8 heads change nothing. That's the gambler's fallacy beaten.",
      otherFb: "Not yet. Each of the 2 tosses has a 1/2 chance of tails. What is 2 × 1/2?",
      hint: "Forget the first 8 tosses; the coin has. Each new toss: 1/2 tails.",
      model: "1 tail on average (2 × 1/2). Past heads don't make tails due.",
    },
  },
  M2: {
    title: "Winning-streak belief (hot hand)",
    what: "You expected a streak to CONTINUE, as if winning makes the next win more likely, or even certain.",
    explain: "A win doesn't make the next win more likely, and a streak can never guarantee one. The coin isn't \"hot\": every toss is a fresh 1/2, however many wins came before.",
    example: "In your coin lab, right after 3 heads in a row, the next toss was heads only about half the time. (In sport, skill and practice can matter, but a coin's chance never changes.)",
    followup: {
      id: "f1", kind: "mcq", lo: "LO1",
      prompt: "Follow-up for you: Priya won the toss 3 matches in a row. Her teammate says, \"She's on a winning streak, so she'll surely win the next toss.\" What's Priya's chance of winning the 4th toss?",
      choices: [
        { id: "a", text: "100%, the streak guarantees it", tag: "M2", fb: "A streak never guarantees anything. Even after 3 wins, losing the 4th toss is exactly as likely as winning it: 1/2 each." },
        { id: "b", text: "More than 1/2, winners keep winning", tag: "M2", fb: "Winning doesn't \"warm up\" a coin. Remember your lab: after 3 heads, heads came next only about half the time." },
        { id: "c", text: "Less than 1/2, her luck will run out", tag: "M1", fb: "Careful: that's the opposite trap (\"due\" to lose). Luck doesn't run out either; the chance stays 1/2." },
        { id: "d", text: "1/2", correct: true, fb: "Right! 3 wins don't change the 4th toss: still 1/2. No streak guarantees a win." },
      ],
      hint: "Does the coin know Priya won the last 3 times?",
      model: "1/2: the streak doesn't change the next toss, and it never guarantees a win.",
    },
  },
  none: {
    title: "No streak misconception",
    what: "You didn't fall for either streak trap: you predicted 1/2 and backed it with evidence.",
    explain: "Let's check that the idea transfers. Independence isn't just about coins: any fair device with no memory works the same way.",
    example: "A fair die has no memory either: each roll is 1/6 for a 6, whatever came before.",
    followup: {
      id: "f1", kind: "number", lo: "LO1",
      prompt: "Stretch question: a fair die showed a 6 three times in a row. What is the probability that the next roll is a 6?",
      answer: 1 / 6,
      wrong: [
        { value: 0.5, fb: "1/2 is for a coin. A die has 6 equally likely faces." },
        { value: 0, tag: "M1", fb: "A 6 isn't \"used up\": the die has no memory, so it's still 1/6." },
      ],
      correctFb: "Yes: 1/6, exactly as before the streak. Independence works for dice too.",
      otherFb: "Not yet. How many equally likely faces does a die have, and how many of them are a 6?",
      hint: "Same idea as the coin: no memory. How many faces does a die have?",
      model: "1/6: the die has no memory of the three 6s.",
    },
  },
};
export const tasksFor = (d: Diag): Task[] => [DIAG[d].followup, ...TASKS];

// ---------------------------------------------------------------- adaptive extras (chosen by the planner, not fixed)
export const EXTRA: Record<string, Task> = {
  // revisit the diagnosed misconception in a NEW context
  "r1-M1": {
    id: "r1", kind: "mcq", lo: "LO1",
    prompt: "Revisit: a fair spinner is half red, half blue. It landed on RED 6 times in a row. What is the chance it lands on BLUE next?",
    choices: [
      { id: "a", text: "More than 1/2: blue is due", tag: "M1", fb: "Same trap in a new costume: the spinner doesn't owe you blue. Still 1/2." },
      { id: "b", text: "1/2", correct: true, fb: "Yes! Red or blue, the spinner has no memory: 1/2." },
      { id: "c", text: "Less than 1/2: red is on a streak", tag: "M2", fb: "Careful, that's the opposite trap (streak). Still 1/2." },
    ],
    hint: "Half red, half blue, and no memory. What's the chance of blue on any spin?",
    model: "1/2: the spinner is independent of earlier spins.",
  },
  "r1-M2": {
    id: "r1", kind: "mcq", lo: "LO1",
    prompt: "Revisit: Anu rolled a 6 on a fair die twice in a row. Her friend says, \"She's hot, she'll surely roll a 6 again!\" What is the chance of a 6 next?",
    choices: [
      { id: "a", text: "Certain: she's on a streak", tag: "M2", fb: "A streak never guarantees anything. The die has no memory: still 1/6." },
      { id: "b", text: "More than 1/6", tag: "M2", fb: "Rolling 6s doesn't \"warm up\" the die. Still 1/6." },
      { id: "c", text: "1/6", correct: true, fb: "Right! 1 face out of 6, whatever came before." },
    ],
    hint: "How many faces does a die have, and does it remember earlier rolls?",
    model: "1/6: each roll is independent.",
  },
  // easier prerequisite when basics were weak
  e1: {
    id: "e1", kind: "mcq", lo: "LO2",
    prompt: "Step back: which list shows ALL the equally likely outcomes of tossing a coin twice?",
    choices: [
      { id: "a", text: "HH, HT, TT", fb: "Missing one: HT (heads then tails) and TH (tails then heads) are different." },
      { id: "b", text: "HH, HT, TH, TT", correct: true, fb: "Yes: 4 equally likely outcomes. That's why P(HH) = 1 out of 4." },
      { id: "c", text: "H, T", fb: "That's one toss. Two tosses give 2 × 2 = 4 outcomes." },
    ],
    hint: "Write the first toss, then the second toss. Is \"heads then tails\" the same as \"tails then heads\"?",
    model: "HH, HT, TH, TT: 4 outcomes.",
  },
  // harder sequence question when the learner is strong and confident
  q2h: {
    id: "q2h", kind: "number", lo: "LO2",
    prompt: "Level up: you toss a fair coin THREE times. What is the probability of getting Heads all three times?",
    answer: 0.125,
    wrong: [
      { value: 0.5, fb: "1/2 is for one toss. For three independent tosses, multiply: 1/2 × 1/2 × 1/2." },
      { value: 0.25, fb: "That's two tosses. Multiply by 1/2 once more for the third." },
      { value: 1 / 3, fb: "Not a count of 3 outcomes: there are 2 × 2 × 2 = 8 equally likely outcomes." },
    ],
    correctFb: "Correct! (1/2)³ = 1/8: HHH is 1 of 8 equally likely outcomes.",
    otherFb: "Not yet. How many equally likely outcomes do 3 tosses have? How many are HHH?",
    hint: "Multiply the chance for each toss.",
    model: "1/8 = 0.125: P(HHH) = 1/2 × 1/2 × 1/2.",
  },
  // reading evidence again when the lab verdict went wrong
  lab1: {
    id: "lab1", kind: "mcq", lo: "LO3",
    prompt: "Evidence check: a class tossed coins and found 400 moments after H H H. The next toss was heads 196 times (49%). What does this show?",
    choices: [
      { id: "a", text: "Tails is due after a streak", tag: "M1", fb: "If tails were due, heads would be well below 50%. 49% is just normal variation around 50%." },
      { id: "b", text: "Heads keeps going after a streak", tag: "M2", fb: "If streaks continued, heads would be well above 50%. 49% is close to 50%." },
      { id: "c", text: "The next toss is still about 1/2", correct: true, fb: "Yes: 49% from 400 moments is well within normal variation around 50%. The streak changed nothing." },
    ],
    hint: "Is 49% far from 50%, with 400 moments? (Normal range is about 45%–55%.)",
    model: "About 1/2: 49% is within normal chance variation of 50%.",
  },
};

/** Asha's 1-minute lesson: teach before asking. Each idea is shown, and read aloud if voice is on. */
export const LESSON: { title: string; say: string; visual: string; caption: string }[] = [
  { title: "One toss", say: "Let's start simple. A fair coin has two sides, heads and tails, and they are equally likely. So the chance of heads is 1 out of 2: that's 1/2.", visual: "HT", caption: "2 equally likely outcomes → P(H) = 1/2" },
  { title: "No memory", say: "Here's the big idea: tosses are independent. The coin has no memory. It doesn't know what happened before, so every toss starts fresh at 1/2.", visual: "HHHHH?", caption: "After H H H H H → next toss is still 1/2" },
  { title: "Many tosses", say: "Streaks happen all the time in random tosses. But over many tosses, the share of heads settles near 50%, because new tosses dilute the old ones, not because the coin catches up.", visual: "HTTHHHTHTTHH", caption: "Streaks are normal; the % still settles near 50%" },
  { title: "Two tosses", say: "For two tosses, list the outcomes: HH, HT, TH, TT. Four equally likely outcomes. HH is one of them, so P of HH is 1/4. Or multiply: 1/2 times 1/2.", visual: "HH HT TH TT", caption: "P(HH) = 1/2 × 1/2 = 1/4" },
];

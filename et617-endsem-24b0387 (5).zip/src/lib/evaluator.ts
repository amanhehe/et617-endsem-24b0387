// The Evaluator agent's check of a free-text explanation (Practice Q5).
// 1) An AI model scores it through /api/agent (see api/agent.js);
// 2) the output is validated and cross-checked against a rule-based rubric;
// 3) if the AI is unavailable or its output fails a check, the rule-based rubric is used (clearly labelled).
export type Tag = "none" | "M1" | "M2" | "other";
export type Verdict = { score: 0 | 1 | 2; tag: Tag; feedback: string; source: "ai" | "rules"; note?: string };

const NEG = String.raw`(not|isn'?t|is not|no|never|doesn'?t|does not|won'?t|will not|can'?t|cannot|nothing)`;
const negated = (text: string, word: string) =>
  new RegExp(`${NEG}\\s+(\\w+\\s+){0,4}${word}`, "i").test(text);

export function rubric(textRaw: string): Omit<Verdict, "source"> {
  const text = textRaw.toLowerCase();
  const m1Words = ["due", "turn", "balance", "owed", "bound to", "my chance now"];
  const m2Words = ["hot", "lucky", "unlucky", "streak will continue", "keep losing", "keep winning"];
  const hits = (words: string[]) => words.some((w) => text.includes(w) && !negated(text, w.split(" ")[0]!));
  const indep =
    /(independ|memory|remember|fresh|each toss|every toss|separate|on its own|not (affect|change|depend)|doesn'?t (affect|change|depend)|does not (affect|change|depend)|no effect|no connection)/.test(text);
  const half = /(1\/2|half|50 ?%|50-50|fifty|0\.5|equal chance|same chance|equally likely)/.test(text);
  if (hits(m1Words) && !indep)
    return {
      score: 0,
      tag: "M1",
      feedback:
        "This still sounds like 'my turn is due'. The coin doesn't keep score of past tosses, so the next one is still 1/2.",
    };
  if (hits(m2Words) && !indep)
    return {
      score: 0,
      tag: "M2",
      feedback:
        "This sounds like the 'lucky/unlucky streak' idea. A coin can't be on a streak; every toss is a fresh 1/2.",
    };
  const score = ((indep ? 1 : 0) + (half ? 1 : 0)) as 0 | 1 | 2;
  const feedback =
    score === 2
      ? "Spot on: you said the tosses are independent AND that the chance stays 1/2. That's exactly the idea."
      : score === 1 && indep
        ? "Good: you said past tosses don't affect the next. Add the number too: the chance stays 1/2."
        : score === 1
          ? "Good: you said the chance is 1/2. Add the reason: each toss is independent (the coin has no memory)."
          : "Try to say two things: (1) past tosses don't affect the next one, (2) the chance is still 1/2.";
  return { score, tag: score === 0 ? "other" : "none", feedback };
}

const BANNED = /(is due|are due|luck (will|has to|must) (turn|change)|more likely (after|because of) (a|the) streak|hot streak (will )?continue)/i;

/** Validate a model reply; returns null if it must not be shown. */
export function validateAi(raw: unknown): { score: 0 | 1 | 2; tag: Tag; feedback: string } | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const score = o.score, tag = o.misconception, fb = o.feedback;
  if (score !== 0 && score !== 1 && score !== 2) return null;
  if (tag !== "none" && tag !== "M1" && tag !== "M2" && tag !== "other") return null;
  if (typeof fb !== "string" || fb.trim().length < 10 || fb.length > 320) return null;
  if (BANNED.test(fb)) return null; // never let the AI endorse the misconception
  return { score, tag, feedback: fb.trim() };
}

export async function evaluateExplanation(text: string): Promise<Verdict> {
  const rules = rubric(text);
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 9000);
    const r = await fetch("/api/agent", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ task: "evaluate", answer: text.slice(0, 600) }),
      signal: ctl.signal,
    });
    clearTimeout(t);
    if (!r.ok) throw new Error(String(r.status));
    const ai = validateAi(await r.json());
    if (!ai) return { ...rules, source: "rules", note: "AI reply failed the safety/format check, so the rule-based Evaluator was used." };
    // cross-check: if the rubric clearly found a misconception, a full AI score is not trusted
    if (rules.tag === "M1" || rules.tag === "M2") {
      if (ai.score === 2) return { ...rules, source: "rules", note: "AI and rubric disagreed; the stricter rubric result is shown." };
    }
    return { ...ai, source: "ai" };
  } catch {
    return { ...rules, source: "rules", note: "AI not reachable, so the rule-based Evaluator checked this (offline mode)." };
  }
}

// ---------------------------------------------------------------- teach-back: which concepts are present / missing
export type ConceptId = "independence" | "chance" | "streak";
export const CONCEPTS: { id: ConceptId; label: string }[] = [
  { id: "independence", label: "The coin has no memory: tosses are independent" },
  { id: "chance", label: "The chance stays 1/2 on the next toss" },
  { id: "streak", label: "So the streak doesn't make a win due (or guaranteed)" },
];
export type TeachBack = { found: Record<ConceptId, boolean>; tag: Tag; source: "ai" | "rules"; note?: string };

export function teachBackRules(raw: string): Omit<TeachBack, "source"> {
  const t = raw.toLowerCase();
  const r = rubric(raw);
  const independence = /(independ|memory|remember|fresh|separate|on its own|not (affect|change|depend)|doesn'?t (affect|change|depend)|does not (affect|change|depend)|no effect|no connection|past (tosses|results) (don'?t|do not|can'?t))/.test(t);
  const chance = /(1\/2|half|50 ?%|50-50|fifty|0\.5|equal chance|same chance|equally likely)/.test(t);
  const streak =
    /(not|n'?t|no|never|nothing)\s+(\w+\s+){0,4}(due|turn|balance|guarantee|more likely|change)/.test(t) ||
    /(streak|losing|lost|past|before|previous)[^.]{0,60}(doesn'?t|does not|won'?t|can'?t|cannot|don'?t|do not|no)\s+(\w+\s+){0,3}(matter|change|affect|make|mean)/.test(t);
  return { found: { independence, chance, streak }, tag: r.tag === "M1" || r.tag === "M2" ? r.tag : "none" };
}

export async function evaluateTeachBack(text: string): Promise<TeachBack> {
  const rules = teachBackRules(text);
  try {
    const ctl = new AbortController();
    const tm = setTimeout(() => ctl.abort(), 9000);
    const r = await fetch("/api/agent", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ task: "teachback", answer: text.slice(0, 600) }), signal: ctl.signal });
    clearTimeout(tm);
    if (!r.ok) throw new Error();
    const o = (await r.json()) as { concepts?: Record<string, unknown>; misconception?: unknown };
    const ok = o && o.concepts && ["independence", "chance", "streak"].every((k) => typeof o.concepts![k] === "boolean") && ["none", "M1", "M2", "other"].includes(String(o.misconception));
    if (!ok) return { ...rules, source: "rules", note: "AI reply failed the format check; rule-based Evaluator used." };
    // if the rubric found a misconception, the AI cannot clear it; the AI may only ADD concepts the rules missed
    const found = { ...rules.found } as Record<ConceptId, boolean>;
    if (rules.tag === "none") for (const k of ["independence", "chance", "streak"] as ConceptId[]) found[k] = found[k] || (o.concepts![k] as boolean);
    return { found, tag: rules.tag !== "none" ? rules.tag : (o.misconception as Tag), source: "ai" };
  } catch {
    return { ...rules, source: "rules", note: "AI not reachable; rule-based Evaluator used (offline mode)." };
  }
}

// Vercel serverless function: the Evaluator agent's AI check of a learner's explanation.
// The API key lives only in the Vercel environment variable ANTHROPIC_API_KEY (never in the code).
const SYSTEM = `You are the EVALUATOR agent in a probability lesson for an anxious Class 10 student (India) who failed this topic once.
Topic: independent events with a fair coin, the gambler's fallacy and the "hot hand" / lucky-streak belief.
Task the student answered: "Your friend says: 'I lost the toss 5 times, so my luck has to turn now.' Explain what's really going on in 1-2 sentences."
Model answer: "Each toss is independent and the coin has no memory, so the chance is still 1/2 every time; losing 5 times doesn't make winning more likely."
Rubric: score 2 = mentions independence/no memory AND that the chance stays 1/2; 1 = only one of these; 0 = missing both or endorses the misconception.
Misconceptions: M1 = gambler's fallacy ("due", "has to turn", "balance out"); M2 = hot hand / lucky or unlucky streak continues.
Reply with ONLY a JSON object: {"score":0|1|2,"misconception":"none"|"M1"|"M2"|"other","feedback":"<max 40 words, warm, simple English, no shaming, never say a past streak changes the next toss>"}`;

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(503).json({ error: "AI not configured" });
  const answer = String((req.body && req.body.answer) || "").slice(0, 600);
  if (!answer.trim()) return res.status(400).json({ error: "empty answer" });
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "claude-haiku-5-5",
        max_tokens: 200,
        system: SYSTEM,
        messages: [{ role: "user", content: `Student's answer: """${answer}"""` }],
      }),
    });
    if (!r.ok) return res.status(502).json({ error: "model error " + r.status });
    const data = await r.json();
    const text = (data.content || []).map((c) => c.text || "").join("");
    const json = text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1);
    return res.status(200).json(JSON.parse(json));
  } catch (e) {
    return res.status(502).json({ error: "AI call failed" });
  }
}

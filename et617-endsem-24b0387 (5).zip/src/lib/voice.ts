// Voice: the agents can speak (speech synthesis) and the learner can answer by voice (speech recognition).
// Both are built into Chrome/Edge on Android and desktop; if missing, the app simply works by text.
export const canSpeak = () => typeof window !== "undefined" && "speechSynthesis" in window;
type Rec = { lang: string; interimResults: boolean; continuous: boolean; onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null; onend: (() => void) | null; onerror: (() => void) | null; start: () => void; stop: () => void };
const RecCtor = (): (new () => Rec) | null =>
  typeof window === "undefined" ? null : ((window as unknown as { SpeechRecognition?: new () => Rec; webkitSpeechRecognition?: new () => Rec }).SpeechRecognition ?? (window as unknown as { webkitSpeechRecognition?: new () => Rec }).webkitSpeechRecognition ?? null);
export const canListen = () => !!RecCtor();

const VOICE: Record<string, { pitch: number; rate: number }> = { teacher: { pitch: 1.05, rate: 0.95 }, challenger: { pitch: 0.85, rate: 1.0 }, evaluator: { pitch: 1.2, rate: 0.95 } };
export function speak(text: string, who: "teacher" | "challenger" | "evaluator" = "teacher") {
  if (!canSpeak() || !text.trim()) return;
  try {
    const u = new SpeechSynthesisUtterance(text.replace(/[↳🔁🧭✅🌱💡🔊🎤]/gu, "").replace(/1\/2/g, "one half").replace(/1\/4/g, "one quarter").replace(/1\/6/g, "one sixth").replace(/1\/8/g, "one eighth"));
    const v = window.speechSynthesis.getVoices();
    u.voice = v.find((x) => /en-IN/i.test(x.lang)) ?? v.find((x) => /^en/i.test(x.lang)) ?? null;
    u.lang = u.voice?.lang ?? "en-IN";
    u.pitch = VOICE[who]!.pitch;
    u.rate = VOICE[who]!.rate;
    window.speechSynthesis.speak(u);
  } catch {
    /* speech not available: text stays on screen */
  }
}
export const stopSpeaking = () => { try { if (canSpeak()) window.speechSynthesis.cancel(); } catch { /* ignore */ } };

/** Listen once; streams the transcript; returns a stop function. */
export function listen(onText: (t: string, final: boolean) => void, onEnd: () => void): () => void {
  const C = RecCtor();
  if (!C) { onEnd(); return () => {}; }
  const r = new C();
  r.lang = "en-IN";
  r.interimResults = true;
  r.continuous = false;
  r.onresult = (e) => {
    let t = "", fin = false;
    for (let i = 0; i < e.results.length; i++) { t += e.results[i]![0]!.transcript; fin = e.results[i]!.isFinal; }
    onText(t, fin);
  };
  r.onend = onEnd;
  r.onerror = onEnd;
  try { r.start(); } catch { onEnd(); }
  return () => { try { r.stop(); } catch { /* ignore */ } };
}

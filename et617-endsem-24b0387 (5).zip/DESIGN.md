# DESIGN.md — Lucky Streak?

**ID:** 24B0387 · **P3** Multi-agent collaborative learning · **T6** Probability: is a "lucky streak" real? (Cl. 9–10) · **L5** Anxious repeat learner · **C4** 10-minute sessions

## D1 · Problem
Students can use *P = favourable/total*, yet still believe a streak changes the next toss: "tails is due" (**gambler's fallacy**) or "she's winning, so she'll surely win again" (**hot hand**). Textbooks never test this belief, and an anxious learner who failed once avoids the topic. In this app, three AI agents disagree about a streak; the learner settles it with coin-toss evidence, all in one calm 10-minute session.

**Scope:** the claim is tested for **independent tosses of a fair coin (or die)**. Real-world streaks such as a batsman in form can involve changing skill or conditions; that is a different question, and the app says so.

**Learning outcomes**
- **LO1:** *Predict* that P(heads) after any streak is still 1/2, and *explain* this with independence.
- **LO2:** *Compute* a sequence's probability by multiplying, and *compare* sequences (each exact sequence of 4 tosses = 1/16).
- **LO3:** *Use* simulation evidence, including sample variation, to *judge* conflicting claims.

**Context:** at home in the evening, on her own Android phone; 10 minutes, possibly interrupted.

## D2 · Persona
**Kavya Deshmukh, 15, Class 10, Pune (Maharashtra State Board, English medium; Marathi at home).** Father runs a small hardware shop; mother is a homemaker. She goes to group tuition three evenings a week.

- **History:** scored 9/25 in the probability unit test and must re-sit it. Her teacher returned the paper in front of the class. Since then she says "I'm just bad at maths".
- **Learning gaps:**
  - **Knows:** fractions, %, and P = favourable/total for a single coin or die.
  - **Gap 1:** has never met *independence*; thinks of past results as "affecting" the next one.
  - **Gap 2:** adds probabilities instead of multiplying (says P(HH) = 1/2 + 1/2, or "1/3 because there are 3 outcomes: HH, HT, TT").
  - **Gap 3:** has never seen data vary; one surprising result convinces her.
- **Misconceptions:**
  - **M1, gambler's fallacy:** "After a run of heads, tails is due." This comes from cricket tosses ("we'll win it this time").
  - **M2, hot hand:** "A winning streak guarantees, or makes more likely, another win." This comes from the idea that a player "in form" will keep winning.
- **When confused:** she doesn't ask. She guesses the first option that "sounds right", or freezes and closes the app. She re-reads long text without taking it in, and copies a classmate's answer instead of trying.
- **Anxiety triggers:**
  - red crosses and "Wrong!";
  - visible countdown timers;
  - being compared with others;
  - a wall of formulas;
  - being asked to explain out loud in front of people.
- **Confidence issues:**
  - She under-rates herself even when she is right ("I was just guessing").
  - When a guess happens to be right she becomes over-sure, then crashes on the next question.
  - Once she has decided she is "bad at it" she stops trying.
- **Preferred learning style:**
  - learns by *seeing it happen* and short worked examples;
  - prefers everyday Indian contexts (cricket toss, Ludo, the mela);
  - short sentences, one idea at a time;
  - private practice, where nobody watches her mistakes;
  - likes being *asked her opinion* rather than told.
- **Device / time:** her own low-cost Android phone (shared data pack); about 10 minutes after tuition, often interrupted by family.
- **Motivation:** pass the re-sit without embarrassment; she wants to feel in control.

**How each trait shapes the app**
| Kavya's trait | App feature |
|---|---|
| Gap 1: no idea of independence | The Challenger voices her belief; she tests it in the coin lab; the Teacher's explanation is "the coin has no memory" |
| Gap 2: adds instead of multiplying, the "3 outcomes" error | Numeric task with targeted feedback for 1/2 and for 1/3, plus a hint to list HH, HT, TH, TT |
| Gap 3: trusts a single result | Repeated lab batches, a 50% theory line and a "normal range" band that shows how small samples jump around |
| M1 or M2 | The **explicit diagnosis** picks a different explanation, example, follow-up question and hints for each |
| Guesses or freezes when confused | **Adaptive hints:** a one-tap hint tailored to her diagnosis; 2 tries, then a model answer, so she is never stuck |
| Doesn't ask for help | Agents step in on their own: after a wrong lab verdict the Evaluator nudges; after a second, the Teacher walks her through it |
| Triggers: red crosses, "Wrong!", comparison | **Supportive feedback:** "Not yet", "very common idea", no red, no ranking, nothing graded; feedback quotes her *own* lab data |
| Trigger: countdown timer | The clock shows time *used* ("m:ss of 10:00"), in calm wording; going over is "fine, finish calmly" |
| Trigger: wall of formulas | One idea per screen; formulas only as 1/2 × 1/2; short sentences |
| Under-confident even when right | One-tap confidence check; "You felt you were guessing, but you reasoned correctly. Trust it" |
| Over-sure after a lucky guess | Calibration message in the summary when confidence > post-test result |
| Likes being asked, not told | **Agent interaction:** she is the judge of the Teacher vs Challenger disagreement, not a listener |
| Anxious in front of others | Private, single-learner app; the Challenger is told to "keep it gentle" when she says she is worried |
| "Bad at maths" self-image | **Assessment:** the pre-test has no feedback, then the summary shows her own pre → post gain on matched items |
| Interrupted by family | Pause & save on every screen; "Welcome back, continue from Stage N" |
| Low-cost phone, limited data | Phone-first layout, large tap targets, no images or video, works offline except the optional AI check |

## D3 · Content: six timed stages = exactly 10:00
Welcome, Pause, About and Summary are **supporting screens and are not timed**.

| # | Stage | Budget | What happens |
|---|---|---|---|
| 1 | Check-in + diagnostic | 1:45 | Feeling, then **5 diagnostic MCQs** with no feedback (2 basics + 3 matched pre-test items), then a **"What your answers tell us"** screen: a knowledge profile (basics / streaks / sequences), what each wrong answer reveals, and the main misconception |
| 2 | Mini-lesson + class debate | 1:45 | **Asha's 1-minute lesson** (4 ideas with coin visuals: one toss = 1/2 · no memory · many tosses → 50% · two tosses = 1/4), then a **classroom** debate: Challenger vs Teacher on the learner's own answer, with the Evaluator handing the decision to the learner |
| 3 | Coin lab | 1:45 | Repeated batches; P(H right after HHH) vs the theoretical 50%; variation range; the learner's verdict |
| 4 | Practice + teach-back | 2:30 | A verified explanation (agent pipeline), the tailored follow-up, a numeric task, then the **teach-back** |
| 5 | Post-test | 1:15 | 3 items in **new scenarios** (scenario B), mirroring the pre-test |
| 6 | Reflect | 1:00 | Confidence, then a personalised summary showing pre → post |
| | **Total** | **10:00** | |

**Pre-test (scenario A)** vs **post-test (scenario B)**, matched item by item:
| Probes | Pre-test | Post-test |
|---|---|---|
| M1 / M2 diagnosis | Riya's coin: 5 heads, so P(next H)? | A Ludo die: three 6s, so P(next 6)? |
| M2 "guarantee" / M1 "luck turns" | Arjun lost the toss 4 times, so P(he wins next)? | Sana won the toss 4 matches in a row and the coach says she's guaranteed to win the next, so P? |
| LO2 sequences | HHHH vs HTTH (4 tosses)? | TTTTTT vs TTHTHH (6 tosses)? |

**Diagnosis → different explanation, example, follow-up and hints**
| | M1: gambler's fallacy | M2: hot hand | None |
|---|---|---|---|
| Explanation | The coin doesn't keep score or "owe" tails; the share of heads nears 50% by *dilution*, not payback | A win never makes the next more likely, and a streak never guarantees one | Independence transfers to any memoryless device |
| Example | 5 extra heads in 1,000 tosses = 0.5%; a captain who lost 5 tosses still has 1/2 | Your lab: heads after HHH was about 50% | A die has no memory: still 1/6 |
| Follow-up | 8 heads, then how many tails expected in the next 2? → **1** | Priya won 3 tosses, "sure to win the 4th"? → **1/2** | A die after three 6s? → **1/6** |

**Practice** (hint, 2 tries, then the model answer):
1. The tailored follow-up (above).
2. **Numeric:** P(HH)? → **1/4**. Feedback for 1/2 ("multiply") and for 1/3 ("there are 4 outcomes").
3. **Teach-back (her own words):** "I lost 5 times, so my luck HAS to turn." Kavya explains why this isn't true.
   - **The Evaluator ticks 3 concepts:** independence (no memory), the chance stays 1/2, and so the streak changes nothing.
   - **The Teacher guides one gap at a time** before the next attempt:
     - independence → "does the coin know earlier tosses?";
     - chance → "what is the chance on the next toss?";
     - streak → "so does losing 5 times make a win due?" (or "guarantee" for M2).
   - If she endorses the misconception, the Teacher points her back to her lab result.
   - Up to 3 attempts, then the model answer. **Model answer:** "Each toss is independent: the coin has no memory. So the chance is still 1/2, and losing 5 times doesn't make a win due."
   - **Concept check:** rules, plus an optional AI check. The AI can only *add* concepts, and can never clear a misconception the rules found.

**Coin lab:** the learner **chooses the pattern** (H, HH, HHH, HHHH, HHHHH, T, TT, TTT, HTH) and **the number of tosses** (10 / 100 / 1000, or any number up to 5000). Every time the pattern occurs, the app records the next toss. A comparison chart shows *heads-next after every pattern side by side*, all near 50%: the past flips don't affect the next one.
- **Shown per batch and in total:** P(H | after HHH), compared with the **theoretical 50%**.
- **Normal range for chance variation:** 50% ± 98/√n percentage points (n = number of HHH occurrences, roughly 95%).
- **The message:** small batches jump around; more data settles near 50%; a gap inside the range is just chance.
- **Also shown:** streaks are normal. P(a run of 5+ heads in 100 tosses) ≈ 81%, computed exactly.

## Agents (P3): collaboration through shared notes
The agents share one **notes board**: feeling, diagnosis, lab result, wrong verdicts and hints used. Each reads it before speaking, and every influenced message shows **"↳ using X's note"**:
1. **Teacher → Challenger** "anxious learner": the Challenger uses a gentle version of the challenge.
2. **Evaluator → Teacher** diagnosis: chooses the explanation, example, follow-up question and hints.
3. **Evaluator → Teacher** lab result: practice feedback quotes the learner's *own* lab percentage.
4. **Evaluator → Challenger** verdict and evidence: the Challenger concedes using the learner's data.
5. **Challenger → Evaluator** concession: the summary records the resolved disagreement.

**Reasoning pipeline:** the Teacher proposes, the Challenger tests, the Evaluator verifies the maths, and the Teacher revises (see D6).

**Disagreement → decision → resolution:**
1. The Challenger argues the learner's pre-test idea (labelled "Challenge: I might be wrong").
2. The Teacher disagrees.
3. The Evaluator: "Don't pick the louder voice; test it."
4. The learner runs the lab and **chooses** who the evidence supports.
5. A wrong verdict gets a nudge to look at the number, not the answer; a second gets a worked explanation.
6. The losing agent concedes, citing the data.

## Adaptivity: the path is built from Kavya's data, not fixed
| Signal | Decision rule | What changes |
|---|---|---|
| Diagnostic answers (pre1, pre2) | Majority tag: M1, M2 or none | The Challenger's argument; the explanation, example, follow-up and hints |
| "Sure" + wrong in the diagnostic, or the follow-up needed a hint or more than 1 try | Revisit the weak concept | Adds **r1**: the same misconception in a *new context* (M1 → spinner, M2 → die) |
| Basics item wrong (k1 or k2) | Go easier first | Adds **e1** "list the 4 outcomes" before multiplying |
| No misconception, basics and sequences right, confident | Go harder | Replaces P(HH) = 1/4 with **P(HHH) = 1/8** |
| Wrong lab verdict(s) | Re-read the evidence | Adds **lab1**: interpret 49% from 400 cases with sample variation |
| 1st wrong verdict / 2nd wrong verdict | Escalating support | Evaluator nudge → Teacher walk-through |
| Feeling "worried" or confidence "guessing" | Gentle mode | Softer Challenger; reassurance; calibration feedback |
| Teach-back gaps | One gap at a time | Teacher guidance targets the first missing concept |

Each adaptive question shows **"🧭 why this question"**. The Evaluator posts the updated plan in the Agent channel, and the summary lists how the path changed. Typical paths:
- **Strong learner:** f1 → q2h → q5
- **Struggling learner:** f1 → r1 → e1 → q2 → lab1 → q5

## Engagement and voice
- **Teach, then ask.** A short mini-lesson comes before any debate or practice, with the idea in words and as a picture.
- **Classroom view.** A blackboard and four seats: Asha, Kabir, Noor and **You**. Whoever is speaking is highlighted, so it feels like a class discussion, not a quiz.
- **Listen.** Every helper line has a 🔊 button, and a **Voice on/off** switch reads the lesson and debate aloud. Each agent has its own voice pitch, and 1/2 is read as "one half".
- **Say it (voice assessment).** In the teach-back Kavya can tap 🎤 and **explain aloud**. The speech is transcribed and assessed by the same concept check; the log records typed vs voice.
- **Fallback:** browser speech (Chrome/Edge on Android or desktop); without it the app works by text.
- **Few taps.**
  - Warm-up answers move on by themselves.
  - The lesson is one scrolling page, read aloud in order.
  - The class debate plays line by line (Skip ahead available).
  - Correct practice and post-test answers move on after 2.5 s ("Wait, let me read" pauses it).
  - Wrong answers stay put for a retry.
  - Choosing a final confidence opens the summary.
  - Kavya taps only to answer, never just to move along.
- **Why it suits Kavya:** an anxious learner can listen instead of reading walls of text, and *saying* an idea privately to Noor is lower-stakes than writing it for marks.

## Platform structure, two-way lesson and memory
- **Home dashboard (supporting screen, not timed):** the learning journey as cards grouped into **Learn** (check-in, Asha's lesson), **Classroom Discussion** (the debate), **Explore** (coin lab) and **Practice** (adaptive practice + teach-back, check-out, reflect).
  - It shows a progress bar, time used of 10:00, and **Continue where I stopped**.
  - Cards unlock in order (one connected journey); finished cards can be reopened.
  - Quizzes live inside the activities, not on the home screen.
- **Two-way lesson:** Asha teaches in 4 short segments. After each she **pauses for Kavya's prediction**, and her next explanation adapts to it (a wrong prediction gets a second, different explanation). Segments unlock as Kavya predicts.
- **Ask Asha, any time, by voice or text:** a question, "I'm confused", or her own reasoning.
  - Asha answers in context (stage, diagnosis, lab result) and asks **one follow-up question that makes her reason**.
  - Her reply is judged for **conceptual understanding**: by the AI (task `understand`) when available, otherwise a labelled concept check.
  - Every number in an AI answer is verified by Noor's maths check before it is shown.
- **Memory:** Asha keeps a running record of Kavya's first answer and confidence, lesson predictions, lab result, wrong verdicts and questions, and uses it later:
  - the debate recalls her lesson prediction;
  - the lab verdict recalls her first answer and confidence;
  - practice opens with "Earlier today you first said …, your lab showed …, you asked me …";
  - the summary tells the session as one story.

## D4 · App
- **Stack:** Vite + React + TypeScript (Vite starter template, no UI library); a Vercel function `/api/agent`; `localStorage` for saving.
- **C4, visible in the app:**
  - a clock "m:ss of 10:00" counting active time in stages 1–6 only;
  - stage chips with budgets;
  - **Pause & save** and "Welcome back, continue from Stage N";
  - the summary shows "completed in m:ss of 10:00".
- **ID 24B0387** appears in every footer and on the About screen.

## D6 · AI: each agent reasons, and they exchange structured outputs
**When it runs:** for the diagnosis explanation and after every wrong practice answer.

**The pipeline** (`src/lib/pipeline.ts`, `api/agent.js`):
1. **Teacher proposes.** Input: the context (diagnosis, anxious or not, lab %, question, the learner's answer, the correct result). Output: `{explanation, example}`.
2. **Challenger tests the proposal.** Output: `{verdict, issues:[{type, note}]}`. Issue types:
   - `no-independence`
   - `misconception-not-addressed`
   - `too-long` (for an anxious learner)
   - `no-evidence` (doesn't use the learner's lab data)
   - `endorses-misconception`
   - `missing-answer`
3. **Evaluator verifies the maths, always in code.** It extracts every fraction, decimal and % in the draft and checks each against exact facts (1/2, (1/2)ⁿ, 1/6, …) and the learner's **real** lab percentage. It also checks that the correct result is stated. Output: `{pass, numbers:[✓/✗ + reason]}`.
4. **Teacher revises.** Each issue is fixed (shorten, add independence, address the belief, add lab evidence). If the maths check failed, the draft is rebuilt from verified facts. The final text is checked again, so **nothing unverified reaches the learner**.

**Visibility:** the learner sees the final explanation plus "🔍 How the 3 agents built this answer", showing all four structured outputs. Each exchange is also posted to the Agent channel and the session log.

**Models and fallback:**
- **Teacher and Challenger:** an LLM (`claude-haiku-5-5` via `/api/agent`, key in a Vercel env var) when available. Their output is schema-checked, and the AI Challenger's issues are *merged* with the rule checks, never replacing them.
- **Without the AI:** a labelled rule engine does the same tasks.
- **Tested:** a wrong AI draft ("the chance becomes 1/3") is rejected by the Evaluator and never shown.
- **Explanation scoring (practice task 3):** the AI score is validated (schema, banned claims, cross-check with the rubric), with a rule-based fallback.

## D7 · Rationale
- **Cognitive conflict leads to conceptual change:** the learner's own idea is voiced by the Challenger and tested with evidence.
- **Inquiry with sampling variation:** the learner produces the evidence and learns to read it.
- **Scaffolding (ZPD):** a diagnosis-specific hint → 2 tries → model answer.
- **Cognitive Load Theory:** one idea per screen, short sentences.
- **Anxiety (affective filter):**
  - "not yet" instead of red crosses;
  - mistakes called "very common";
  - no countdown pressure; nothing graded;
  - calibration feedback that builds self-efficacy.
- **C4:** a fixed 6-stage micro-lesson of exactly 10:00, with pause and resume.

## D8 · Evaluation
| Outcome | Evidence | Success |
|---|---|---|
| LO1 | Post-test items 1–2 + follow-up | Post-test items 1–2 correct |
| LO2 | Practice numeric + post-test item 3 | Both correct |
| LO3 | Lab verdict + explanation (0–2) | Correct verdict and a score ≥ 1 |
| Conceptual gain | Pre-test vs post-test (0–3 each, matched items) | Post > pre, or both 3/3; M1/M2 answers disappear |
| Confidence | Before vs after | Rises, and matches the post-test |
| C4 | Active time | ≥ 80% finish in ≤ 10:00 |

**Logged (exportable JSON):** pre- and post-test answers; each answer with attempts, hints and misconception tag; confidence; lab batches; verdicts; notes-board changes; time per stage; pauses; agent messages.

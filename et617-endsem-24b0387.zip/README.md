# Lucky Streak? · ET 617 End-Sem · 24B0387

P3 Multi-agent collaborative learning · T6 Probability: is a "lucky streak" real? · L5 Anxious repeat learner · C4 10-minute sessions.
See `DESIGN.md` for the design.

- Built with the Vite React-TS starter template (no UI library).
- `npm install` · `npm run dev` · `npm run build`
- Optional AI Evaluator: set `ANTHROPIC_API_KEY` as a Vercel environment variable. Without it, the labelled rule-based Evaluator is used.

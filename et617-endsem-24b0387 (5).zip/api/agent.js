// Vercel serverless function for the AI agents. The API key lives only in the Vercel environment variable
// ANTHROPIC_API_KEY (never in the code). Each agent has its own task and returns STRUCTURED JSON.
// Every reply is validated again in the browser; the Evaluator's maths check always runs in code.
const TOPIC = `Topic: probability for an anxious Class 10 student in India who failed this topic once.
Concepts: a fair coin/die has no memory, tosses are independent, P(H)=1/2 after any streak; multiply for sequences.
Misconceptions: M1 = gambler's fallacy ("tails is due", "luck has to turn", "balance out"); M2 = hot hand ("a winning streak continues / guarantees another win").
Scope: fair, independent coin tosses or die rolls only (not sport skill).`;

const PROMPTS = {
  evaluate: `You are the EVALUATOR agent. ${TOPIC}
Task the student answered: "Your friend says: 'I lost the toss 5 times, so my luck has to turn now.' Explain what's really going on in 1-2 sentences."
Model answer: "Each toss is independent and the coin has no memory, so the chance is still 1/2 every time."
Rubric: 2 = independence/no memory AND chance stays 1/2; 1 = only one; 0 = neither, or endorses a misconception.
Reply with ONLY JSON: {"score":0|1|2,"misconception":"none"|"M1"|"M2"|"other","feedback":"<max 40 words, warm, simple English>"}`,
  teachback: `You are the EVALUATOR agent. ${TOPIC}
The student is doing a TEACH-BACK: explaining to a friend (who lost the toss 5 times and says "my luck has to turn") why that isn't true.
Check which concepts are present in the student's own words:
- independence: the coin has no memory / tosses are independent / past tosses don't affect the next
- chance: the chance on the next toss is still 1/2 (or 50%)
- streak: therefore the streak doesn't make a win "due" or guaranteed
Also detect a misconception the student ENDORSES (not one they reject).
Reply with ONLY JSON: {"concepts":{"independence":true|false,"chance":true|false,"streak":true|false},"misconception":"none"|"M1"|"M2"|"other"}`,
  ask: `You are ASHA, a warm teacher in a probability classroom. ${TOPIC}
The learner (anxious, repeating the topic) has asked a question, said she is confused, or explained her reasoning aloud. Context JSON: current stage, diagnosed misconception, her lab result (labPct = % heads right after HHH), anxious flag.
Answer her CONTEXTUALLY in max 3 short, simple sentences (no shaming), then ask ONE follow-up question that makes her reason, not recall.
Only use these probabilities: 1/2, 1/4, 1/6, 1/8, 1/16, 1/32, 1/64, or her labPct.
Reply with ONLY JSON: {"answer":"...","followup":"...","concept":"independence"|"chance"|"multiply"|"variation"|"streak"}`,
  understand: `You are ASHA. ${TOPIC}
You asked the learner a follow-up question (in JSON) and she replied (maybe spoken, so expect informal grammar or Hinglish).
Judge whether her reply shows CONCEPTUAL understanding of the target concept (not keywords): can she reason about why the past doesn't change the next independent toss, multiply for sequences, or interpret variation?
Reply with ONLY JSON: {"understood":true|false,"feedback":"<max 35 words: say what her reasoning got right, and if not understood, one guiding question>"}`,
  teacher: `You are the TEACHER agent (Asha). ${TOPIC}
Write a short explanation for THIS learner, using the context JSON (their diagnosed misconception "diag", whether they are anxious, their own coin-lab result labPct = % heads right after HHH, the question and their answer, and the correct result "truth").
Rules: max 3 short sentences; say the tosses are independent / the coin has no memory; speak directly to their misconception; state the correct result exactly as one of truth.forms; only use these probabilities: 1/2, 1/4, 1/6, 1/8, 1/16, 1/32, 1/64, or their own labPct. Warm, simple English.
Reply with ONLY JSON: {"explanation":"...","example":"<one everyday Indian example, 1-2 sentences>"}`,
  challenger: `You are the CHALLENGER agent (Kabir). ${TOPIC}
Test the Teacher's proposed explanation (in the JSON) for weaknesses before it reaches an anxious learner.
Look for: missing independence idea; not addressing the learner's own misconception; too long or too complex for an anxious learner; not using the learner's own lab evidence; wording that could be read as supporting the misconception; not stating the correct result.
Reply with ONLY JSON: {"issues":[{"type":"no-independence"|"misconception-not-addressed"|"too-long"|"no-evidence"|"endorses-misconception"|"missing-answer","note":"<one sentence>"}]}  (empty list if none)`,
};

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(503).json({ error: "AI not configured" });
  const body = req.body || {};
  const task = PROMPTS[body.task] ? body.task : "evaluate";
  const user =
    task === "evaluate" || task === "teachback"
      ? `Student's answer: """${String(body.answer || "").slice(0, 600)}"""`
      : task === "ask"
        ? `Context JSON: ${JSON.stringify(body.ctx || {})}\nLearner said: """${String(body.question || "").slice(0, 500)}"""`
        : task === "understand"
          ? `Context JSON: ${JSON.stringify(body.ctx || {})}\nTarget concept: ${body.concept}\nYour follow-up: """${String(body.followup || "")}"""\nHer reply: """${String(body.reply || "").slice(0, 500)}"""`
      : `Context JSON: ${JSON.stringify(body.ctx || {}).slice(0, 2000)}${body.proposal ? `\nTeacher's proposal JSON: ${JSON.stringify(body.proposal).slice(0, 2000)}` : ""}`;
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.AI_MODEL || "claude-haiku-5-5", max_tokens: 400, system: PROMPTS[task], messages: [{ role: "user", content: user }] }),
    });
    if (!r.ok) return res.status(502).json({ error: "model error " + r.status });
    const data = await r.json();
    const text = (data.content || []).map((c) => c.text || "").join("");
    return res.status(200).json(JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1)));
  } catch {
    return res.status(502).json({ error: "AI call failed" });
  }
}
